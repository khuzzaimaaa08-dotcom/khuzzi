"use client";
import { useEffect, useRef } from "react";
import { WINTER, mulberry32 } from "./heroSceneTimeline";
import { addWinterFx, wakeWinterFx, winterFxState } from "./heroWinterFx";

type Particle = {
  x: number; // px
  y: number; // px
  size: number; // px
  a: number; // current alpha (eases toward target so counts never pop)
  aBase: number; // alpha while active
  fall: number; // px/s
  swayAmp: number; // px
  swayW: number; // rad/s
  phase: number; // rad
  rot: number; // rad (glyph)
  spin: number; // rad/s (glyph)
  keep: boolean; // included in the mobile pool
};

const rand = (rng: () => number, a: number, b: number) => a + rng() * (b - a);

/* ---------- sprites, pre-rendered ONCE to offscreen canvases ---------- */
function makeCircleSprite(d: number) {
  const c = document.createElement("canvas");
  c.width = c.height = Math.max(2, Math.ceil(d));
  const g = c.getContext("2d")!;
  g.fillStyle = "#fff";
  g.beginPath();
  g.arc(d / 2, d / 2, d / 2 - 0.4, 0, Math.PI * 2);
  g.fill();
  return c;
}
function makeSoftSprite(d: number) {
  // bokeh ball: soft radial gradient (near flakes)
  const c = document.createElement("canvas");
  c.width = c.height = d;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(d / 2, d / 2, 0, d / 2, d / 2, d / 2);
  grad.addColorStop(0, "rgba(255,255,255,1)");
  grad.addColorStop(0.45, "rgba(255,255,255,0.85)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, d, d);
  return c;
}
function makeGlyphSprite(d: number) {
  // six-arm crystal flake with branch ticks
  const c = document.createElement("canvas");
  c.width = c.height = d;
  const g = c.getContext("2d")!;
  const cx = d / 2;
  const r = d / 2 - 1;
  g.strokeStyle = "#fff";
  g.lineWidth = Math.max(1, d * 0.06);
  g.lineCap = "round";
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI / 3) * i;
    const ca = Math.cos(a);
    const sa = Math.sin(a);
    g.beginPath();
    g.moveTo(cx - ca * r * 0.28, cx - sa * r * 0.28);
    g.lineTo(cx + ca * r * 0.98, cx + sa * r * 0.98);
    g.stroke();
    const bx = cx + ca * r * 0.6;
    const by = cx + sa * r * 0.6;
    for (const s of [-0.85, 0.85]) {
      g.beginPath();
      g.moveTo(bx, by);
      g.lineTo(bx + Math.cos(a + s) * r * 0.24, by + Math.sin(a + s) * r * 0.24);
      g.stroke();
    }
  }
  return c;
}

/**
 * A2 snowfall — Canvas 2D. depth "far" (far + mid flakes) renders behind the
 * landscape; depth "near" (soft bokeh flakes + glyph crystals) in front of the
 * landscape, still behind all text, CTA and navbar. Intensity and wind come
 * from the master timeline via the shared fx state; per-particle alpha easing
 * makes rising/falling counts fade instead of popping.
 */
export function HeroSnowCanvas({ depth }: { depth: "far" | "near" }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");

    let W = 0;
    let H = 0;
    let dpr = 1;
    let useMobile = window.innerWidth < 768;

    type Pool = { all: Particle[]; mob: Particle[]; sprite: HTMLCanvasElement; windMul: number; glyph: boolean };
    const pools: Pool[] = [];
    const S = WINTER.snow;

    const resize = () => {
      const w = Math.max(1, canvas.clientWidth);
      const h = Math.max(1, canvas.clientHeight);
      useMobile = window.innerWidth < 768;
      dpr = Math.min(useMobile ? 1 : S.dpr, window.devicePixelRatio || 1);
      const bw = Math.round(w * dpr);
      const bh = Math.round(h * dpr);
      if (bw !== canvas.width || bh !== canvas.height) {
        // keep the field coherent across resizes: remap positions proportionally
        if (W && H) {
          const sx = w / W;
          const sy = h / H;
          if (sx !== 1 || sy !== 1) pools.forEach((p) => p.all.forEach((pt) => { pt.x *= sx; pt.y *= sy; }));
        }
        canvas.width = bw;
        canvas.height = bh;
      }
      W = w;
      H = h;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();

    // seeded deterministic initial positions (hydration-safe: client-only anyway)
    S.classes.forEach((cls, ci) => {
      if (cls.depth !== depth) return;
      const rng = mulberry32(20261019 + ci * 31 + (depth === "near" ? 7 : 3));
      const all: Particle[] = Array.from({ length: cls.count }, (_, i) => ({
        x: rng() * W,
        y: rng() * H,
        size: rand(rng, cls.size[0], cls.size[1]),
        a: 0,
        aBase: rand(rng, cls.alpha[0], cls.alpha[1]),
        fall: rand(rng, cls.fall[0], cls.fall[1]),
        swayAmp: rand(rng, cls.sway[0], cls.sway[1]),
        swayW: 0.5 + rng() * 0.8,
        phase: rng() * Math.PI * 2,
        rot: rng() * Math.PI * 2,
        spin: ("spin" in cls ? rand(rng, -cls.spin, cls.spin) : 0) * Math.PI / 180,
        keep: i < cls.mobile,
      }));
      const sprite = "glyph" in cls ? makeGlyphSprite(26) : "soft" in cls ? makeSoftSprite(18) : cls.id === "far" ? makeCircleSprite(5) : makeCircleSprite(9);
      pools.push({ all, mob: all.filter((p) => p.keep), sprite, windMul: cls.wind, glyph: "glyph" in cls });
    });

    let t = 0;
    let gustSm = 0;
    let lastI = -1;
    let staticDrawn = false;

    const drawStatic = (I: number) => {
      // reduced motion: ~60 dim flakes, one frame, no falling
      ctx.clearRect(0, 0, W, H);
      let n = Math.round(60 * Math.min(1, I * 1.6));
      ctx.globalAlpha = 1;
      for (const pool of pools) {
        const parts = useMobile ? pool.mob : pool.all;
        for (const pt of parts) {
          if (n-- <= 0) break;
          ctx.globalAlpha = pt.aBase * 0.5;
          ctx.drawImage(pool.sprite, pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
        }
      }
      ctx.globalAlpha = 1;
    };

    const task = (dt: number): boolean => {
      const I = winterFxState.snow;
      const hard = winterFxState.hardZero;

      if (hard) {
        ctx.clearRect(0, 0, W, H);
        canvas.style.visibility = "hidden";
        return false;
      }

      // wind: slow base drift + scroll-driven gust (near flakes feel it most)
      const Wind = S.wind;
      const target = Math.max(-1, Math.min(1, winterFxState.gust / Wind.gustDivisor)) * Wind.gustMax;
      gustSm += (target - gustSm) * Math.min(1, dt * Wind.gustLerp);
      const wind = Wind.base * Math.sin(t * Wind.baseFreq) + gustSm;

      if (reduced.matches) {
        if (Math.abs(I - lastI) > 0.004 || !staticDrawn) {
          lastI = I;
          staticDrawn = true;
          drawStatic(I);
        }
        return false;
      }
      if (I <= 0.003 && !pools.some((p) => p.all.some((pt) => pt.a > 0.004))) {
        ctx.clearRect(0, 0, W, H);
        canvas.style.visibility = "hidden";
        return false;
      }

      t += dt;
      const ease = 1 - Math.pow(0.95, dt * 60); // ≈ 0.05 per 60 fps frame
      let anyVisible = false;

      ctx.clearRect(0, 0, W, H);
      for (const pool of pools) {
        const parts = useMobile ? pool.mob : pool.all;
        const active = Math.floor(parts.length * I);
        for (let i = 0; i < parts.length; i++) {
          const pt = parts[i];
          const targetA = i < active ? pt.aBase : 0;
          if (pt.a > 0.004 || targetA > 0) {
            pt.a += (targetA - pt.a) * ease;
            pt.y += pt.fall * dt;
            pt.x += wind * pool.windMul * dt;
            if (pt.spin) pt.rot += pt.spin * dt;
            if (pt.y > H + 12) {
              // re-enter above the top at a random x in [-5%, 105%]
              pt.y = -12 - Math.random() * 24;
              pt.x = Math.random() * W * 1.1 - W * 0.05;
            }
            if (pt.x < -W * 0.06) pt.x += W * 1.12;
            else if (pt.x > W * 1.06) pt.x -= W * 1.12;
          }
          if (pt.a <= 0.004) {
            pt.a = Math.max(0, pt.a);
            continue;
          }
          anyVisible = true;
          const sway = pt.swayAmp * Math.sin(t * pt.swayW + pt.phase);
          ctx.globalAlpha = Math.min(1, pt.a);
          if (pool.glyph) {
            ctx.save();
            ctx.translate(pt.x + sway, pt.y);
            ctx.rotate(pt.rot);
            ctx.drawImage(pool.sprite, -pt.size / 2, -pt.size / 2, pt.size, pt.size);
            ctx.restore();
          } else {
            ctx.drawImage(pool.sprite, pt.x + sway - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
          }
        }
      }
      ctx.globalAlpha = 1;
      if (canvas.style.visibility !== "visible") canvas.style.visibility = "visible";
      return true; // keep running while flakes are visible (fade-out drains included)
    };

    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    const remove = addWinterFx(task);
    wakeWinterFx(); // in case the scene is already active at mount
    return () => {
      remove();
      ro.disconnect();
    };
  }, [depth]);

  return <canvas ref={canvasRef} aria-hidden className="absolute inset-0 block size-full" style={{ visibility: "hidden" }} />;
}
