import { useEffect, useRef } from "react";
import { gsap, MOTION_OK } from "@/lib/motion";

const STEPS = [
  { t: "Free 15-minute call", d: "You tell us how inquiries reach you today. We point out where they get missed or answered late." },
  { t: "14-day pilot", d: "We set up one assistant for one branch or one project, at a fixed price agreed upfront. Your team stays in control of every confirmation." },
  { t: "Measure, then expand", d: "We track reply time and bookings against your starting point. If it works, we roll it out to the rest of your business." },
];

export function Process() {
  const root = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = root.current!;
    const mm = gsap.matchMedia();
    mm.add(MOTION_OK, () => {
      el.querySelectorAll<SVGPathElement>("[data-draw]").forEach((path) => {
        const len = path.getTotalLength();
        gsap.fromTo(path, { strokeDasharray: len, strokeDashoffset: len }, {
          strokeDashoffset: 0, ease: "none",
          scrollTrigger: { trigger: el, start: "top 70%", end: "bottom 70%", scrub: true },
        });
      });
      el.querySelectorAll("[data-node]").forEach((n, i) => {
        gsap.from(n, { scale: 0.4, opacity: 0.2, ease: "none", scrollTrigger: { trigger: el, start: `top+=${i * 18}% 60%`, end: `top+=${i * 18 + 10}% 60%`, scrub: true } });
      });
    });
    return () => mm.revert();
  }, []);

  return (
    <section ref={root} id="start" aria-labelledby="process-title" data-nav-theme="dark" className="bg-ultramarine py-28 text-paper">
      <div className="container-site">
        <h2 id="process-title" className="h2-fluid max-w-[12ch]">How we start</h2>
        <div className="relative mt-16">
          <svg aria-hidden viewBox="0 0 1200 120" preserveAspectRatio="none" className="absolute inset-x-0 top-0 hidden h-[120px] w-full md:block">
            <path data-draw d="M40 60 C 250 -20, 350 140, 600 60 S 950 -20, 1160 60" fill="none" stroke="currentColor" strokeWidth="4" className="text-sun" />
          </svg>
          <svg aria-hidden viewBox="0 0 20 1000" preserveAspectRatio="none" className="absolute left-[27px] top-0 h-full w-5 md:hidden">
            <path data-draw d="M10 0 V1000" fill="none" stroke="currentColor" strokeWidth="4" className="text-sun" vectorEffect="non-scaling-stroke" />
          </svg>
          <ol className="relative grid gap-12 md:grid-cols-3 md:gap-8">
            {STEPS.map((s, i) => (
              <li key={s.t} className="flex gap-6 md:block">
                <span data-node className="grid size-14 shrink-0 place-items-center rounded-full bg-sun font-display text-2xl font-extrabold text-ink tabular md:mx-0 md:mt-8">{i + 1}</span>
                <div className="md:mt-10">
                  <h3 className="text-[clamp(1.75rem,3vw,2.5rem)] font-bold">{s.t}</h3>
                  <p className="mt-4 max-w-[38ch] text-paper/90">{s.d}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}