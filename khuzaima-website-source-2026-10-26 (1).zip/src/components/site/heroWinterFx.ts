/**
 * Shared render loop for the winter night effects (8:00–9:30 pm): the WebGL
 * aurora and the two Canvas 2D snow layers. ONE requestAnimationFrame
 * scheduler drives all of them (dt clamped to 50 ms); it runs only while at
 * least one effect has intensity > 0.003 and the tab is visible, and stops
 * completely otherwise. All intensities are written by the master timeline
 * (Hero.tsx ScrollTrigger → HeroNightLayers.apply) into the module singleton
 * below — never React state per frame — so scene state stays a pure function
 * of scroll progress and reverses cleanly.
 */

export type WinterFxState = {
  /** Aurora intensity 0–1 (auroraBrightness). */
  aurora: number;
  /** Snow intensity 0–1 (snowAmount). */
  snow: number;
  /** Scroll velocity in px/s (EMA, written by the timeline, decayed by the loop). */
  gust: number;
  /** 0–1 scroll-progress phase for the aurora wrapper's gentle parallax drift. */
  drift: number;
  /** True once the clock is at/past 9:30 pm — everything must be hidden NOW. */
  hardZero: boolean;
};

export const winterFxState: WinterFxState = { aurora: 0, snow: 0, gust: 0, drift: 0, hardZero: false };

/** A task returns true while it still needs frames; false = it is done/hidden. */
export type WinterFxTask = (dt: number, t: number) => boolean;

const tasks = new Set<WinterFxTask>();
let raf = 0;
let running = false;
let last = 0;
/** Accumulated loop seconds — pauses with the loop so motion never jumps. */
let clock = 0;

/** Rough frame-time telemetry for the QA performance gate (ms). */
export const winterFxStats = { frames: 0, avgDt: 16.7, maxDt: 16.7 };

function stop() {
  if (raf) cancelAnimationFrame(raf);
  raf = 0;
  running = false;
}

function onVisibility() {
  if (document.hidden) stop();
  else wakeWinterFx();
}

function tick(now: number) {
  raf = requestAnimationFrame(tick);
  const dt = Math.min(0.05, Math.max(0.001, (now - last) / 1000));
  last = now;
  clock += dt;
  // scroll gust settles smoothly once scrolling stops (~0.45 s constant)
  winterFxState.gust *= Math.exp(-dt * 2.2);
  let any = false;
  tasks.forEach((task) => {
    if (task(dt, clock)) any = true;
  });
  winterFxStats.frames++;
  winterFxStats.avgDt += (dt * 1000 - winterFxStats.avgDt) * 0.05;
  winterFxStats.maxDt = Math.max(winterFxStats.maxDt, dt * 1000);
  if (!any) stop();
}

/** Start the loop if it is not already running (no-op while the tab is hidden). */
export function wakeWinterFx() {
  if (typeof document === "undefined" || document.hidden) return;
  if (!running) {
    running = true;
    last = performance.now();
    raf = requestAnimationFrame(tick);
  }
}

export function addWinterFx(task: WinterFxTask): () => void {
  tasks.add(task);
  if (typeof document !== "undefined") {
    document.addEventListener("visibilitychange", onVisibility);
  }
  return () => {
    tasks.delete(task);
    if (!tasks.size) {
      stop();
      if (typeof document !== "undefined") document.removeEventListener("visibilitychange", onVisibility);
    }
  };
}

if (typeof window !== "undefined" && process.env.NODE_ENV === "development") {
  // Dev/QA probe: window.__winterFx.state / .stats / .isRunning()
  (window as unknown as { __winterFx?: unknown }).__winterFx = {
    state: winterFxState,
    stats: winterFxStats,
    isRunning: () => running,
    tasks: () => tasks.size,
  };
}
