import { forwardRef, useCallback, useImperativeHandle, useRef } from "react";
import { SKY, BALLOONS, LIGHTS, ramp, smooth, lerp, easeOut, sineInOut, balloonState, envelope, buildingOpacity, lightOpacity } from "./heroSceneTimeline";
import { HIDDEN, show, useSceneBounds } from "./heroLayerTools";
import { Bird, Cloud } from "./HeroScenery";

export type SkyHandle = { update: (minutes: number) => void };

const win = (m: number, a: number, b: number, f: number) => smooth(ramp(a, a + f, m)) * (1 - smooth(ramp(b - f, b, m)));
/* ---------- BalloonScene ---------- */
function BalloonArt({ pattern, id }: { pattern: string; id: number }) {
  return (
    <svg viewBox="0 0 60 84" className="block h-auto w-full">
      <defs>
        <clipPath id={`balloon-clip-${id}`}><path d="M30 2C14 2 4 14 4 28C4 42 18 52 24 60H36C42 52 56 42 56 28C56 14 46 2 30 2Z" /></clipPath>
        <pattern id={`balloon-pattern-${id}`} width="18" height="18" patternUnits="userSpaceOnUse">
          {pattern === "chevron" ? <path fill="var(--balloon-coral)" d="M0 0L9 7L18 0V7L9 14L0 7Z" /> : <><path fill="var(--ink)" d="M9 1L15 9L9 17L3 9Z" /><path fill="var(--sun)" d="M9 5L12 9L9 13L6 9Z" /></>}
        </pattern>
      </defs>
      <path fill="var(--cloud)" d="M30 2C14 2 4 14 4 28C4 42 18 52 24 60H36C42 52 56 42 56 28C56 14 46 2 30 2Z" />
      {pattern === "stripes" && <><path fill="var(--sun)" d="M30 2C21 9 18 40 25 60H35C42 40 39 9 30 2Z" />
      <path fill="var(--ink)" d="M30 2C27 12 26 42 28.5 60H31.5C34 42 33 12 30 2Z" /></>}
      {pattern !== "stripes" && <rect width="60" height="64" fill={`url(#balloon-pattern-${id})`} clipPath={`url(#balloon-clip-${id})`} />}
      <path fill="var(--cloud-shade)" d="M24 60H36L35 63H25Z" />
      <path stroke="var(--ink)" strokeWidth="1" strokeLinecap="round" d="M25 63L26.5 72M35 63L33.5 72" />
      <rect x="25" y="72" width="10" height="9" rx="2" fill="var(--ink)" />
    </svg>
  );
}

/* ---------- PlaneContrailScene ---------- */
function PlaneArt() {
  return (
    <svg viewBox="0 0 36 14" className="block h-auto w-full fill-ink">
      <path d="M2 7L30 5.5C33 5.5 35 6.3 35 7S33 8.5 30 8.5ZM14 6.5L20 0H23L19 6.2ZM14 7.5L20 14H23L19 7.8ZM3 7L1 3H4L7 6.6Z" />
    </svg>
  );
}

/* ---------- SkylineScene (viewBox 800x200, ground y=200) ---------- */
// Far layer, left to right.
const FAR = [
  { d: "M110 200V62h54v138Z", top: 62 }, { d: "M320 200V44h62v156Z", top: 44 },
  { d: "M380 200V110h40v90Z", top: 110 }, { d: "M590 200V74h58v126Z", top: 74 },
];
// Near layer in reveal order: low-rise left to right, then towers, spire and clinic last.
const NEAR = [
  { d: "M14 200V152l38-26 38 26v48Z", top: 126 }, // house
  { d: "M286 200V148l30-22 30 22v52Z", top: 126 }, // house
  { d: "M738 200V154l30-20 30 20v46Z", top: 134 }, // house
  { d: "M196 200V82a4 4 0 0 1 4-4h66a4 4 0 0 1 4 4v118Z", top: 78 }, // apartment tower
  { d: "M496 200V98a4 4 0 0 1 4-4h76a4 4 0 0 1 4 4v102Z", top: 94 }, // apartment tower
  { d: "M430 200V44L440 6L450 44V200Z", top: 6 }, // slim spire tower
  { d: "M606 200V132a6 6 0 0 1 6-6h104a6 6 0 0 1 6 6v68Z", top: 126 }, // clinic
];
const reveal = (m: number, a: number, dur: number, travel: number, n: SVGGElement | null | undefined, h: number, sk: number) => {
  if (!n) return;
  const t = ramp(a, a + dur, m);
  n.setAttribute("transform", `translate(0 ${((1 - easeOut(t)) * h * travel + sk * h).toFixed(2)})`);
  n.style.opacity = (smooth(ramp(0, 0.4, t)) * buildingOpacity(m)).toFixed(3);
};
const HOMEWARD = [0, 1, 2, 3, 4, 5].map((k) => ({ k, w: 32 - k * 1.5, flap: 1.3 + (k % 3) * 0.12, ph: k * 0.7 }));

export const HeroSkyLayers = forwardRef<SkyHandle>(function HeroSkyLayers(_, ref) {
  const root = useRef<HTMLDivElement>(null);
  const size = useRef({ W: 1, H: 1 });
  const lastM = useRef(0);
  const balloons = useRef<(HTMLDivElement | null)[]>([]);
  const balloonFades = useRef<(HTMLDivElement | null)[]>([]);
  const plane = useRef<HTMLDivElement>(null);
  const planeEl = useRef<HTMLDivElement>(null);
  const trail = useRef<SVGSVGElement>(null);
  const trailLine = useRef<SVGLineElement>(null);
  const trailGrad = useRef<SVGLinearGradientElement>(null);
  const skyline = useRef<HTMLDivElement>(null);
  const hill = useRef<HTMLDivElement>(null);
  const far = useRef<SVGGElement>(null);
  const farEls = useRef<(SVGGElement | null)[]>([]);
  const nearEls = useRef<(SVGGElement | null)[]>([]);
  const near = useRef<SVGGElement>(null);
  const wins = useRef<(SVGRectElement | null)[]>([]);
  const plus = useRef<SVGGElement>(null);
  const birdLayer = useRef<HTMLDivElement>(null);
  const birds = useRef<(HTMLDivElement | null)[]>([]);
  const sunset = useRef<(HTMLDivElement | null)[]>([]);
  const warm = useRef<(HTMLDivElement | null)[]>([]);
  const dusk = useRef<(HTMLDivElement | null)[]>([]);
  const evening = useRef<HTMLDivElement>(null);
  const lamps = useRef<(SVGGElement | null)[]>([]);
  const halos = useRef<(SVGEllipseElement | null)[]>([]);
  const beacon = useRef<SVGGElement>(null);

  const apply = useCallback((m: number) => {
    lastM.current = m;
    const { W, H } = size.current;
    const px = (x: number) => (x / 100) * W, py = (y: number) => (y / 100) * H;

    BALLOONS.forEach((_, i) => {
      const b = balloonState(m, i, W < 768), node = balloons.current[i], fade = balloonFades.current[i];
      if (show(node, b.opacity) && node) {
        node.style.transform = `translate3d(${px(b.x)}px,${py(b.y)}px,0) translate(-50%,-50%)`;
        if (fade) fade.style.transform = `scale(${b.scale})`;
      }
    });

    // Jet + dotted contrail
    const P = SKY.plane;
    const po = smooth(ramp(P.in, P.full, m)) * (1 - smooth(ramp(P.vanish, P.out, m)));
    if (show(plane.current, m >= P.in && m < P.out ? po : 0)) {
      const e = sineInOut(ramp(P.in, P.out, m));
      const x = px(lerp((P.from[0] ?? 0), (P.to[0] ?? 0), e)), y = py(lerp((P.from[1] ?? 0), (P.to[1] ?? 0), e));
      const sc = lerp(1, P.vanishScale, smooth(ramp(P.vanish, P.out, m)));
      const sx = px((P.from[0] ?? 0)), sy = py((P.from[1] ?? 0));
      if (planeEl.current) planeEl.current.style.transform = `translate3d(${x}px,${y}px,0) translate(-50%,-50%) rotate(-3deg) scale(${sc.toFixed(3)})`;
      const ex = x - 18 * sc, ey = y + 1;
      trail.current?.setAttribute("viewBox", `0 0 ${W} ${H}`);
      for (const n of [trailLine.current, trailGrad.current]) {
        [sx, sy, ex, ey].forEach((v, i) => n?.setAttribute(["x1", "y1", "x2", "y2"][i] ?? "x1", v.toFixed(1)));
      }
    }

    // Downtown: hill, then far, then near buildings rise; exit mirrors it (clinic + spire first, hill last).
    const K = SKY.skyline;
    const seq = NEAR.length + FAR.length, span = K.sinkEnd - K.sinkDur - 1 - K.sinkStart;
    const sinkAt = (j: number) => sineInOut(ramp(K.sinkStart + (j * span) / (seq - 1), K.sinkStart + (j * span) / (seq - 1) + K.sinkDur, m));
    if (show(skyline.current, m >= K.hill[0] && m < K.sinkEnd ? 1 : 0)) {
      const ht = ramp(K.hill[0], K.hill[1], m), hs = sineInOut(ramp(K.sinkEnd - 5, K.sinkEnd, m));
      if (hill.current) hill.current.style.opacity = (smooth(ht) * buildingOpacity(m)).toFixed(3);
      if (hill.current) hill.current.style.transform = `translateY(${(1 - easeOut(ht)) * K.hillRise + hs * K.hillRise}px)`;
      const fs = (K.far[1] - K.far[0] - K.farDur) / Math.max(1, FAR.length - 1);
      FAR.forEach((b, i) => reveal(m, K.far[0] + i * fs, K.farDur, K.farTravel, farEls.current[i], 200 - b.top, sinkAt(NEAR.length + FAR.length - 1 - i)));
      const ns = (K.near[1] - K.near[0] - K.nearDur) / Math.max(1, NEAR.length - 1);
      NEAR.forEach((b, i) => reveal(m, K.near[0] + i * ns, K.nearDur, 1, nearEls.current[i], 200 - b.top, sinkAt(NEAR.length - 1 - i)));
      LIGHTS.forEach((w, i) => show(wins.current[i], w.lit ? lightOpacity(m, w.threshold, w.y) : 0));
      const L = SKY.windows;
      halos.current.forEach((n, i) => show(n, envelope(m, L.start + i * 1.5, L.half, L.offStart, L.out) * 0.16));
      lamps.current.forEach((n, i) => show(n, lightOpacity(m, L.start + i * 2, 198)));
      show(plus.current, lightOpacity(m, L.start, 146));
      show(beacon.current, lightOpacity(m, L.start, 6));
    }

    // Homeward birds, right to left in a loose V
    const Hm = SKY.homeward;
    if (show(birdLayer.current, win(m, Hm.in, Hm.out, Hm.fade))) {
      const u = ramp(Hm.in, Hm.out, m);
      HOMEWARD.forEach((b, i) => {
        const n = birds.current[i];
        if (!n) return;
        const side = Math.ceil(b.k / 2), dir = b.k % 2 ? -1 : 1;
        const x = lerp((Hm.x[0] ?? 0), (Hm.x[1] ?? 0), u) + side * 3.4;
        const y = lerp((Hm.y[0] ?? 0), (Hm.y[1] ?? 0), u) + dir * side * 2.3 + Math.sin(u * Math.PI * 3 + b.ph) * 0.6;
        n.style.transform = `translate3d(${px(x)}px,${py(y)}px,0) translate(-50%,-50%) scaleX(-1)`;
      });
    }

    const St = SKY.sunset;
    const tint = smooth(ramp(St.duskIn, St.duskFull, m));
    St.items.forEach((c, i) => {
      const n = sunset.current[i], opacity = envelope(m, St.in, St.full, St.fadeOut, St.out);
      if (show(n, opacity * c.op) && n) n.style.transform = `translate3d(${-px(St.travel * c.depth * sineInOut(ramp(St.in, St.out, m)))}px,0,0) scale(${0.94 + 0.06 * smooth(ramp(St.in, St.full, m))})`;
      show(warm.current[i], 1 - tint);
      show(dusk.current[i], tint);
    });
    const E = SKY.evening;
    show(evening.current, envelope(m, E.in, E.full, E.fadeOut, E.out));
  }, []);

  useImperativeHandle(ref, () => ({ update: apply }), [apply]);

  const measure = useCallback((W: number, H: number) => { size.current = { W, H }; apply(lastM.current); }, [apply]);
  useSceneBounds(root, measure);

  return (
    <div ref={root} aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden [contain:layout_paint]">
      <div data-copy-safe className="absolute inset-0">
        {BALLOONS.map((b, i) => <div key={i} data-balloon={i + 1} data-depth={b.depth} ref={(n) => { balloons.current[i] = n; }} className="absolute left-0 top-0 w-[clamp(40px,4.6vw,76px)] will-change-transform" style={HIDDEN}>
          <div ref={(n) => { balloonFades.current[i] = n; }}><div className="balloon-idle" style={{ "--sway": `${b.sway}s`, "--phase": `${b.phase}s` } as React.CSSProperties}><BalloonArt pattern={b.pattern} id={i} /></div></div>
        </div>)}
      </div>

      {/* SkylineScene */}
      <div ref={skyline} className="absolute inset-0" style={HIDDEN}>
        <div ref={hill} className="absolute inset-x-0 bottom-0 h-[12vh] will-change-transform">
          <svg viewBox="0 0 1000 100" preserveAspectRatio="none" className="size-full">
            <path fill="var(--ink)" fillOpacity="0.06" d="M0 100V62C120 40 230 30 360 46S600 74 720 54 900 28 1000 44V100Z" />
          </svg>
        </div>
        <svg
          viewBox="0 0 800 200"
          preserveAspectRatio="xMaxYMax meet"
          className="absolute bottom-0 right-0 h-[21vh] w-[55%]"
          overflow="visible"
        >
          <defs><radialGradient id="city-light-halo"><stop stopColor="var(--sun)" stopOpacity="0.9" /><stop offset="1" stopColor="var(--sun)" stopOpacity="0" /></radialGradient></defs>
          {[{ layer: "far", data: FAR, refs: farEls, group: far }, { layer: "near", data: NEAR, refs: nearEls, group: near }].map(({ layer, data, refs, group }) => <g key={layer} ref={group}>
            {data.map((b, i) => <g key={i} data-building={`${layer}-${i}`} ref={(n) => { refs.current[i] = n; }} style={{ opacity: 0 }}>
              <ellipse ref={(n) => { halos.current[layer === "far" ? i : FAR.length + i] = n; }} cx={layer === "far" ? [137, 351, 400, 619][i] : [52, 316, 768, 233, 538, 440, 664][i]} cy={(b.top + 200) / 2} rx="48" ry={(200 - b.top) / 2} fill="url(#city-light-halo)" style={HIDDEN} />
              <path fill="var(--ink)" fillOpacity={layer === "far" ? 0.14 : 0.24} d={b.d} />
              {LIGHTS.map((w, wi) => w.layer === layer && w.building === i ? <g key={wi} className={`${wi < 4 ? "win-flicker" : ""} ${w.mobile ? "" : "max-md:hidden"}`}>
                <rect data-window data-lit={w.lit} ref={(n) => { wins.current[wi] = n; }} x={w.x} y={w.y} width={w.width} height="9" rx="1" fill={w.tone} style={HIDDEN} />
              </g> : null)}
              {layer === "near" && i === 5 && <g ref={beacon} style={HIDDEN}><g className="beacon-blink"><circle cx="440" cy="6" r="6" fill="var(--beacon)" fillOpacity="0.2" /><circle cx="440" cy="6" r="2" fill="var(--paper)" /></g></g>}
              {layer === "near" && i === 6 && <g ref={plus} style={HIDDEN}><g className="plus-pulse" fill="var(--mint)"><rect x="659" y="138" width="8" height="24" rx="1.5" /><rect x="651" y="146" width="24" height="8" rx="1.5" /></g></g>}
            </g>)}
          </g>)}
          {Array.from({ length: 7 }, (_, i) => <g key={i} ref={(n) => { lamps.current[i] = n; }} style={HIDDEN}>
            <ellipse cx={85 + i * 105} cy="196" rx="24" ry="4" fill="url(#city-light-halo)" fillOpacity="0.3" />
            <path d={`M${85 + i * 105} 195v-16`} stroke="var(--ink)" strokeOpacity="0.25" strokeWidth="1.5" />
            <circle cx={85 + i * 105} cy="179" r="9" fill="url(#city-light-halo)" fillOpacity="0.18" /><circle cx={85 + i * 105} cy="179" r="2" fill="var(--sun)" />
          </g>)}
        </svg>
      </div>

      <div data-copy-safe className="absolute inset-0">
        <svg className="absolute size-0"><defs>
          <linearGradient id="sunset-warm" x2="0" y2="1"><stop stopColor="var(--sunset-rim)" /><stop offset="0.45" stopColor="var(--sunset-peach)" /><stop offset="1" stopColor="var(--sunset-rose)" /></linearGradient>
          <linearGradient id="sunset-dusk" x2="0" y2="1"><stop stopColor="var(--sunset-peach)" /><stop offset="0.45" stopColor="var(--sunset-rose)" /><stop offset="1" stopColor="var(--lilac)" /></linearGradient>
        </defs></svg>
        {SKY.sunset.items.map((c, i) => <div key={i} data-sunset-cloud ref={(n) => { sunset.current[i] = n; }} className="absolute" style={{ left: `${c.x}%`, top: `${c.y}%`, width: `max(${132 * c.size}px, ${11.58 * c.size}%)`, ...HIDDEN }}>
          <div ref={(n) => { warm.current[i] = n; }}><Cloud fill="url(#sunset-warm)" shade="var(--sunset-rose)" rim /></div>
          <div ref={(n) => { dusk.current[i] = n; }} className="absolute inset-0"><Cloud fill="url(#sunset-dusk)" shade="var(--sunset-dusk-base)" rim /></div>
        </div>)}
        <div data-evening-star ref={evening} className="absolute size-[18px]" style={{ left: `${SKY.evening.x}%`, top: `${SKY.evening.y}%`, ...HIDDEN }}><div className="evening-twinkle"><svg viewBox="-16 -16 52 52" className="size-full overflow-visible"><defs><radialGradient id="evening-glow"><stop stopColor="var(--paper)" stopOpacity="0.45" /><stop offset="1" stopColor="var(--paper)" stopOpacity="0" /></radialGradient></defs><circle cx="10" cy="10" r="25" fill="url(#evening-glow)" /><path fill="var(--paper)" d="M10 0C11 7 13 9 20 10C13 11 11 13 10 20C9 13 7 11 0 10C7 9 9 7 10 0Z" /></svg></div></div>
      </div>

      {/* PlaneContrailScene (desktop only) */}
      <div ref={plane} className="absolute inset-0 max-md:hidden" style={HIDDEN}>
        <svg ref={trail} className="absolute inset-0 size-full" viewBox="0 0 1 1">
          <defs>
            <linearGradient ref={trailGrad} id="contrail-fade" gradientUnits="userSpaceOnUse">
              <stop offset="0" stopColor="var(--ink)" stopOpacity="0" />
              <stop offset="1" stopColor="var(--ink)" stopOpacity="0.4" />
            </linearGradient>
          </defs>
          <line ref={trailLine} stroke="url(#contrail-fade)" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="0 9" />
        </svg>
        <div ref={planeEl} className="absolute left-0 top-0 w-8 will-change-transform"><PlaneArt /></div>
      </div>

      {/* HomewardBirds */}
      <div ref={birdLayer} className="absolute inset-0" style={HIDDEN}>
        {HOMEWARD.map((b, i) => (
          <div
            key={i}
            ref={(n) => { birds.current[i] = n; }}
            className={`absolute left-0 top-0 will-change-transform ${i >= 4 ? "max-md:hidden" : ""}`}
            style={{ width: `max(${b.w * 0.6}px, ${b.w / 19}%)` }}
          >
            <Bird flap={b.flap} ph={b.ph} />
          </div>
        ))}
      </div>
    </div>
  );
});

/* ---------- GoldenHourGlow: lives inside the sun's own SVG group ---------- */
const RAYS = Array.from({ length: 10 }, (_, i) => i * 36);
export const GoldenHourGlow = forwardRef<SkyHandle>(function GoldenHourGlow(_, ref) {
  const g = useRef<SVGGElement>(null);
  const halo = useRef<SVGCircleElement>(null);
  const rays = useRef<SVGGElement>(null);
  useImperativeHandle(ref, () => ({
    update: (m: number) => {
      const G = SKY.glow;
      if (!show(g.current, win(m, G.in, G.out, G.fade))) return;
      const grow = 1 + 0.35 * smooth(ramp(G.in, G.peak, m));
      halo.current?.setAttribute("transform", `scale(${grow.toFixed(3)})`);
      rays.current?.setAttribute("transform", `rotate(${(ramp(G.in, G.out, m) * 40).toFixed(2)})`);
    },
  }), []);
  return (
    <g ref={g} style={HIDDEN}>
      <defs>
        <radialGradient id="sun-halo" r="0.5">
          <stop offset="0.45" stopColor="var(--sun)" stopOpacity="0.35" />
          <stop offset="1" stopColor="var(--sun)" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="sun-ray" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="160">
          <stop offset="0.25" stopColor="var(--sun)" stopOpacity="0.12" />
          <stop offset="1" stopColor="var(--sun)" stopOpacity="0" />
        </radialGradient>
      </defs>
      <g ref={rays} className="max-md:hidden" fill="url(#sun-ray)">
        {RAYS.map((r) => <path key={r} transform={`rotate(${r})`} d="M-2.4 -40L0 -160L2.4 -40Z" />)}
      </g>
      <circle ref={halo} r="72" fill="url(#sun-halo)" />
    </g>
  );
});