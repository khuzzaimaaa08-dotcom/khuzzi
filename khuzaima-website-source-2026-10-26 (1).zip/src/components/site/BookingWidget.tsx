"use client";

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { gsap, MOTION_OK } from "@/lib/motion";
import { Magnetic } from "@/components/site/Magnetic";
import { TIME_SLOTS, TOPICS } from "@/lib/booking-schema";
import { site } from "@/site.config";

type Day = {
  iso: string;
  weekday: string;
  dayNum: string;
  month: string;
  label: string;
};

/** Next 10 weekdays, built client-side only (server/client clocks can differ). */
function buildDays(): Day[] {
  const out: Day[] = [];
  const d = new Date();
  while (out.length < 10) {
    d.setDate(d.getDate() + 1);
    const dow = d.getDay();
    if (dow === 0 || dow === 6) continue;
    out.push({
      iso: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`,
      weekday: d.toLocaleDateString("en-US", { weekday: "short" }),
      dayNum: String(d.getDate()),
      month: d.toLocaleDateString("en-US", { month: "short" }),
      label: d.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }),
    });
  }
  return out;
}

/** Client-only snapshot via useSyncExternalStore: null during SSR, dates after hydration. */
let clientDays: Day[] | null = null;
const subscribe = () => () => {};
const getDays = () => (clientDays ??= buildDays());
const getServerDays = () => null;

/** Deterministic "already booked" slots (~30%), stable per date+time. */
function isTaken(iso: string, slot: string): boolean {
  let h = 2166136261;
  const s = iso + slot;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h % 10 < 3;
}

const prettyTime = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  const ampm = h >= 12 ? "PM" : "AM";
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${hh}:${String(m).padStart(2, "0")} ${ampm}`;
};

const endTime = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  const end = new Date(2000, 0, 1, h, m + 15);
  const hh = end.getHours() % 12 === 0 ? 12 : end.getHours() % 12;
  return `${hh}:${String(end.getMinutes()).padStart(2, "0")} ${end.getHours() >= 12 ? "PM" : "AM"}`;
};

const field =
  "w-full h-[clamp(52px,4.4vw,60px)] rounded-[18px] border border-ink/12 bg-white/70 px-5 text-[16px] text-ink placeholder:text-ink/45 outline-none transition-all duration-150 focus:border-ink/60 focus:bg-white";

export function BookingWidget() {
  const days = useSyncExternalStore(subscribe, getDays, getServerDays);
  const [dateIdx, setDateIdx] = useState<number | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [state, setState] = useState<"idle" | "sending" | "done" | "taken" | "error">("idle");
  const [who, setWho] = useState({ name: "", topic: "" });
  const cardRef = useRef<HTMLDivElement>(null);
  const timeRef = useRef<HTMLFieldSetElement>(null);

  useEffect(() => {
    if (state !== "done" || !cardRef.current) return;
    const ctx = gsap.context(() => {
      gsap.matchMedia().add(MOTION_OK, () => {
        gsap.from("[data-ok] > *", { y: 18, opacity: 0, duration: 0.55, ease: "power3.out", stagger: 0.07 });
      });
    }, cardRef.current);
    return () => ctx.revert();
  }, [state]);

  const day = dateIdx !== null && days ? days[dateIdx] : null;
  const takenSet = useMemo(
    () => (day ? TIME_SLOTS.filter((s) => isTaken(day.iso, s)) : []),
    [day]
  );

  function pickDate(i: number) {
    if (i === dateIdx) return;
    setDateIdx(i);
    if (time && days && isTaken(days[i].iso, time)) setTime(null);
    setState("idle");
    requestAnimationFrame(() => {
      timeRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!day || !time) return;
    const f = new FormData(e.currentTarget);
    const g = (k: string) => String(f.get(k) ?? "");
    const name = g("name").split(" ")[0] || "there";
    const topic = g("topic");
    setWho({ name, topic });
    setState("sending");
    try {
      const res = await fetch("/api/book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: g("name"),
          email: g("email"),
          company: g("company"),
          topic,
          notes: g("notes"),
          call_date: day.iso,
          call_time: time,
        }),
      });
      if (res.ok) {
        setState("done");
        cardRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      } else if (res.status === 409) {
        setState("taken");
        setTime(null);
        timeRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      } else {
        setState("error");
      }
    } catch {
      setState("error");
    }
  }

  /** .ics calendar invite — times are PKT (GMT+5), 15 minutes long. */
  function downloadIcs() {
    if (!day || !time) return;
    const [y, mo, da] = day.iso.split("-").map(Number);
    const [hh, mi] = time.split(":").map(Number);
    const start = new Date(Date.UTC(y, mo - 1, da, hh, mi) - 5 * 3_600_000);
    const end = new Date(start.getTime() + 15 * 60_000);
    const fmt = (x: Date) => x.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
    const ics = [
      "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Khuzaima Labs//Booking//EN", "BEGIN:VEVENT",
      `UID:${Date.now()}@khuzaimalabs.com`, `DTSTAMP:${fmt(new Date())}`,
      `DTSTART:${fmt(start)}`, `DTEND:${fmt(end)}`,
      "SUMMARY:Free 15-minute call — Khuzaima Labs",
      `DESCRIPTION:Topic: ${who.topic || "Introduction"}.\\nA video call link arrives by email shortly. See you soon!`,
      "END:VEVENT", "END:VCALENDAR",
    ].join("\r\n");
    const url = URL.createObjectURL(new Blob([ics], { type: "text/calendar" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "khuzaima-labs-call.ics";
    a.click();
    URL.revokeObjectURL(url);
  }

  const chipBase = "flex shrink-0 cursor-pointer flex-col items-center justify-center rounded-[18px] transition-all duration-200";
  const dateChip = (active: boolean) =>
    `${chipBase} h-[76px] w-[68px] border ${active
      ? "border-ink bg-ink text-paper shadow-[0_10px_24px_-8px_var(--ink)] -translate-y-0.5"
      : "border-ink/12 bg-white/70 text-ink hover:border-ink/40 hover:-translate-y-0.5"}`;
  const timeChip = (active: boolean) =>
    `${chipBase} h-12 px-4 border text-sm font-semibold tabular ${active
      ? "border-ink bg-ink text-paper shadow-[0_10px_24px_-8px_var(--ink)] -translate-y-0.5"
      : "border-ink/12 bg-white/70 text-ink hover:border-ink/40 hover:-translate-y-0.5"}`;

  return (
    <div className="grid gap-6 lg:grid-cols-12 lg:gap-8">
      {/* ——— Flow column ——— */}
      <div className="lg:col-span-8">
        <div ref={cardRef} className="rounded-panel border border-ink/10 bg-paper p-5 shadow-[0_24px_60px_-32px_rgba(23,23,58,0.25)] sm:p-8">
          {state === "done" ? (
            <div data-ok className="py-6 text-center">
              <div className="mx-auto mb-6 w-fit">
                <svg viewBox="0 0 120 120" className="sun-rise size-28" aria-hidden>
                  <g className="sun-rays" stroke="var(--tangerine)" strokeWidth="4" strokeLinecap="round">
                    {Array.from({ length: 12 }).map((_, i) => {
                      const a = (i * 30 * Math.PI) / 180;
                      const r1 = 44, r2 = i % 2 ? 52 : 56;
                      const R = (n: number) => Math.round(n * 100) / 100;
                      return <line key={i} x1={R(60 + r1 * Math.cos(a))} y1={R(60 + r1 * Math.sin(a))} x2={R(60 + r2 * Math.cos(a))} y2={R(60 + r2 * Math.sin(a))} />;
                    })}
                  </g>
                  <circle cx="60" cy="60" r="36" fill="var(--sun)" />
                  <path d="M46 62l9 9 19-21" fill="none" stroke="var(--ink)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <h3 className="font-display text-4xl font-extrabold">You&rsquo;re booked, {who.name}.</h3>
              <p className="mx-auto mt-3 max-w-[46ch] text-ink/70">
                A calendar invite with the video link is on its way to your inbox. Fifteen minutes, zero pitch — we promise.
              </p>
              <div className="mx-auto mt-6 flex max-w-md flex-wrap items-center justify-center gap-2 text-sm font-semibold">
                <span className="rounded-full bg-ink px-4 py-2 text-paper">{day?.label}</span>
                <span className="rounded-full bg-coral px-4 py-2 text-paper">{time ? `${prettyTime(time)} – ${endTime(time)} PKT` : ""}</span>
                <span className="rounded-full bg-sun px-4 py-2 text-ink">{who.topic || "Intro call"}</span>
              </div>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <Magnetic><button type="button" onClick={downloadIcs} className="btn-pill">Add to calendar (.ics)</button></Magnetic>
                <a href={site.whatsapp} target="_blank" rel="noopener noreferrer" className="btn-ghost hover:!bg-ink hover:!text-paper hover:!border-ink">WhatsApp us</a>
                <Link href="/" className="px-4 py-2 font-semibold underline underline-offset-4 hover:text-ultramarine">Back to home</Link>
              </div>
            </div>
          ) : (
            <form onSubmit={onSubmit}>
              {/* Step 1 — date */}
              <fieldset>
                <legend className="mb-3 flex items-center gap-3">
                  <span className="grid size-7 place-items-center rounded-full bg-coral text-[13px] font-bold text-paper">1</span>
                  <span className="font-display text-xl font-bold">Pick a day</span>
                  <span className="text-sm text-ink/50">Mon–Fri, next two weeks</span>
                </legend>
                {days ? (
                  <div className="picker-strip -mx-1 flex gap-2 overflow-x-auto px-1 pb-1" role="radiogroup" aria-label="Call date">
                    {days.map((d, i) => (
                      <label key={d.iso} className={`${dateChip(dateIdx === i)} has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-ink`}>
                        <input type="radio" name="call_date" value={d.iso} className="sr-only" checked={dateIdx === i} onChange={() => pickDate(i)} />
                        <span className="text-[11px] font-bold uppercase tracking-wider opacity-70">{d.weekday}</span>
                        <span className="font-display text-2xl font-extrabold leading-none">{d.dayNum}</span>
                        <span className="text-[11px] font-semibold opacity-70">{d.month}</span>
                      </label>
                    ))}
                  </div>
                ) : (
                  <div className="flex gap-2" aria-hidden>
                    {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-[76px] w-[68px] animate-pulse rounded-[18px] bg-ink/5" />)}
                  </div>
                )}
              </fieldset>

              {/* Step 2 — time */}
              <fieldset ref={timeRef} className="mt-7 scroll-mt-32 transition-opacity duration-300" aria-disabled={!day}>
                <legend className="mb-3 flex flex-wrap items-center gap-3">
                  <span className={`grid size-7 place-items-center rounded-full text-[13px] font-bold ${day ? "bg-aqua text-ink" : "bg-ink/15 text-ink/50"}`}>2</span>
                  <span className="font-display text-xl font-bold">Pick a time</span>
                  <span className="text-sm text-ink/50">Pakistan Standard Time (GMT+5)</span>
                </legend>
                <div className={`grid grid-cols-3 gap-2 sm:grid-cols-5 ${!day ? "pointer-events-none opacity-35" : ""}`} role="radiogroup" aria-label="Call time">
                  {TIME_SLOTS.map((s) => {
                    const taken = !!day && takenSet.includes(s);
                    return (
                      <label key={s} className={`${timeChip(time === s)} ${taken ? "pointer-events-none !border-ink/8 !bg-ink/5 !text-ink/35 line-through" : ""} has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-ink`}>
                        <input type="radio" name="call_time" value={s} className="sr-only" disabled={!day || taken} checked={time === s} onChange={() => { setTime(s); setState("idle"); }} />
                        {prettyTime(s)}
                      </label>
                    );
                  })}
                </div>
                {state === "taken" && (
                  <p role="alert" className="mt-3 rounded-2xl bg-flamingo/15 px-4 py-2.5 text-sm font-semibold text-ink">
                    Someone just grabbed that slot — the grid is refreshed, pick another time.
                  </p>
                )}
              </fieldset>

              {/* Step 3 — details */}
              <fieldset className={`mt-7 transition-opacity duration-300 ${!time ? "pointer-events-none opacity-35" : ""}`} aria-disabled={!time}>
                <legend className="mb-3 flex items-center gap-3">
                  <span className={`grid size-7 place-items-center rounded-full text-[13px] font-bold ${time ? "bg-sun text-ink" : "bg-ink/15 text-ink/50"}`}>3</span>
                  <span className="font-display text-xl font-bold">Your details</span>
                </legend>
                <div className="grid gap-[15px] min-[480px]:grid-cols-2">
                  <input name="name" required minLength={2} maxLength={100} placeholder="Full name*" aria-label="Full name" autoComplete="name" className={field} />
                  <input name="email" type="email" required maxLength={255} placeholder="Work email*" aria-label="Work email" autoComplete="email" className={field} />
                  <input name="company" required minLength={2} maxLength={150} placeholder="Company or clinic*" aria-label="Company" autoComplete="organization" className={field} />
                  <div className="relative">
                    <select name="topic" required defaultValue="" aria-label="What should we talk about?" className={`${field} appearance-none pr-10 invalid:text-ink/45`}>
                      <option value="" disabled hidden>What do you run?*</option>
                      {TOPICS.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <svg viewBox="0 0 24 24" aria-hidden className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 9l6 6 6-6" /></svg>
                  </div>
                </div>
                <textarea name="notes" rows={3} maxLength={1000} placeholder="Anything we should know before we dial in? (optional)" aria-label="Notes"
                  className={`${field} mt-[15px] h-auto min-h-[96px] resize-y py-4`} />
                <div className="mt-5 flex flex-wrap items-center gap-4">
                  <Magnetic>
                    <button type="submit" disabled={!day || !time || state === "sending"}
                      className="btn-pill w-full min-[480px]:w-auto disabled:opacity-50 disabled:pointer-events-none">
                      {state === "sending" ? "Locking it in…" : "Confirm my free call"}
                    </button>
                  </Magnetic>
                  <p className="text-sm text-ink/55">No card. No invoice. No awkward follow-up calls.</p>
                </div>
                {state === "error" && (
                  <p role="alert" className="mt-3 text-sm font-semibold text-flamingo">
                    Something went wrong on our side. Try once more, or WhatsApp us.
                  </p>
                )}
              </fieldset>
            </form>
          )}
        </div>
      </div>

      {/* ——— Summary aside ——— */}
      <aside className="lg:col-span-4" aria-live="polite">
        <div className="rounded-panel overflow-hidden border border-ink/10 bg-ink text-paper lg:sticky lg:top-24">
          <div className="border-b border-paper/15 px-6 pb-4 pt-5">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-paper/55">Your slot</p>
          </div>
          <div className="px-6 py-5">
            {day && time ? (
              <>
                <p className="font-display text-3xl font-extrabold leading-tight">{day.label}</p>
                <p className="mt-1 font-display text-2xl font-bold text-sun tabular">
                  {prettyTime(time)} – {endTime(time)}
                </p>
                <p className="mt-1 text-sm text-paper/60">Pakistan Standard Time (GMT+5)</p>
              </>
            ) : (
              <p className="font-display text-2xl font-extrabold leading-snug text-paper/85">
                {day ? "Now pick a time →" : "Pick a day to begin →"}
              </p>
            )}
            <dl className="mt-6 space-y-3 text-sm">
              <div className="flex items-center justify-between gap-3 border-t border-paper/12 pt-3">
                <dt className="text-paper/55">Duration</dt>
                <dd className="font-semibold tabular">15 minutes</dd>
              </div>
              <div className="flex items-center justify-between gap-3 border-t border-paper/12 pt-3">
                <dt className="text-paper/55">Format</dt>
                <dd className="font-semibold">Video call</dd>
              </div>
              <div className="flex items-center justify-between gap-3 border-t border-paper/12 pt-3">
                <dt className="text-paper/55">Price</dt>
                <dd className="font-semibold text-sun">Free, forever</dd>
              </div>
            </dl>
          </div>
          <div className="flex items-center gap-3 bg-paper/8 px-6 py-4 text-sm text-paper/70">
            <svg viewBox="0 0 24 24" className="size-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden><path d="M4 5h16v11H8l-4 4V5z" /></svg>
            Google Meet link arrives with your confirmation email.
          </div>
        </div>
      </aside>
    </div>
  );
}
