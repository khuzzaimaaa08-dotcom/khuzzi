"use client";

import { useEffect } from "react";

/* Scroll-scrubbed light-to-dark theme transition for the home page.
 *
 * The "Our work." divider heading is the boundary: while it sits below the
 * viewport the page canvas stays exactly as designed (white, near-black
 * ink). As the heading travels up through the viewport (top edge at 100vh
 * down to 32vh) a progress value scrubs 0 -> 1 and this component writes
 * two interpolated custom properties:
 *
 *   --pg-bg   page canvas  #FFFFFF -> #0D0B0A  (eased with the scroll)
 *   --pg-fg   canvas text  #0D0B0A -> #FFFFFF  (steeper curve that
 *                             crosses while the canvas is mid-gray, so
 *                             text and background never disagree long)
 *
 * PERFORMANCE (Task 33): the properties are written on the dark-zone
 * section elements themselves (.theme-canvas + any .theme-fg/#our-work-title
 * outside one), NOT on <html>. A custom-property write on the root would
 * invalidate style for the entire document on every scrubbed frame — hero
 * scenery included, which never consumes the vars. Scoping to the three
 * consuming sections keeps each frame's recalc inside those subtrees only,
 * with identical computed values (the sections own the vars their rules
 * already resolve).
 *
 * The rAF loop also SLEEPS when the transition is fully settled (chase
 * converged AND no write happened) and is re-armed by scroll / resize /
 * fonts.ready / an IntersectionObserver with a 200% rootMargin around the
 * heading. Progress stays a pure function of the heading's position, so
 * scrolling back up replays the transition in reverse exactly as before —
 * no state to desync, nothing to flicker.
 *
 * prefers-reduced-motion swaps the scrub for a snapped threshold with
 * hysteresis: colors change as state, not as animation.
 *
 * The first frame snaps disp to the measured target so a deep-scrolled
 * reload never flashes the light theme. */
export function ThemeTransition() {
  useEffect(() => {
    const heading = document.getElementById("our-work-title");
    if (!heading) return;

    /* Var targets: the dark-zone canvases own both properties; any fg
       consumer outside a canvas (none today, future-proof) gets them too. */
    const canvases = Array.from(document.querySelectorAll<HTMLElement>(".theme-canvas"));
    const extras = Array.from(document.querySelectorAll<HTMLElement>(".theme-fg, #our-work-title")).filter(
      (el) => !el.closest(".theme-canvas"),
    );
    const targets = [...canvases, ...extras];
    if (!targets.length) return;

    const reduce = matchMedia("(prefers-reduced-motion: reduce)");
    const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
    const smooth = (t: number) => t * t * (3 - 2 * t);
    const mix = (a: number, b: number, t: number) => Math.round(a + (b - a) * t);
    const rgb = (r: number, g: number, b: number) => `rgb(${r} ${g} ${b})`;

    let lastBg = "";
    let lastFg = "";
    const apply = (t: number) => {
      const bgT = smooth(t);
      const fgT = smooth(clamp01((bgT - 0.38) / 0.24));
      const bg = rgb(mix(255, 13, bgT), mix(255, 11, bgT), mix(255, 10, bgT));
      const fg = rgb(mix(13, 255, fgT), mix(11, 255, fgT), mix(10, 255, fgT));
      if (bg === lastBg && fg === lastFg) return false;
      lastBg = bg;
      lastFg = fg;
      for (const el of targets) {
        el.style.setProperty("--pg-bg", bg);
        el.style.setProperty("--pg-fg", fg);
      }
      return true;
    };

    let disp = 0;
    let last = -1;
    let inited = false;
    let raf = 0;

    const frame = () => {
      raf = 0;
      const vh = innerHeight;
      const top = heading.getBoundingClientRect().top;
      /* 0 while the heading is at/below the viewport bottom, 1 once it
         reaches its upper resting area (32vh) — 68vh of travel total. */
      const target = clamp01((vh - top) / (vh * 0.68));
      if (!inited) {
        inited = true;
        disp = target;
      }
      if (reduce.matches) {
        const next = disp >= 0.5 ? (target > 0.42 ? 1 : 0) : (target > 0.58 ? 1 : 0);
        if (next !== disp) disp = next;
      } else {
        disp += (target - disp) * 0.25;
        if (Math.abs(target - disp) < 0.0005) disp = target;
      }
      const changed = Math.abs(disp - last) >= 0.0005;
      if (changed) {
        apply(disp); // internally dedupes identical color strings
        last = disp;
      }
      /* Sleep when settled: progress is a pure function of the heading's
         position, which only changes through scroll/resize/layout events —
         all of which re-arm the loop below. */
      if (!changed && Math.abs(target - disp) < 0.0005) return;
      raf = requestAnimationFrame(frame);
    };
    const wake = () => {
      if (!raf) raf = requestAnimationFrame(frame);
    };

    addEventListener("scroll", wake, { passive: true });
    addEventListener("resize", wake);
    document.fonts?.ready.then(wake).catch(() => undefined);
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) wake();
      },
      { rootMargin: "200% 0px" },
    );
    io.observe(heading);
    wake();

    return () => {
      if (raf) cancelAnimationFrame(raf);
      removeEventListener("scroll", wake);
      removeEventListener("resize", wake);
      io.disconnect();
    };
  }, []);
  return null;
}
