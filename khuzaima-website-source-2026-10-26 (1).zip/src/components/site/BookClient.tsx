"use client";

import { useEffect, useLayoutEffect, useRef } from "react";
import Link from "next/link";
import { Header, Cursor } from "@/components/site/Chrome";
import { BookingWidget } from "@/components/site/BookingWidget";
import { gsap, MOTION_OK } from "@/lib/motion";
import { site } from "@/site.config";

const AGENDA = [
  { time: "0–3 min", title: "Quick hellos", copy: "Who you are, what you run, and how your week usually looks. No slide decks, ever.", chip: "bg-coral text-paper" },
  { time: "3–8 min", title: "Walk us through it", copy: "Where inquiries arrive today — calls, WhatsApp, walk-ins — and where things quietly slip through.", chip: "bg-sun text-ink" },
  { time: "8–13 min", title: "Live sketching", copy: "We map which parts an AI assistant could handle right away, and which ones need a human touch.", chip: "bg-aqua text-ink" },
  { time: "13–15 min", title: "Your call, literally", copy: "Next steps if it's a fit, or a friendly goodbye. Either way, the sketch is yours to keep.", chip: "bg-flamingo text-paper" },
];

const AUDIENCES = [
  {
    tag: "For clinics",
    title: "Front-desk relief",
    copy: "Patients ask the same eight questions at 11 pm. Your front desk answers them at 9 am — if nothing gets lost overnight.",
    points: ["Answers while the front desk sleeps", "Appointment booking inside the chat", "Fewer phone-tag loops and no-shows"],
    bg: "bg-mint",
  },
  {
    tag: "For real estate",
    title: "Inbox zero, showings full",
    copy: "Portal leads go cold in fifteen minutes. An assistant replies in fifteen seconds, qualifies, and puts viewings on the calendar.",
    points: ["Every portal lead answered instantly", "Budget and area qualified automatically", "Viewings booked while you're showing"],
    bg: "bg-lilac",
  },
];

const FAQ = [
  { q: "Is it really free?", a: "Yes. No invoice, no card, and no free-trial-that-quietly-bills-you. We take these calls because they're genuinely useful — most people leave with a plan they can act on themselves." },
  { q: "What if I'm not technical?", a: "Perfect — the call happens in plain language. If we mention a tool, we'll show it working first. You never need to install or configure anything to understand what's possible." },
  { q: "What happens afterwards?", a: "You get a one-page summary of everything we sketched. If there's a fit, we'll propose a small pilot. If not, the sketch is yours to keep and use with anyone." },
  { q: "Can I reschedule?", a: "Life happens. Reply to the confirmation email or message us on WhatsApp and we'll find a new slot — even at the last minute." },
];

const MARQUEE_WORDS = ["Free 15-minute call", "Real answers", "No pitch", "No obligation", "Booked in 60 seconds", "Leave with a plan"];

function Star4({ className = "size-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M12 1.8l2.5 7.7 7.7 2.5-7.7 2.5L12 22.2l-2.5-7.7-7.7-2.5 7.7-2.5L12 1.8z" />
    </svg>
  );
}

function WaveSquiggle({ className = "size-16" }: { className?: string }) {
  return (
    <svg viewBox="0 0 96 40" className={className} fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" aria-hidden>
      <path d="M4 20c8-14 16-14 24 0s16 14 24 0 16-14 24 0 16 14 20 4" />
    </svg>
  );
}

function Flower({ className = "size-14" }: { className?: string }) {
  // Round trig to 2dp: Node and V8-browser Math.sin can differ in the last bits,
  // which would trip hydration attribute checks.
  const R = (n: number) => Math.round(n * 100) / 100;
  const petals = Array.from({ length: 6 }).map((_, i) => (i * 60 * Math.PI) / 180);
  return (
    <svg viewBox="0 0 80 80" className={className} aria-hidden>
      {petals.map((a, i) => {
        const cx = R(40 + 20 * Math.cos(a));
        const cy = R(40 + 20 * Math.sin(a));
        return (
          <ellipse key={i} cx={cx} cy={cy} rx="12" ry="18"
            transform={`rotate(${R((a * 180) / Math.PI + 90)} ${cx} ${cy})`}
            fill={i % 2 ? "var(--flamingo)" : "var(--coral)"} opacity="0.9" />
        );
      })}
      <circle cx="40" cy="40" r="9" fill="var(--sun)" />
    </svg>
  );
}

export function BookClient() {
  const root = useRef<HTMLDivElement>(null);

  // Native smooth scrolling for in-page anchors (Lenis isn't mounted on this page).
  useEffect(() => {
    const html = document.documentElement;
    html.style.scrollBehavior = "smooth";
    return () => { html.style.scrollBehavior = ""; };
  }, []);

  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      const mm = gsap.matchMedia();
      mm.add(MOTION_OK, () => {
        gsap.timeline({ defaults: { ease: "power3.out" } })
          .from("[data-a=badge]", { y: 14, opacity: 0, duration: 0.5 }, 0.1)
          .from("[data-a=h] > span", { yPercent: 115, duration: 0.9, stagger: 0.1 }, 0.18)
          .from("[data-a=sun]", { scale: 0.55, opacity: 0, duration: 1.2, ease: "expo.out" }, 0.25)
          .from("[data-a=p]", { y: 16, opacity: 0, duration: 0.5 }, 0.5)
          .from("[data-a=cta] > *", { y: 14, opacity: 0, stagger: 0.08, duration: 0.45 }, 0.6)
          .from("[data-a=sticker]", { scale: 0, opacity: 0, duration: 0.7, ease: "back.out(2)", stagger: 0.09 }, 0.85)
          .from("[data-a=stats] > *", { y: 12, opacity: 0, stagger: 0.07, duration: 0.4 }, 0.95);
        el.querySelectorAll("[data-rv]").forEach((node) => {
          gsap.from(node, {
            y: 30, opacity: 0, duration: 0.85, ease: "power3.out",
            scrollTrigger: { trigger: node, start: "top 88%" },
          });
        });
      });
    }, el);
    return () => ctx.revert();
  }, []);

  const jump = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      {/* Fixed glass navbar lives at the page root, outside the clipped
          wrapper — an ancestor with overflow clipping must never sit between
          the backdrop blur and the page it samples. The wrapper's top padding
          replaces the flow space the old sticky header occupied. */}
      <Header />
      <div ref={root} data-nav-theme="light" className="overflow-x-clip bg-summer pt-[var(--nav-h)] text-ink selection:bg-sun selection:text-ink">
        <a href="#main" className="sr-only z-[80] rounded-full bg-sun px-4 py-2 text-ink focus:not-sr-only focus:fixed focus:left-4 focus:top-4">
          Skip to content
        </a>
        <Cursor />
        <main id="main">

        {/* ————— HERO ————— */}
        <section className="relative flex min-h-dvh flex-col justify-center overflow-hidden pt-28 pb-16 md:pt-32">
          {/* drifting gradient orbs */}
          <div aria-hidden className="absolute -left-48 top-24 size-[38vw] min-w-72 rounded-full bg-coral/30 blur-[110px] orb-drift" style={{ "--orb-dur": "17s", "--dx": "5%", "--dy": "4%" } as React.CSSProperties} />
          <div aria-hidden className="absolute bottom-[-10vw] left-[22%] size-[30vw] min-w-64 rounded-full bg-flamingo/25 blur-[100px] orb-drift" style={{ "--orb-dur": "21s", "--orb-delay": "-6s", "--dx": "-4%", "--dy": "-5%" } as React.CSSProperties} />
          <div aria-hidden className="absolute right-[8%] bottom-[6%] size-[24vw] min-w-56 rounded-full bg-aqua/30 blur-[90px] orb-drift" style={{ "--orb-dur": "14s", "--orb-delay": "-3s", "--dx": "4%", "--dy": "-4%" } as React.CSSProperties} />

          {/* the summer sun */}
          <div data-a="sun" aria-hidden className="absolute -right-[10vw] top-[7vh] z-0 size-[clamp(170px,26vw,400px)] md:-right-[6vw]">
            <svg viewBox="0 0 200 200" className="size-full">
              <g className="sun-rays" stroke="var(--tangerine)" strokeWidth="5" strokeLinecap="round" opacity="0.85">
                {Array.from({ length: 14 }).map((_, i) => {
                  const a = (i * (360 / 14) * Math.PI) / 180;
                  const r1 = 74, r2 = i % 2 ? 86 : 94;
                  const R = (n: number) => Math.round(n * 100) / 100;
                  return <line key={i} x1={R(100 + r1 * Math.cos(a))} y1={R(100 + r1 * Math.sin(a))} x2={R(100 + r2 * Math.cos(a))} y2={R(100 + r2 * Math.sin(a))} />;
                })}
              </g>
              <circle cx="100" cy="100" r="62" fill="var(--sun)" />
              <circle cx="100" cy="100" r="62" fill="none" stroke="var(--tangerine)" strokeWidth="3" opacity="0.5" />
            </svg>
          </div>

          {/* floating stickers */}
          <div data-a="sticker" aria-hidden className="sticker-bob absolute left-[6%] top-[22%] hidden text-coral md:block" style={{ "--rot": "-6deg", "--bob-dur": "5.5s" } as React.CSSProperties}><Star4 className="size-9" /></div>
          <div data-a="sticker" aria-hidden className="sticker-bob absolute left-[16%] top-[62%] hidden text-aqua md:block" style={{ "--rot": "5deg", "--bob-dur": "7s", "--bob-delay": "-2s" } as React.CSSProperties}><WaveSquiggle className="w-20" /></div>
          <div data-a="sticker" aria-hidden className="sticker-bob absolute right-[26%] top-[14%] hidden md:block" style={{ "--rot": "8deg", "--bob-dur": "6.2s", "--bob-delay": "-4s" } as React.CSSProperties}><Flower className="size-14" /></div>
          <div data-a="sticker" aria-hidden className="sticker-bob absolute bottom-[18%] right-[14%] hidden text-tangerine md:block" style={{ "--rot": "-5deg", "--bob-dur": "6.8s", "--bob-delay": "-1s" } as React.CSSProperties}><Star4 className="size-6" /></div>

          <div className="grain" aria-hidden />

          <div className="container-site relative z-10">
            <p data-a="badge" className="mb-6 inline-flex items-center gap-2.5 rounded-full border border-ink/15 bg-paper/70 py-2 pl-3 pr-5 text-sm font-semibold backdrop-blur">
              <span className="relative flex size-2.5"><span className="absolute inline-flex size-full animate-ping rounded-full bg-coral opacity-60" /><span className="relative inline-flex size-2.5 rounded-full bg-coral" /></span>
              Free &middot; 15 minutes &middot; Zero pitch
            </p>
            <h1 data-a="h" className="max-w-[13ch] text-[clamp(3rem,9.5vw,8.25rem)] font-extrabold">
              <span className="reveal-line"><span>Book a free</span></span>
              <span className="reveal-line"><span>
                <em className="mb-1 inline-block -rotate-2 rounded-[0.4em] bg-sun px-[0.28em] not-italic shadow-[0.12em_0.12em_0_var(--ink)]">15-minute</em> call.
              </span></span>
            </h1>
            <p data-a="p" className="mt-7 max-w-[54ch] text-lg text-ink/75 md:text-xl">
              Tell us where your inquiries pile up — WhatsApp, missed calls, that inbox nobody opens.
              Leave with a clear next step, not a sales pitch.
            </p>
            <div data-a="cta" className="mt-9 flex flex-wrap items-center gap-4">
              <a href="#book" onClick={jump("book")} data-cursor="book" className="btn-pill text-base">Grab a slot<Star4 className="ml-2 size-4" /></a>
              <a href="#agenda" onClick={jump("agenda")} className="btn-ghost">How the call runs</a>
            </div>
            <dl data-a="stats" className="mt-16 grid max-w-2xl grid-cols-3 divide-x divide-ink/12">
              {[["60s", "to book a slot"], ["15 min", "of your time, total"], ["0", "pitches, ever"]].map(([v, l]) => (
                <div key={l} className="px-5 first:pl-0">
                  <dt className="font-display text-3xl font-extrabold md:text-4xl">{v}</dt>
                  <dd className="mt-1 text-sm text-ink/60">{l}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        {/* ————— MARQUEE ————— */}
        <section aria-hidden className="relative z-10 -my-3 -rotate-[1.3deg] scale-[1.03] overflow-hidden border-y-2 border-ink bg-sun py-4">
          <div className="marquee-track flex w-max" style={{ "--marquee-dur": "24s" } as React.CSSProperties}>
            {[0, 1].map((half) => (
              <div key={half} className="flex items-center gap-10 pr-10">
                {MARQUEE_WORDS.map((w) => (
                  <span key={w} className="flex items-center gap-10 whitespace-nowrap font-display text-lg font-bold uppercase tracking-tight text-ink">
                    {w} <Star4 className="size-4 text-coral" />
                  </span>
                ))}
              </div>
            ))}
          </div>
        </section>

        {/* ————— AGENDA ————— */}
        <section id="agenda" className="container-site scroll-mt-24 py-24 md:py-32">
          <div data-rv className="mb-12 flex flex-wrap items-end justify-between gap-6 md:mb-14">
            <h2 className="h2-fluid font-extrabold">The 15 minutes,<br />mapped.</h2>
            <p className="max-w-sm text-lg text-ink/70">
              A tight, friendly agenda — so you know exactly what you&rsquo;re saying yes to before you say it.
            </p>
          </div>
          <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {AGENDA.map((a, i) => (
              <li key={a.title} data-rv className="group relative flex flex-col overflow-hidden rounded-panel border border-ink/10 bg-paper p-6 pt-7 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_24px_48px_-24px_rgba(23,23,58,0.3)]">
                <span aria-hidden className="pointer-events-none absolute -right-2 -top-5 font-display text-[7rem] font-extrabold leading-none text-ink/6 transition-colors duration-300 group-hover:text-ink/10">{`0${i + 1}`}</span>
                <span className={`w-fit rounded-full px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider ${a.chip}`}>{a.time}</span>
                <h3 className="mt-4 font-display text-2xl font-extrabold">{a.title}</h3>
                <p className="mt-2.5 text-[15px] leading-relaxed text-ink/70">{a.copy}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* ————— BOOKING WIDGET ————— */}
        <section id="book" className="relative scroll-mt-20 overflow-hidden pb-24 pt-4 md:pb-32">
          <div aria-hidden className="absolute left-1/2 top-24 -z-10 size-[46vw] min-w-96 -translate-x-1/2 rounded-full bg-aqua/20 blur-[130px] orb-drift" style={{ "--orb-dur": "19s", "--dx": "-3%", "--dy": "3%" } as React.CSSProperties} />
          <div className="container-site">
            <div data-rv className="mx-auto mb-10 max-w-2xl text-center md:mb-14">
              <p className="mb-4 inline-block rounded-full bg-ink px-4 py-1.5 text-xs font-bold uppercase tracking-[0.16em] text-sun">Three taps and you&rsquo;re in</p>
              <h2 className="h2-fluid font-extrabold">Grab your slot.</h2>
              <p className="mt-4 text-lg text-ink/70">
                Pick a day, pick a time, tell us who you are. That&rsquo;s the whole form — it really takes about sixty seconds.
              </p>
            </div>
            <div data-rv>
              <BookingWidget />
            </div>
          </div>
        </section>

        {/* ————— MADE FOR ————— */}
        <section className="container-site pb-24 md:pb-32">
          <div data-rv className="mb-12 md:mb-14">
            <h2 className="h2-fluid font-extrabold">Made for busy teams<br />in clinics &amp; real estate.</h2>
          </div>
          <div className="grid gap-5 lg:grid-cols-2">
            {AUDIENCES.map((a) => (
              <article key={a.tag} data-rv className={`group relative flex flex-col overflow-hidden rounded-panel p-8 transition-transform duration-300 hover:-translate-y-1.5 md:p-10 ${a.bg} text-ink`}>
                <Star4 className="absolute -right-4 -top-4 size-28 opacity-15 transition-transform duration-500 group-hover:rotate-90 group-hover:scale-110" />
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-ink/60">{a.tag}</p>
                <h3 className="mt-3 max-w-[16ch] font-display text-3xl font-extrabold md:text-4xl">{a.title}</h3>
                <p className="mt-4 max-w-[48ch] text-ink/75">{a.copy}</p>
                <ul className="mt-6 space-y-2.5">
                  {a.points.map((p) => (
                    <li key={p} className="flex items-start gap-3 font-medium">
                      <svg viewBox="0 0 24 24" className="mt-1 size-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M4 12.5l5 5L20 6.5" /></svg>
                      {p}
                    </li>
                  ))}
                </ul>
                <a href="#book" onClick={jump("book")} className="mt-8 inline-flex w-fit items-center gap-2 font-display text-lg font-bold underline decoration-2 underline-offset-4 transition-transform duration-200 hover:scale-[1.03]">
                  Book a slot for your {a.tag.includes("clinics") ? "clinic" : "team"}
                  <svg viewBox="0 0 24 24" className="size-5 transition-transform duration-200 group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden><path d="M4 12h16m-6-6l6 6-6 6" /></svg>
                </a>
              </article>
            ))}
          </div>
        </section>

        {/* ————— FAQ + FOOTER (summer evening) ————— */}
        <div data-nav-theme="dark" className="rounded-t-[clamp(2rem,6vw,4rem)] bg-ink pb-14 pt-20 text-paper md:pt-28">
          <section className="container-site" aria-labelledby="faq-title">
            <div data-rv className="mb-10 flex flex-wrap items-end justify-between gap-6 md:mb-12">
              <h2 id="faq-title" className="h2-fluid font-extrabold text-paper">Before you ask.</h2>
              <p className="max-w-xs text-paper/60">The four things everyone wonders about a &ldquo;free&rdquo; call.</p>
            </div>
            <div data-rv className="grid gap-3 lg:grid-cols-2">
              {FAQ.map((f) => (
                <details key={f.q} className="group rounded-[22px] border border-paper/15 bg-paper/5 p-5 transition-colors duration-200 open:bg-paper/10 [&_summary::-webkit-details-marker]:hidden">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-lg font-bold">
                    {f.q}
                    <span className="grid size-8 shrink-0 place-items-center rounded-full border border-paper/25 text-paper/80 transition-transform duration-300 group-open:rotate-45">
                      <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden><path d="M12 5v14M5 12h14" /></svg>
                    </span>
                  </summary>
                  <p className="mt-3 leading-relaxed text-paper/70">{f.a}</p>
                </details>
              ))}
            </div>
          </section>

          <footer className="container-site mt-20 md:mt-28">
            <div className="flex flex-wrap items-end justify-between gap-8">
              <div>
                <h2 className="max-w-[14ch] font-display text-[clamp(2.5rem,7vw,6rem)] font-extrabold leading-[0.95] text-paper">
                  See you on<br />the call.
                </h2>
                <p className="mt-6 max-w-[44ch] text-paper/70">
                  Still thinking it over? The slot costs sixty seconds to grab and nothing but fifteen minutes of your day.
                </p>
              </div>
              <div className="flex flex-col items-start gap-4">
                <a href="#book" onClick={jump("book")} data-cursor="book" className="btn-pill bg-sun text-ink hover:!bg-paper">Book my free call</a>
                <Link href="/" className="font-semibold text-paper/75 underline underline-offset-4 transition-colors hover:text-sun">Back to home</Link>
                <a href={`mailto:${site.email}`} className="font-semibold text-paper/75 underline underline-offset-4 transition-colors hover:text-sun">{site.email}</a>
              </div>
            </div>
            <p className="mt-16 border-t border-paper/12 pt-6 text-sm text-paper/45">
              {site.name} &mdash; {site.location}. Serving clinics and real estate teams in Pakistan and the UAE.
            </p>
          </footer>
        </div>
      </main>
      </div>
    </>
  );
}
