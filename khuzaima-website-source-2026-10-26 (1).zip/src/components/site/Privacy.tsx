import { useEffect, useRef } from "react";
import { gsap, MOTION_OK } from "@/lib/motion";
import { site } from "@/site.config";

export function Privacy() {
  const root = useRef<HTMLElement>(null);
  const text = `The assistants we build don\u2019t give medical advice, and they only handle the information your business approves. A person confirms every booking. ${site.shortName} leads the work and is studying AI Security and Cyber Intelligence, so permissions, data handling and safe behaviour are part of every design from day one.`;
  useEffect(() => {
    const el = root.current!;
    const mm = gsap.matchMedia();
    mm.add(MOTION_OK, () => {
      gsap.fromTo(el.querySelectorAll("[data-w]"), { opacity: 0.15 }, {
        opacity: 1, stagger: 0.1, ease: "none",
        scrollTrigger: { trigger: el.querySelector("p"), start: "top 80%", end: "bottom 45%", scrub: true },
      });
    });
    return () => mm.revert();
  }, []);
  return (
    <section ref={root} id="about" aria-labelledby="privacy-title" data-nav-theme="dark" className="theme-canvas py-32 theme-fg">
      <div className="container-site">
        <h2 id="privacy-title" className="mb-10 font-display text-2xl font-bold">Safe by design</h2>
        <p className="max-w-[30ch] font-display text-[clamp(1.75rem,4.4vw,3.75rem)] font-semibold leading-[1.1] tracking-[-0.02em]" aria-label={text}>
          {text.split(" ").map((w, i) => (
            <span key={i} aria-hidden><span data-w>{w}</span> </span>
          ))}
        </p>
      </div>
    </section>
  );
}