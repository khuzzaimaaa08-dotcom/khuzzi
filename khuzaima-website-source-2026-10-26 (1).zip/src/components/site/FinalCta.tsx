import { useEffect, useRef } from "react";
import Link from "next/link";
import { gsap, MOTION_OK } from "@/lib/motion";
import { site } from "@/site.config";
import { Magnetic } from "./Magnetic";

export function FinalCta() {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = root.current!;
    const mm = gsap.matchMedia();
    mm.add(MOTION_OK, () => {
      el.querySelectorAll(".reveal-line > span").forEach((s) =>
        gsap.from(s, { yPercent: 110, duration: 1, ease: "power3.out", scrollTrigger: { trigger: s, start: "top 90%" } }));
      gsap.fromTo("[data-wordmark]", { clipPath: "inset(0 100% 0 0)" }, {
        clipPath: "inset(0 0% 0 0)", ease: "none",
        scrollTrigger: { trigger: "[data-wordmark]", start: "top bottom", end: "bottom bottom", scrub: true },
      });
    });
    return () => mm.revert();
  }, []);

  return (
    <div ref={root}>
      <section id="contact" aria-labelledby="cta-title" data-nav-theme="light" className="bg-tangerine py-32 text-center text-ink">
        <div className="container-site">
          <h2 id="cta-title" className="mx-auto max-w-[14ch] text-[clamp(2.75rem,8vw,7.5rem)] font-extrabold">
            <span className="reveal-line"><span>Let&rsquo;s look at your</span></span>
            <span className="reveal-line"><span>inquiries together.</span></span>
          </h2>
          <p className="mx-auto mt-8 max-w-[52ch] text-lg">
            Tell us what you run and where messages pile up. We&rsquo;ll reply within one working day.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Magnetic><Link href="/book" data-cursor="book" className="btn-pill">Book a free 15-minute call</Link></Magnetic>
            <a href={site.whatsapp} target="_blank" rel="noopener noreferrer" className="btn-ghost hover:!bg-ink hover:!text-paper hover:!border-ink">Message on WhatsApp</a>
          </div>
        </div>
      </section>
      <footer data-nav-theme="dark" className="overflow-hidden bg-ink pt-20 text-paper">
        <div className="container-site">
          <p className="max-w-[46ch] text-paper/85">{site.location}. Serving clinics and real estate teams in Pakistan and the UAE.</p>
          <p className="mt-2 text-paper/85"><a className="underline underline-offset-4 hover:text-mint" href={`mailto:${site.email}`}>{site.email}</a></p>
        </div>
        <p data-wordmark aria-hidden className="mt-10 whitespace-nowrap px-[2vw] font-display text-[15.5vw] font-extrabold leading-[0.8] tracking-[-0.05em] text-ultramarine">
          {site.name}
        </p>
      </footer>
    </div>
  );
}