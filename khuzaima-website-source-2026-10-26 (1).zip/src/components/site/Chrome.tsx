import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Lenis from "lenis";
import { gsap, ScrollTrigger } from "@/lib/motion";
import { site } from "@/site.config";

/* Main navigation v2 — full-width edge-to-edge glass bar. Fixed to the
   viewport at the page root (never inside the pinned hero or any
   transformed/filtered wrapper, so backdrop-filter keeps sampling the real
   page behind it). Transparent at the very top of a page (data-size=
   "expanded"), compacting to data-size="compact" once scrolled past 32px
   (hysteresis: back to expanded only below 8px), when the progressive
   backdrop blur engages — four stacked masked layers (.nav-blur, strongest
   at the top, dissolving over ~56px below the bar; see globals.css).
   Contrast comes from the adaptive theme: data-theme="dark|light" flips
   foreground colors and inverts the CTA pill, decided by an
   IntersectionObserver that samples a 1px band at the bar's vertical
   center against every [data-nav-theme] section; inside the hero the
   theme follows the hero's own time-of-day tone (data-hero-tone, kept in
   sync with the is-night headline flip). The bar is permanently visible
   while scrolling — no hide-on-scroll, no scroll-direction detection, no
   scroll-triggered transforms. Pink "Huge"
   wordmark left, six matter links centered in the free space between
   wordmark and CTA (flex space-between), "Let's talk" pill right. Under
   md the links collapse into a menu button + glass drawer (scroll-locked,
   focus-trapped, Esc to close). */
const NAV_LINKS = [
  { label: "Work", href: "/#work" },
  { label: "Solutions", href: "/#services" },
  { label: "Approach", href: "/#start" },
  { label: "Company", href: "/#about" },
  { label: "Ideas", href: "/#manifesto" },
  { label: "Careers", href: "/#contact" },
] as const;

export function SmoothScroll() {
  useEffect(() => {
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const touch = matchMedia("(pointer: coarse)").matches;
    document.fonts?.ready.then(() => ScrollTrigger.refresh());
    if (reduce || touch) return;
    const lenis = new Lenis({ lerp: 0.1 });
    lenis.on("scroll", ScrollTrigger.update);
    const tick = (t: number) => lenis.raf(t * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);
    /* The mobile drawer freezes smooth scrolling while it is open (pages
       without Lenis just use the html overflow lock the drawer also sets). */
    const lock = (e: Event) =>
      (e as CustomEvent<boolean>).detail ? lenis.stop() : lenis.start();
    addEventListener("nav:lock", lock);
    return () => {
      removeEventListener("nav:lock", lock);
      gsap.ticker.remove(tick);
      lenis.destroy();
    };
  }, []);
  return null;
}

export function Header() {
  const head = useRef<HTMLElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  const progress = useRef<HTMLDivElement>(null);
  const menuBtn = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  const compactRef = useRef(false);

  /* One passive rAF-throttled scroll listener drives the reading-progress
     bar and the expanded ⇄ compact size (with hysteresis). The bar itself
     never hides — it stays pinned at the top through the entire scroll.
     scrollHeight is cached and only re-measured on resize / when close to
     the cached end, so the hot path never forces a layout (Task 33). */
  useEffect(() => {
    let raf = 0;
    let max = -1;
    let ticks = 0;
    const measure = () => {
      max = document.documentElement.scrollHeight - innerHeight;
    };
    measure();
    addEventListener("resize", measure);
    const on = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const y = window.scrollY;
        if (y > max - 2 || max < 0 || ++ticks % 128 === 0) measure(); // late loads can grow the page
        if (progress.current)
          progress.current.style.transform = `scaleX(${max > 0 ? y / max : 0})`;
        const compact = compactRef.current ? y >= 8 : y > 32;
        if (compact !== compactRef.current) {
          compactRef.current = compact;
          if (head.current) head.current.dataset.size = compact ? "compact" : "expanded";
        }
      });
    };
    addEventListener("scroll", on, { passive: true });
    on();
    return () => {
      removeEventListener("scroll", on);
      removeEventListener("resize", measure);
      cancelAnimationFrame(raf);
    };
  }, []);

  /* Adaptive theme: an IntersectionObserver whose rootMargin collapses the
     viewport to a 1px band at the navbar's vertical center — whichever
     [data-nav-theme] section covers that line decides whether the glass
     sits over a dark or a light background. The hero keeps its own
     data-nav-theme in sync with its time-of-day text tone, so a
     MutationObserver re-reads it while the hero pins under the bar. */
  useEffect(() => {
    const headerEl = head.current, barEl = bar.current;
    if (!headerEl || !barEl) return;
    const covering = new Set<Element>();
    const apply = () => {
      let current: Element | null = null;
      for (const el of covering) {
        if (!current ||
          (current.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0)
          current = el;
      }
      headerEl.dataset.theme =
        current?.getAttribute("data-nav-theme") === "dark" ? "dark" : "light";
    };
    let io: IntersectionObserver | null = null;
    const build = () => {
      io?.disconnect();
      covering.clear();
      const h = barEl.offsetHeight;
      io = new IntersectionObserver(
        (entries) => {
          for (const e of entries) {
            if (e.isIntersecting) covering.add(e.target);
            else covering.delete(e.target);
          }
          apply();
        },
        { rootMargin: `-${h / 2}px 0px -${innerHeight - h / 2 - 1}px 0px` },
      );
      document.querySelectorAll("[data-nav-theme]").forEach((el) => io!.observe(el));
    };
    build();
    const hero = document.querySelector("[data-hero-tone]");
    const mo = hero ? new MutationObserver(apply) : null;
    if (hero) mo?.observe(hero, { attributes: true, attributeFilter: ["data-nav-theme"] });
    addEventListener("resize", build);
    return () => {
      io?.disconnect();
      mo?.disconnect();
      removeEventListener("resize", build);
    };
  }, []);

  /* Mobile drawer: while open, the page is scroll-locked (html overflow +
     a nav:lock event for Lenis), Tab is trapped inside the header, and Esc
     closes (the pre-existing logic, hardened). */
  useEffect(() => {
    if (!open) return;
    const el = head.current;
    if (!el) return;
    const prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = "hidden";
    window.dispatchEvent(new CustomEvent("nav:lock", { detail: true }));
    const focusables = () =>
      Array.from(el.querySelectorAll<HTMLElement>("a[href], button:not([disabled])"))
        .filter((n) => n.offsetParent !== null);
    requestAnimationFrame(() =>
      focusables().find((n) => n.classList.contains("nav-drawer-link"))?.focus());
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        menuBtn.current?.focus();
        return;
      }
      if (e.key !== "Tab") return;
      const items = focusables();
      if (!items.length) return;
      const idx = items.indexOf(document.activeElement as HTMLElement);
      if (e.shiftKey && idx <= 0) {
        e.preventDefault();
        items[items.length - 1]!.focus();
      } else if (!e.shiftKey && idx === items.length - 1) {
        e.preventDefault();
        items[0]!.focus();
      }
    };
    addEventListener("keydown", onKey);
    return () => {
      removeEventListener("keydown", onKey);
      document.documentElement.style.overflow = prevOverflow;
      window.dispatchEvent(new CustomEvent("nav:lock", { detail: false }));
    };
  }, [open]);

  return (
    <>
      <div aria-hidden className="fixed inset-x-0 top-0 z-[60] h-1">
        <div ref={progress} className="h-full origin-left scale-x-0 bg-ultramarine" />
      </div>
      <header ref={head} className="site-head" data-size="expanded" data-theme="light">
        <div className="nav-blur" aria-hidden="true">
          <span /><span /><span /><span />
        </div>
        <div ref={bar} className="nav-bar">
          <Link href="/" className="nav-brand" aria-label={`${site.shortName} — home`}>
            Huge
          </Link>
          <nav aria-label="Primary" className="nav-links">
            {NAV_LINKS.map((l) => (
              <Link key={l.label} href={l.href} className="nav-link">
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="nav-end">
            <Link href="/book" data-cursor="book" className="nav-cta">
              Let’s talk
            </Link>
            <button
              ref={menuBtn}
              type="button"
              className="nav-menu-btn"
              aria-expanded={open}
              aria-controls="nav-drawer"
              onClick={() => setOpen((v) => !v)}
            >
              <span className="nav-menu-icon" aria-hidden="true">
                <span /><span />
              </span>
              <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
            </button>
          </div>
        </div>
        <div id="nav-drawer" className="nav-drawer" hidden={!open}>
          <nav aria-label="Primary" className="nav-drawer-links">
            {NAV_LINKS.map((l) => (
              <Link key={l.label} href={l.href} className="nav-drawer-link" onClick={() => setOpen(false)}>
                {l.label}
              </Link>
            ))}
          </nav>
          <Link href="/book" data-cursor="book" className="nav-drawer-cta" onClick={() => setOpen(false)}>
            Let’s talk
          </Link>
        </div>
      </header>
    </>
  );
}

export function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const label = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    if (!matchMedia("(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)").matches) return;
    const el = dot.current!;
    el.style.display = "grid";
    /* One persistent quickTo per property — pointermove re-targets the same
       tweens instead of allocating a fresh gsap.to per event (Task 33). */
    const x = gsap.quickTo(el, "x", { duration: 0.25, ease: "power3.out" });
    const y = gsap.quickTo(el, "y", { duration: 0.25, ease: "power3.out" });
    const s = gsap.quickTo(el, "scale", { duration: 0.3, ease: "power3.out" });
    let labelOn: boolean | null = null;
    const move = (e: PointerEvent) => {
      x(e.clientX); y(e.clientY);
      const t = e.target as HTMLElement;
      const book = t.closest("[data-cursor=book]");
      const inter = t.closest("a,button,[role=tab]");
      const field = t.closest("input,textarea,select");
      s(field ? 0 : book ? 6 : inter ? 3 : 1);
      const on = !!book;
      if (labelOn !== on) {
        labelOn = on;
        if (label.current) label.current.style.opacity = on ? "1" : "0";
      }
    };
    addEventListener("pointermove", move);
    return () => removeEventListener("pointermove", move);
  }, []);
  return (
    <div ref={dot} aria-hidden className="pointer-events-none fixed left-0 top-0 z-[70] hidden size-3 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-ink">
      <span ref={label} className="text-[3px] font-bold text-paper opacity-0">Book</span>
    </div>
  );
}
