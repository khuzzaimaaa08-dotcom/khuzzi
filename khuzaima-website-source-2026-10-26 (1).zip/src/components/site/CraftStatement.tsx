import { Fragment, useEffect, useRef } from "react";
import Link from "next/link";
import { gsap, MOTION_OK } from "@/lib/motion";

/* The craft statement, directly below the manifesto on the same white ground:
   the "Anyone can make." paragraph set as five line spans (the reference's
   five text spans) in the matter stack — 48px cap / 700 / tightened tracking
   and 0.98 leading, with generous space above via the section's own padding.
   Words rest a muted light grey and, as the section scrolls through the
   viewport, sweep through a five-stage color ramp — grey, pale pink, vibrant
   pink, deep burgundy, near-black — each word following the last in reading
   order. The sweep is scrub-linked strictly to scroll position, so scrolling
   back reverses it naturally; never a timer. The paragraph is plain DOM text
   colored near-black by default, so it reads correctly without JS and under
   reduced motion. */

const LINES = [
  "Anyone can make.",
  "Creating experiences that resonate",
  "with culture and business is the",
  "hard part. It takes design, tech",
  "and human judgment.",
];

/* Scroll-driven color ramp, per word in reading order: */
const GREY = "#D6D6D8"; // initial — muted light grey
const PALE = "#F3B6D5"; // early scroll — pale pink
const VIBRANT = "#FF0090"; // middle scroll — vibrant pink
const BURGUNDY = "#70143F"; // later scroll — deep burgundy
const FINAL = "#0D0B0A"; // final — near-black

const SEG = 1; // one color stage per timeline segment
const STAGGER = 0.5; // word-to-word cascade offset

/* The reference's vertical index beside the statement — matter 25px / 600 /
   27px line / -0.25px tracking / ink #0d0b0a, arrow after each label. On
   hover each glyph lifts out of a one-line mask while a pink duplicate
   (text-shadow cast one line below) rises into place, staggered 10ms per
   glyph over 0.6s cubic-bezier(0.625, 0.05, 0, 1) — the roll from the
   supplied reference styles. */
const LINKS = [
  { label: "See the work.", href: "/#how" },
  { label: "Discover our solutions.", href: "/#services" },
  { label: "Check our approach.", href: "/#start" },
  { label: "Latest ideas & news.", href: "/#about" },
  { label: "This is Huge.", href: "/#top" },
  { label: "Want to join us?", href: "/#contact" },
] as const;

export function CraftStatement() {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const words = gsap.utils.toArray<HTMLElement>(".craft-word", el);
    if (words.length === 0) return;

    const mm = gsap.matchMedia();

    mm.add(MOTION_OK, () => {
      // Scrub-linked cascade: each word runs the full five-stage ramp, the
      // next word trailing the previous by STAGGER, so the paragraph reads
      // as one continuous gradient wave while scrolling through the section.
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: el,
          start: "top 75%",
          end: "bottom 60%",
          scrub: 0.5,
        },
      });
      words.forEach((word, i) => {
        const at = i * STAGGER;
        tl.fromTo(
          word,
          { color: GREY },
          { color: PALE, duration: SEG, ease: "none" },
          at,
        )
          .to(word, { color: VIBRANT, duration: SEG, ease: "none" }, at + SEG)
          .to(word, { color: BURGUNDY, duration: SEG, ease: "none" }, at + SEG * 2)
          .to(word, { color: FINAL, duration: SEG, ease: "none" }, at + SEG * 3);
      });
    });

    return () => mm.revert();
  }, []);

  return (
    <section ref={root} id="craft" data-nav-theme="light" className="bg-white">
      <div className="container-site pt-[clamp(6rem,22vh,15rem)] pb-[clamp(6rem,16vh,11rem)]">
        <div className="flex flex-col gap-14 lg:flex-row lg:items-center lg:justify-between lg:gap-10">
          <p className="craft-text">
            {LINES.map((line) => (
              <span key={line} className="craft-line">
                {line.split(" ").map((word, i) => (
                  <Fragment key={i}>
                    {i > 0 && " "}
                    <span className="craft-word">{word}</span>
                  </Fragment>
                ))}
              </span>
            ))}
          </p>
          <nav aria-label="Explore" className="craft-links">
            {LINKS.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="craft-link"
                aria-label={link.label}
              >
                <span className="craft-link-roll" aria-hidden="true">
                  {link.label.split("").map((ch, i) => (
                    <span
                      key={i}
                      className="craft-link-char"
                      style={{ transitionDelay: `${i * 0.01}s` }}
                    >
                      {ch === " " ? "\u00A0" : ch}
                    </span>
                  ))}
                </span>
                <span className="craft-link-arrow" aria-hidden="true">→</span>
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </section>
  );
}
