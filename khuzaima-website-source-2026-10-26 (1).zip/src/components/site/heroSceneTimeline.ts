/**
 * Hero scenery timeline. Every timing is in clock minutes since midnight
 * (9:00 AM = 540). Scene state is a pure function of these minutes.
 */
export const SCENE = {
  start: 540, // 9:00 AM
  birdsDriftEnd: 900, // 3:00 PM, exit sweep begins
  exitEnd: 957, // 3:57 PM, birds + clouds fully gone
  cloudRevealStart: 690, // 11:30 AM
  cloudRevealDur: 60,
  cloudStagger: 15,
  starsStart: 1020, // 5:00 PM
  starsProminent: 1200, // 8:00 PM
  starsFull: 1320, // 10:00 PM
  starsAppearEnd: 1290, // 9:30 PM
  starFade: 45,
  sparklesStart: 1260,
  trunk: [1320, 1355] as const, // 10:00 to 10:35 PM
  primary: [1345, 1380] as const, // 10:25 to 11:00 PM
  twigs: [1370, 1395] as const, // 10:50 to 11:15 PM
  owlsStart: 1390, // 11:10 PM
  owlDur: 8,
  owlStagger: 6,
  owlsSettled: 1410, // 11:30 PM
};

export const clamp01 = (t: number) => (t < 0 ? 0 : t > 1 ? 1 : t);
export const ramp = (a: number, b: number, m: number) => clamp01((m - a) / (b - a));
export const smooth = (t: number) => t * t * (3 - 2 * t);
export const easeIn = (t: number) => t * t * t;
export const easeOut = (t: number) => 1 - (1 - t) ** 3;
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** back-out with ~4% overshoot */
export const backOut = (t: number) => { const c = 0.6; const u = t - 1; return 1 + (c + 1) * u ** 3 + c * u ** 2; };

export function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** "HH:MM" (24h) to clock minutes. */
export const at = (hhmm: string) => { const [h, m] = hhmm.split(":").map(Number); return (h ?? 0) * 60 + (m ?? 0); };

/**
 * Afternoon to dusk layers (HeroSkyLayers). Retune timing and placement here.
 * Positions are % of the hero box [x, y]. `fade` is minutes of smooth fade at each end.
 * Everything is gone by `allGone`, so 8:00 PM onward is untouched.
 */
export const SKY = {
  /** Clouds + birds exit is SCENE.exitEnd (3:57 PM). Balloon + jet start there. */
  balloon: { in: at("15:57"), full: at("16:25"), vanish: at("16:50"), out: at("17:15"), from: [64, 105], to: [72, 38], vanishScale: 0.75, mobileFrom: [70, 105], mobileTo: [78, 30] },
  plane: { in: at("15:57"), full: at("16:25"), vanish: at("16:55"), out: at("17:15"), from: [-4, 13], to: [78, 11], vanishScale: 0.8 },
  skyline: {
    hill: [at("16:05"), at("16:30")] as const, hillRise: 24,
    far: [at("16:10"), at("16:40")] as const, farDur: 21,
    near: [at("16:20"), at("17:00")] as const, nearDur: 22,
    farTravel: 0.6, // far buildings rise 0.6x their own height, near rise 1x
    sinkStart: at("19:48"), sinkEnd: at("20:00"), // downtown exit: spire + clinic first, hill last
    sinkDur: 6, // minutes each building takes to sink
  },
  glow: { in: at("17:00"), peak: at("18:30"), out: at("18:45"), fade: 25 },
  homeward: { in: at("17:15"), out: at("18:15"), fade: 10, x: [104, -14], y: [19, 24] },
  sunset: {
    in: at("18:15"), full: at("18:30"), duskIn: at("18:50"), duskFull: at("19:25"), fadeOut: at("19:25"), out: at("19:45"), travel: 20,
    items: [
      { x: 63, y: 25, size: 0.6, depth: 0.4, op: 0.65 },
      { x: 74, y: 32, size: 0.7, depth: 0.4, op: 0.7 },
      { x: 68, y: 44, size: 0.8, depth: 0.7, op: 0.8 },
      { x: 80, y: 54, size: 1, depth: 0.7, op: 0.75 },
      { x: 72, y: 64, size: 1.2, depth: 1, op: 0.85 },
    ],
  },
  evening: { in: at("19:10"), full: at("19:30"), fadeOut: at("19:50"), out: at("20:05"), x: 26, y: 17 },
  windows: { start: at("18:50"), half: at("19:20"), lastOn: at("19:45"), fade: 3, offStart: at("19:56"), out: at("20:00"), litFraction: 0.66 },
  allGone: at("20:00"),
};

export const sineInOut = (t: number) => 0.5 - 0.5 * Math.cos(Math.PI * clamp01(t));

/**
 * Winter aurora night, 8:00–9:30 pm. The aurora is a WebGL shader
 * (HeroAuroraCanvas) and the snowfall a Canvas 2D system (HeroSnowCanvas);
 * the hills, pines, cabin and sparkles below stay SVG/DOM. Everything is gone
 * by `out` (exactly 9:30 pm); 9:30–11:08 pm stays intentionally calm.
 * The actual measured text rects (1920×1080): headline x 19–63 / y 54–81,
 * clock x 69–81 / y 16–32, CTA x 67–81 / y 87–92 — the aurora box plus the
 * shared copy-safe mask keep the glow ≥ 24 px clear of all of them.
 */
export const WINTER = {
  aurora: {
    glimmer: at("19:56"), // 7:56 pm, intensity starts rising from 0
    at8: at("20:00"), at8Opacity: 0.4, // clearly visible (~40%) at exactly 8:00 pm
    full: at("20:20"), // fully luminous by 8:20 pm
    fadeOut: at("21:10"), out: at("21:30"), // smoothstep to 0, gone at exactly 9:30 pm
    drift: 1.5, // % of box width of gentle scroll parallax drift
    box: { left: 26, top: 8, width: 58, height: 38 }, // % of the hero box
    scale: 0.6, mobileScale: 0.45, // WebGL drawing-buffer scale (upscaled by CSS)
  },
  snow: {
    dpr: 1.5, // device pixel ratio cap (1 on mobile)
    /** Intensity keys [clock minutes, 0–1]; smoothstep between consecutive points. */
    curve: [
      [at("19:58"), 0], [at("20:00"), 0.18], [at("20:15"), 0.45],
      [at("20:30"), 0.8], [at("20:40"), 1], [at("21:08"), 1], [at("21:28"), 0],
    ] as const,
    wind: {
      base: 10, baseFreq: 0.07, // slow global drift, px/s
      gustDivisor: 1800, gustMax: 70, gustLerp: 3.5, // scroll gust: clamp(v/1800,-1,1) x 70 px/s
    },
    /** Peak counts at intensity 1: desktop 110+70+30+10 = 220, mobile 50+30+8+2 = 90. */
    classes: [
      { id: "far", depth: "far", count: 110, mobile: 50, size: [1.2, 2.2], alpha: [0.35, 0.55], fall: [35, 60], sway: [10, 18], wind: 0.6 },
      { id: "mid", depth: "far", count: 70, mobile: 30, size: [2.5, 4], alpha: [0.55, 0.8], fall: [70, 110], sway: [14, 22], wind: 1 },
      { id: "near", depth: "near", count: 30, mobile: 8, size: [5, 8], alpha: [0.5, 0.75], fall: [130, 190], sway: [18, 26], wind: 1.4, soft: true },
      { id: "glyph", depth: "near", count: 10, mobile: 2, size: [9, 13], alpha: [0.7, 0.9], fall: [50, 80], sway: [10, 16], wind: 1, spin: 40, glyph: true },
    ],
  },
  hills: {
    back: [at("19:56"), at("20:06")] as const, front: [at("19:58"), at("20:08")] as const,
    sinkFront: [at("21:12"), at("21:28")] as const, sinkBack: [at("21:14"), at("21:30")] as const, fade: 2,
  },
  pines: {
    riseDur: 5.5, sinkDur: 4, fade: 1.8,
    clusters: [
      { depth: "far", count: 3, x: [57, 63.5], vh: [6, 8], op: 0.28, start: at("19:58"), step: 1.5, exit: at("21:13.5") },
      { depth: "mid", count: 4, x: [67, 79], vh: [9, 13], op: 0.4, start: at("20:03"), step: 1.4, exit: at("21:11.5") },
      { depth: "near", count: 4, x: [82, 94.5], vh: [14, 19], op: 0.55, start: at("20:09"), step: 1.4, exit: at("21:10"), sway: 2 },
    ],
  },
  cabin: {
    rise: [at("20:08"), at("20:20")] as const, fade: 2,
    lightOn: at("20:20"), lightDur: 2, lightOff: [at("21:12"), at("21:20")] as const,
    sink: [at("21:12"), at("21:30")] as const,
    x: 57.5, vh: 9,
  },
  sparkles: { first: at("20:05"), last: at("21:05"), fadeDur: 5, out: [at("21:10"), at("21:30")] as const, count: 8 },
} as const;
export function auroraBrightness(m: number) {
  const A = WINTER.aurora;
  if (m <= A.glimmer || m >= A.out) return 0;
  if (m < A.at8) return A.at8Opacity * smooth(ramp(A.glimmer, A.at8, m));
  if (m < A.full) return lerp(A.at8Opacity, 1, smooth(ramp(A.at8, A.full, m)));
  if (m < A.fadeOut) return 1;
  return 1 - smooth(ramp(A.fadeOut, A.out, m));
}
/** Piecewise smoothstep through [clock minutes, value] key points. */
export function keyCurve(keys: readonly (readonly [number, number])[], m: number) {
  if (m <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (m < keys[i][0]) {
      const [t0, v0] = keys[i - 1];
      const [t1, v1] = keys[i];
      return lerp(v0, v1, smooth((m - t0) / (t1 - t0)));
    }
  }
  return keys[keys.length - 1][1];
}
export function snowAmount(m: number) {
  return keyCurve(WINTER.snow.curve, m);
}
export const BALLOONS = [
  { ...SKY.balloon, scale: 1, depth: 1, pattern: "stripes", sway: 3.8, phase: 0 },
  { in: at("16:08"), full: at("16:33"), vanish: at("16:50"), out: at("17:15"), from: [58, 108], to: [65, -8], mobileFrom: [24, 108], mobileTo: [24, 6], vanishScale: 0.75, scale: 0.7, depth: 0.7, pattern: "chevron", sway: 4.6, phase: -1.7 },
  { in: at("16:18"), full: at("16:43"), vanish: at("16:45"), out: at("17:15"), from: [76, 111], to: [83, 27], mobileFrom: [40, 111], mobileTo: [40, -24], vanishScale: 0.75, scale: 0.55, depth: 0.5, pattern: "diamonds", sway: 5.4, phase: -3.1 },
] as const;
export const envelope = (m: number, a: number, full: number, fade: number, out: number) => smooth(ramp(a, full, m)) * (1 - smooth(ramp(fade, out, m)));
export function balloonState(m: number, i: number, mobile = false) {
  const b = BALLOONS[i];
  if (!b) return { opacity: 0, x: 0, y: 0, scale: 0 };
  const from = mobile ? b.mobileFrom : b.from, to = mobile ? b.mobileTo : b.to;
  const t = sineInOut(ramp(b.in, b.out, m) ** 0.6);
  const mobileT = sineInOut(ramp(b.in, b.full, m));
  return { opacity: envelope(m, b.in, b.full, b.vanish, b.out), x: mobile && i === 0 ? 10 : lerp(from[0] ?? 0, to[0] ?? 0, t), y: mobile ? lerp(110, [20, 18, 23][i] ?? 20, mobileT) : lerp(from[1] ?? 0, to[1] ?? 0, t), scale: b.scale * (mobile ? 0.8 : 1) * lerp(1, b.vanishScale, smooth(ramp(b.vanish, b.out, m))) };
}
export function buildingOpacity(m: number) { return 1 - smooth(ramp(SKY.windows.offStart, SKY.windows.out, m)); }
export function lightOpacity(m: number, threshold: number, y: number) {
  const L = SKY.windows;
  const offAt = lerp(L.offStart, L.out - 0.8, ramp(6, 200, y));
  return smooth(ramp(threshold, threshold + L.fade, m)) * (1 - smooth(ramp(offAt, Math.min(L.out, offAt + 0.8), m)));
}
/** Slots follow each unchanged silhouette. Seeded selection lights 66% per building. */
const GRIDS = [
  { layer: "far", building: 0, x: 118, y: 74, cols: 3, rows: 5, dx: 15, dy: 24 },
  { layer: "far", building: 1, x: 330, y: 58, cols: 3, rows: 6, dx: 16, dy: 23 },
  { layer: "far", building: 2, x: 389, y: 123, cols: 2, rows: 3, dx: 16, dy: 24 },
  { layer: "far", building: 3, x: 600, y: 87, cols: 3, rows: 4, dx: 15, dy: 25 },
  { layer: "near", building: 0, x: 34, y: 164, cols: 2, rows: 1, dx: 25, dy: 20 },
  { layer: "near", building: 1, x: 303, y: 162, cols: 2, rows: 1, dx: 24, dy: 20 },
  { layer: "near", building: 2, x: 755, y: 166, cols: 2, rows: 1, dx: 24, dy: 20 },
  { layer: "near", building: 3, x: 208, y: 92, cols: 3, rows: 5, dx: 22, dy: 21 },
  { layer: "near", building: 4, x: 508, y: 109, cols: 3, rows: 4, dx: 24, dy: 23 },
  { layer: "near", building: 5, x: 435, y: 57, cols: 1, rows: 6, dx: 0, dy: 23 },
  { layer: "near", building: 6, x: 618, y: 171, cols: 6, rows: 1, dx: 16, dy: 20 },
] as const;
export const LIGHTS = GRIDS.flatMap((g, gi) => {
  const rng = mulberry32(610 + gi), count = g.cols * g.rows;
  const slots = Array.from({ length: count }, (_, i) => ({ i, order: rng(), tone: rng(), size: rng() }));
  const order = [...slots].sort((a, b) => a.order - b.order);
  const lit = Math.round(count * SKY.windows.litFraction);
  return slots.map((s) => {
    const rank = order.findIndex((o) => o.i === s.i);
    const q = rank / Math.max(1, lit - 1);
    const threshold = q <= 0.76 ? lerp(SKY.windows.start, SKY.windows.half, q / 0.76) : lerp(SKY.windows.half, SKY.windows.lastOn - SKY.windows.fade, (q - 0.76) / 0.24);
    return { layer: g.layer, building: g.building, x: g.x + (s.i % g.cols) * g.dx, y: g.y + Math.floor(s.i / g.cols) * g.dy, lit: rank < lit, mobile: s.i % 2 === 0, threshold: threshold + gi * 0.08, tone: s.tone < 0.7 ? "var(--sun)" : s.tone < 0.9 ? "var(--light-amber)" : "var(--paper)", width: 6 + s.size * 2 };
  });
});