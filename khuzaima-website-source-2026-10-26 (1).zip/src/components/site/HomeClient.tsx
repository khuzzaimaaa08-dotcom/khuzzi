"use client";

import { Header, SmoothScroll, Cursor } from "@/components/site/Chrome";
import { ThemeTransition } from "@/components/site/ThemeTransition";
import { Hero } from "@/components/site/Hero";
import { Manifesto } from "@/components/site/Manifesto";
import { ChatDemo } from "@/components/site/ChatDemo";
import { Services } from "@/components/site/Services";
import { Process } from "@/components/site/Process";
import { Privacy } from "@/components/site/Privacy";
import { CraftStatement } from "@/components/site/CraftStatement";
import { BrandShowcase } from "@/components/site/BrandShowcase";
import { OurWork } from "@/components/site/OurWork";
import { FinalCta } from "@/components/site/FinalCta";

export function HomeClient() {
  return (
    <>
      <a href="#main" className="sr-only z-[80] rounded-full bg-sun px-4 py-2 text-ink focus:not-sr-only focus:fixed focus:left-4 focus:top-4">
        Skip to content
      </a>
      <SmoothScroll />
      <ThemeTransition />
      <Cursor />
      <Header />
      <main id="main">
        <Hero />
        <Manifesto />
        <CraftStatement />
        <BrandShowcase />
        <OurWork />
        <ChatDemo />
        <Services />
        <Process />
        <Privacy />
      </main>
      <FinalCta />
    </>
  );
}
