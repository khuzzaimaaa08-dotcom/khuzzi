import { forwardRef, useCallback, useEffect, useImperativeHandle, useRef } from "react";
import { WINTER, ramp, smooth, lerp, easeOut, sineInOut, mulberry32, auroraBrightness, snowAmount } from "./heroSceneTimeline";
import { HIDDEN, show, useSceneBounds } from "./heroLayerTools";
import { winterFxState, wakeWinterFx } from "./heroWinterFx";
import { HeroAuroraCanvas } from "./HeroAuroraCanvas";
import { HeroSnowCanvas } from "./HeroSnowCanvas";

export type NightHandle = { update: (minutes: number, p: number) => void };

/* ---------- A3 pine art: 4 scalloped tiers + snow caps + trunk ---------- */
function buildPine(seed: number) {
  const rng = mulberry32(3100 + seed * 7);
  const jit = () => 0.9 + rng() * 0.2;
  const specs = [
    { apex: 98, base: 202, half: 44 * jit() },
    { apex: 62, base: 156, half: 34 * jit() },
    { apex: 30, base: 112, half: 25 * jit() },
    { apex: 4, base: 72, half: 17.5 * jit() },
  ];
  const tiers = specs.map(({ apex, base, half }) => {
    const h = base - apex, s = h * 0.06, by = base - s;
    const lx = 50 - half, rx = 50 + half, seg = (half * 2) / 3;
    const d = `M50 ${apex}` +
      `C${(50 - half * 0.55).toFixed(1)} ${(apex + h * 0.38).toFixed(1)} ${(lx + half * 0.06).toFixed(1)} ${(by - h * 0.16).toFixed(1)} ${lx.toFixed(1)} ${by.toFixed(1)}` +
      `q${(seg / 2).toFixed(1)} ${(s * 2.2).toFixed(1)} ${seg.toFixed(1)} 0`.repeat(3) +
      `C${(rx - half * 0.06).toFixed(1)} ${(by - h * 0.16).toFixed(1)} ${(50 + half * 0.55).toFixed(1)} ${(apex + h * 0.38).toFixed(1)} 50 ${apex}Z`;
    const capBase = apex + h * 0.3, ch = half * 0.29;
    const cap = `M50 ${apex}` +
      `C${(50 - ch * 0.6).toFixed(1)} ${(apex + h * 0.12).toFixed(1)} ${(50 - ch).toFixed(1)} ${capBase.toFixed(1)} ${(50 - ch).toFixed(1)} ${(capBase + 1).toFixed(1)}` +
      `q${(ch / 2).toFixed(1)} 3.4 ${ch.toFixed(1)} 1.4q${(ch / 2).toFixed(1)} 2.6 ${ch.toFixed(1)} -1.4` +
      `C${(50 + ch).toFixed(1)} ${capBase.toFixed(1)} ${(50 + ch * 0.6).toFixed(1)} ${(apex + h * 0.12).toFixed(1)} 50 ${apex}Z`;
    return { d, cap };
  });
  return { tiers, trunk: "M46.6 200h6.8v20h-6.8Z" };
}

/* ---------- static seeded placements (deterministic, SSR-stable) ---------- */
type PineCfg = { depth: string; op: number; x: number; vh: number; lean: number; start: number; exit: number; sway: { dur: number; delay: number } | null; art: ReturnType<typeof buildPine>; keep: boolean };
const PINES: PineCfg[] = WINTER.pines.clusters.flatMap((c, ci) => {
  const rng = mulberry32(20262 + ci * 13);
  return Array.from({ length: c.count }, (_, i) => {
    const t = c.count <= 1 ? 0.5 : i / (c.count - 1);
    const sway = "sway" in c && c.sway && i < c.sway ? { dur: 6 + rng() * 3, delay: -rng() * 6 } : null;
    return {
      depth: c.depth, op: c.op,
      x: lerp(c.x[0], c.x[1], t) + (rng() - 0.5) * 1.6,
      vh: lerp(c.vh[0], c.vh[1], rng()),
      lean: (rng() - 0.5) * 4,
      start: c.start + i * c.step,
      exit: c.exit + i * 0.45,
      sway, art: buildPine(ci * 10 + i),
      keep: i < 2,
    };
  });
});
const STAR_PATH = "M10 0C11 7 13 9 20 10C13 11 11 13 10 20C9 13 7 11 0 10C7 9 9 7 10 0Z";
const SPARKLES = (() => {
  const rng = mulberry32(20261018);
  const T = WINTER.sparkles;
  return Array.from({ length: T.count }, (_, i) => ({
    x: 31 + rng() * 33, y: 12 + rng() * 15, size: 9 + rng() * 4,
    in: lerp(T.first, T.last, i / Math.max(1, T.count - 1)),
    delay: -rng() * 4,
  }));
})();

export const HeroNightLayers = forwardRef<NightHandle>(function HeroNightLayers(_, ref) {
  const root = useRef<HTMLDivElement>(null);
  const hillBack = useRef<HTMLDivElement>(null);
  const hillFront = useRef<HTMLDivElement>(null);
  const pines = useRef<(HTMLDivElement | null)[]>([]);
  const cabin = useRef<HTMLDivElement>(null);
  const cabinWin = useRef<SVGRectElement>(null);
  const cabinGlow = useRef<SVGEllipseElement>(null);
  const sparkles = useRef<(HTMLSpanElement | null)[]>([]);
  const winterOn = useRef(false);
  const spanRef = useRef(1); // px of page scroll for 0..1 timeline progress
  const pPrev = useRef(0);
  const pTime = useRef(-1);
  const apply = useCallback((m: number, p: number) => {
    let active = false;

    // A1 aurora (WebGL shader) + A2 snowfall (Canvas 2D): the only scroll-driven
    // inputs are the two intensities (+ gust + drift), fed to the shared fx loop.
    const A = WINTER.aurora;
    const bright = auroraBrightness(m);
    const snow = snowAmount(m);
    winterFxState.aurora = bright;
    winterFxState.snow = snow;
    winterFxState.drift = sineInOut(ramp(A.glimmer, A.out, m));
    winterFxState.hardZero = m >= A.out;
    if (bright > 0.003 || snow > 0.003) {
      active = true;
      // scroll velocity (px/s, EMA-smoothed) -> snow wind gust; the loop decays it
      const now = performance.now();
      if (pTime.current < 0) {
        pPrev.current = p;
        pTime.current = now;
      } else {
        const dt = (now - pTime.current) / 1000;
        if (dt > 0.004) {
          const v = Math.max(-3000, Math.min(3000, ((p - pPrev.current) * spanRef.current) / dt));
          winterFxState.gust = winterFxState.gust * 0.75 + v * 0.25;
          pPrev.current = p;
          pTime.current = now;
        }
      }
      wakeWinterFx();
    } else {
      pPrev.current = p;
      pTime.current = performance.now();
    }

    // A3 hills: back then front rise; front sinks first, back finishes at 9:30
    const Hs = WINTER.hills;
    const bRise = easeOut(ramp(Hs.back[0], Hs.back[1], m));
    const bSink = smooth(ramp(Hs.sinkBack[0], Hs.sinkBack[1], m));
    if (show(hillBack.current, smooth(ramp(Hs.back[0], Hs.back[0] + Hs.fade, m)) * (1 - bSink)) && hillBack.current) {
      active = true;
      hillBack.current.style.transform = `translateY(${((1 - bRise) * 105 + bSink * 112).toFixed(2)}%)`;
    }
    const fRise = easeOut(ramp(Hs.front[0], Hs.front[1], m));
    const fSink = smooth(ramp(Hs.sinkFront[0], Hs.sinkFront[1], m));
    if (show(hillFront.current, smooth(ramp(Hs.front[0], Hs.front[0] + Hs.fade, m)) * (1 - fSink)) && hillFront.current) {
      active = true;
      hillFront.current.style.transform = `translateY(${((1 - fRise) * 105 + fSink * 112).toFixed(2)}%)`;
    }

    // A3 pines: staggered far -> near rise, near -> far sink, ease-out, no overshoot
    PINES.forEach((p2, i) => {
      const n = pines.current[i];
      const rise = easeOut(ramp(p2.start, p2.start + WINTER.pines.riseDur, m));
      const sink = smooth(ramp(p2.exit, p2.exit + WINTER.pines.sinkDur, m));
      if (show(n, smooth(ramp(p2.start, p2.start + WINTER.pines.fade, m)) * (1 - sink)) && n) {
        active = true;
        n.style.transform = `translateY(${((1 - rise) * 105 + sink * 118).toFixed(2)}%)`;
      }
    });

    // A4 cabin: rises with the landscape, window lights at 8:20 pm, out with the exit
    const C = WINTER.cabin;
    const cRise = easeOut(ramp(C.rise[0], C.rise[1], m));
    const cSink = smooth(ramp(C.sink[0], C.sink[1], m));
    if (show(cabin.current, smooth(ramp(C.rise[0], C.rise[0] + C.fade, m)) * (1 - cSink)) && cabin.current) {
      active = true;
      cabin.current.style.transform = `translateY(${((1 - cRise) * 112 + cSink * 120).toFixed(2)}%)`;
    }
    const light = smooth(ramp(C.lightOn, C.lightOn + C.lightDur, m)) * (1 - smooth(ramp(C.lightOff[0], C.lightOff[1], m)));
    show(cabinWin.current, light);
    show(cabinGlow.current, light * 0.95);

    // A5 sparkles: staggered in 8:05 -> 9:05 pm, out by 9:30 pm
    const T = WINTER.sparkles;
    SPARKLES.forEach((s, i) => {
      if (show(sparkles.current[i], smooth(ramp(s.in, s.in + T.fadeDur, m)) * (1 - smooth(ramp(T.out[0], T.out[1], m))))) active = true;
    });

    if (active !== winterOn.current) {
      winterOn.current = active;
      if (root.current) root.current.dataset["winter"] = active ? "on" : "off";
    }
  }, []);

  useImperativeHandle(ref, () => ({ update: apply }), [apply]);

  // px of page scroll that maps to the full 0..1 timeline progress: the section
  // grows 100svh -> 400vh AFTER mount (data-motion=on), so observe it directly.
  useEffect(() => {
    const sec = root.current?.closest("section");
    if (!sec) return;
    const update = () => {
      spanRef.current = Math.max(1, sec.offsetHeight - window.innerHeight);
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(sec);
    window.addEventListener("resize", update);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", update);
    };
  }, []);

  // copy-safe mask refresh hook from useSceneBounds; the scroll span is
  // tracked by the dedicated section observer above.
  const measure = useCallback(() => {}, []);
  useSceneBounds(root, measure);

  return (
    <div ref={root} data-winter="off" aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden [contain:layout_paint]">
      {/* A1 aurora — WebGL shader riding the dotted arc; masked away from copy,
          the moon (rendered after us) stays in front of it */}
      <div data-copy-safe className="absolute inset-0">
        <HeroAuroraCanvas />
      </div>

      {/* A2 snowfall, far + mid depths (behind the landscape) */}
      <HeroSnowCanvas depth="far" />

      {/* A3 hills */}
      <div ref={hillBack} className="hill-back absolute bottom-0 right-0" style={HIDDEN}>
        <svg viewBox="0 0 440 120" preserveAspectRatio="none" className="size-full"><path d="M0 120C70 58 150 46 230 62C300 76 372 100 440 86V120Z" fill="var(--paper)" fillOpacity="0.14" /></svg>
      </div>
      <div ref={hillFront} className="hill-front absolute bottom-0 right-0" style={HIDDEN}>
        <svg viewBox="0 0 440 100" preserveAspectRatio="none" className="size-full"><path d="M0 100C80 62 170 50 260 64C340 76 400 88 440 80V100Z" fill="var(--paper)" fillOpacity="0.24" /></svg>
      </div>

      {/* A3 pines: far, mid, then near on top of the cabin */}
      {PINES.map((p, i) => (
        <div key={i} ref={(n) => { pines.current[i] = n; }} className={`absolute bottom-0 ${p.keep ? "" : "max-md:hidden"}`} style={{ left: `${p.x.toFixed(2)}%`, height: `${p.vh.toFixed(2)}vh`, width: `calc(${p.vh.toFixed(2)}vh * 0.4545)`, ...HIDDEN }}>
          <svg viewBox="0 0 100 220" className={`pine-lean size-full ${p.sway ? "pine-sway" : ""}`} style={(p.sway ? { "--lean": `${p.lean.toFixed(2)}deg`, "--pine-dur": `${p.sway.dur.toFixed(1)}s`, "--pine-delay": `${p.sway.delay.toFixed(1)}s` } : { transform: `rotate(${p.lean.toFixed(2)}deg)` }) as React.CSSProperties}>
            {p.art.tiers.map((t, j) => (
              <g key={j}>
                <path d={t.d} fill="var(--ink)" fillOpacity={p.op} />
                <path d={t.cap} fill="var(--paper)" fillOpacity="0.9" />
              </g>
            ))}
            <path d={p.art.trunk} fill="var(--ink)" fillOpacity={Math.min(1, p.op + 0.15).toFixed(2)} />
          </svg>
        </div>
      ))}

      {/* A4 cozy cabin: window light on at 8:20 pm, smoke while visible */}
      <div ref={cabin} className="cabin-box absolute bottom-0" style={HIDDEN}>
        <svg viewBox="0 0 160 100" overflow="visible" className="block size-full">
          <defs>
            <radialGradient id="cabin-glow"><stop stopColor="var(--sun)" stopOpacity="0.4" /><stop offset="1" stopColor="var(--sun)" stopOpacity="0" /></radialGradient>
          </defs>
          <g fill="var(--paper)" fillOpacity="0.3">
            <circle className="smoke-puff" cx="104.5" cy="9" r="3.4" style={{ "--puff-delay": "0s" } as React.CSSProperties} />
            <circle className="smoke-puff" cx="104.5" cy="9" r="4.3" style={{ "--puff-delay": "-1.33s" } as React.CSSProperties} />
            <circle className="smoke-puff" cx="104.5" cy="9" r="5.2" style={{ "--puff-delay": "-2.66s" } as React.CSSProperties} />
          </g>
          <rect x="36" y="44" width="88" height="52" rx="2.5" fill="var(--ink)" fillOpacity="0.55" />
          <rect x="46" y="62" width="16" height="34" rx="2" fill="var(--ink)" fillOpacity="0.85" />
          <rect x="70" y="58" width="22" height="18" rx="2" fill="var(--ink)" fillOpacity="0.5" />
          <ellipse ref={cabinGlow} cx="81" cy="67" rx="27" ry="21" fill="url(#cabin-glow)" className="cabin-flicker" style={HIDDEN} />
          <rect ref={cabinWin} x="70" y="58" width="22" height="18" rx="2" fill="var(--sun)" style={HIDDEN} />
          <path d="M81 58v18M70 67h22" stroke="var(--ink)" strokeOpacity="0.55" strokeWidth="1.6" />
          <path d="M24 48L80 12L136 48Z" fill="var(--ink)" fillOpacity="0.72" />
          <path d="M27 46.6L80 14.4L133 46.6L124.6 46.6L80 22.6L35.4 46.6Z" fill="var(--paper)" fillOpacity="0.92" />
          <rect x="99" y="18" width="11" height="16" rx="1.5" fill="var(--ink)" fillOpacity="0.7" />
          <rect x="97.6" y="15.6" width="13.8" height="4.4" rx="2.2" fill="var(--paper)" fillOpacity="0.9" />
          <ellipse cx="80" cy="96.5" rx="74" ry="5.5" fill="var(--paper)" fillOpacity="0.22" />
        </svg>
      </div>

      {/* A2 snowfall, near depth + glyph crystals (in front of the landscape,
          still behind all text, CTA and navbar) */}
      <HeroSnowCanvas depth="near" />

      {/* A5 sparkles — same 4-point star language, pastel mint/white */}
      <div data-copy-safe className="absolute inset-0">
        {SPARKLES.map((s, i) => (
          <span key={i} ref={(n) => { sparkles.current[i] = n; }} className="absolute max-md:hidden" style={{ left: `${s.x.toFixed(2)}%`, top: `${s.y.toFixed(2)}%`, width: s.size, height: s.size, ...HIDDEN }}>
            <svg viewBox="0 0 20 20" className="winter-twinkle size-full" style={{ animationDelay: `${s.delay.toFixed(1)}s` }}><path d={STAR_PATH} fill={i % 2 ? "var(--mint)" : "var(--paper)"} /></svg>
          </span>
        ))}
      </div>
    </div>
  );
});
