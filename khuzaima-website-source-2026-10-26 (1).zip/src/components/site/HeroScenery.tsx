import { forwardRef, useCallback, useEffect, useImperativeHandle, useLayoutEffect, useRef, useState } from "react";
import { SCENE as S, ramp, smooth, easeIn, easeOut, lerp, backOut, mulberry32 } from "./heroSceneTimeline";

export type SceneryHandle = { update: (minutes: number) => void };

/* ---------- Birds ---------- */
const BIRDS = [
  { x: 60, y: 40, w: 46, lead: 6, ph: 0, flap: 1.05, mobile: true },
  { x: 68, y: 33, w: 34, lead: 0, ph: 1.7, flap: 1.2, mobile: true },
  { x: 55, y: 47, w: 58, lead: 12, ph: 3.1, flap: 0.95, mobile: true },
  { x: 106, y: 38, w: 40, lead: 4, ph: 4.2, flap: 1.15, mobile: false },
  { x: 109, y: 27, w: 28, lead: 0, ph: 2.4, flap: 1.3, mobile: false },
];
const WAY: [number, number][] = [[50, 28], [35, 20], [10, 17], [-14, 15]];
const PATHS = BIRDS.map((b) => {
  const pts: [number, number][] = [[b.x, b.y], ...WAY];
  const acc = [0];
  for (let i = 1; i < pts.length; i++) acc.push(acc[i - 1]! + Math.hypot(pts[i]![0] - pts[i - 1]![0], pts[i]![1] - pts[i - 1]![1]));
  return { pts, acc, len: acc[acc.length - 1]! };
});
function along(i: number, q: number): [number, number] {
  const { pts, acc, len } = PATHS[i]!;
  const d = q * len;
  let k = 1;
  while (k < acc.length - 1 && acc[k]! < d) k++;
  const t = (d - acc[k - 1]!) / (acc[k]! - acc[k - 1]! || 1);
  return [lerp(pts[k - 1]![0], pts[k]![0], Math.min(1, t)), lerp(pts[k - 1]![1], pts[k]![1], Math.min(1, t))];
}

export function Bird({ flap, ph }: { flap: number; ph: number }) {
  const v = { "--flap": `${flap}s`, "--fd": `${-ph}s` } as React.CSSProperties;
  return (
    <svg viewBox="0 0 60 24" className="block h-auto w-full fill-ink" style={v}>
      <path className="bird-wing bird-wing-l" d="M30 12C24 3 14 2 2 8C13 6 22 8 30 14Z" />
      <path className="bird-wing bird-wing-r" d="M30 12C36 3 46 2 58 8C47 6 38 8 30 14Z" />
      <ellipse cx="29" cy="13" rx="5.5" ry="2.4" />
      <circle cx="24.5" cy="12.2" r="1.9" />
    </svg>
  );
}

/* ---------- Clouds ---------- */
const CLOUDS = [
  { x: 46, y: 9, w: 150, op: 0.75, drift: 0.01, lead: 0, mobile: true },
  { x: 66, y: 8, w: 150, op: 0.75, drift: 0.01, lead: 0, mobile: false },
  { x: 55, y: 22, w: 220, op: 0.92, drift: 0.02, lead: 8, mobile: true },
  { x: 43, y: 36, w: 220, op: 0.92, drift: 0.02, lead: 8, mobile: false },
  { x: 62, y: 38, w: 300, op: 1, drift: 0.03, lead: 15, mobile: true },
];
const REVEAL_ORDER = [1, 2, 4, 0, 3];

export function Cloud({ fill = "var(--cloud)", shade = "var(--cloud-shade)", rim = false }: { fill?: string; shade?: string; rim?: boolean }) {
  return (
    <svg viewBox="0 0 300 110" className="block h-auto w-full">
      <g fill={fill}>
        <circle cx="78" cy="68" r="38" /><circle cx="135" cy="48" r="46" /><circle cx="196" cy="56" r="40" /><circle cx="246" cy="76" r="28" />
        <rect x="30" y="66" width="248" height="40" rx="20" />
      </g>
      <path fill={shade} d="M36 92h236a20 20 0 0 1-14 14H50a20 20 0 0 1-14-14Z" />
      {rim && <path d="M43 56A38 38 0 0 1 92 33A46 46 0 0 1 175 28A40 40 0 0 1 229 48" fill="none" stroke="var(--sunset-rim)" strokeWidth="2" strokeLinecap="round" />}
    </svg>
  );
}

/* ---------- Tree (viewBox 600x600, ground at y=600) ---------- */
function br(x0: number, y0: number, cx: number, cy: number, x1: number, y1: number, w0: number, w1: number) {
  const L = Math.hypot(x1 - x0, y1 - y0) || 1, nx = -(y1 - y0) / L, ny = (x1 - x0) / L;
  const a = w0 / 2, b = w1 / 2, c = (a + b) / 2, f = (n: number) => n.toFixed(1);
  return `M${f(x0 + nx * a)} ${f(y0 + ny * a)}Q${f(cx + nx * c)} ${f(cy + ny * c)} ${f(x1 + nx * b)} ${f(y1 + ny * b)}L${f(x1 - nx * b)} ${f(y1 - ny * b)}Q${f(cx - nx * c)} ${f(cy - ny * c)} ${f(x0 - nx * a)} ${f(y0 - ny * a)}Z`;
}
const TRUNK = [
  br(484, 640, 506, 380, 474, 110, 104, 14),
  br(470, 598, 430, 606, 370, 625, 36, 6),
  br(498, 598, 545, 603, 588, 612, 32, 6),
  br(486, 600, 472, 616, 448, 645, 42, 10),
].join("");
const PRIMARY = [
  br(486, 445, 280, 452, 60, 362, 28, 5),
  br(484, 385, 550, 372, 588, 306, 20, 4),
  br(483, 342, 365, 332, 250, 300, 20, 4),
  br(477, 245, 535, 235, 584, 158, 16, 3),
  br(475, 195, 440, 150, 390, 125, 18, 3.5),
  br(472, 128, 440, 70, 400, 18, 12, 2.5),
].join("");
const TWIGS = [
  br(200, 412, 160, 360, 125, 298, 7, 1.5),
  br(130, 388, 90, 385, 40, 410, 6, 1.4),
  br(330, 444, 322, 472, 306, 502, 6, 1.4),
  br(330, 319, 282, 301, 222, 272, 6, 1.4),
  br(560, 344, 578, 352, 590, 382, 5, 1.2),
  br(560, 212, 573, 175, 570, 120, 6, 1.4),
  br(410, 136, 405, 95, 418, 60, 6, 1.4),
  br(425, 62, 445, 36, 450, 2, 4, 1),
  br(270, 307, 262, 330, 250, 350, 4, 1),
].join("");
const OWLS = [
  { x: 234, y: 410, h: 98 },
  { x: 552, y: 350, h: 74 }, // right side of the trunk, clear of the moon and CTA
  { x: 436, y: 149, h: 52 },
];
function Owl({ i }: { i: number }) {
  const v = { "--br": `${3.5 + i * 0.5}s`, "--brd": `${-i * 1.3}s` } as React.CSSProperties;
  return (
    <g className="owl-breathe" style={v}>
      <path fill="var(--ink)" d="M-18 0C-23-20-21-42-15-50L-13-60-6-53C-2-55 2-55 6-53L13-60 15-50C21-42 23-20 18 0Z" />
      <ellipse cx="0" cy="-17" rx="11" ry="13" fill="var(--paper)" />
      <path fill="var(--ink)" d="M-5-22l5 3 5-3v1.6l-5 3-5-3ZM-5-14l5 3 5-3v1.6l-5 3-5-3Z" />
      <path fill="var(--paper)" d="M-12-42Q-7.5-36.5-3-42Q-7.5-38.5-12-42ZM3-42Q7.5-36.5 12-42Q7.5-38.5 3-42Z" />
      <path fill="var(--sun)" d="M-2.6-37h5.2L0-32.5Z" />
      <path fill="var(--sun)" d="M-9 0h2.4l.6 4h-1.6ZM6.6 0H9l-1.4 4H6Z" />
    </g>
  );
}

/* ---------- Stars ---------- */
type Star = { x: number; y: number; s: number; at: number; sun: boolean; tw: number; twd: number; spark: boolean };
type Rect = { l: number; t: number; r: number; b: number };

function buildStars(W: number, H: number, ex: Rect[]): Star[] {
  const rng = mulberry32(20261012);
  const scale = Math.max(0.7, W / 1900);
  const out: Star[] = [];
  const free = (x: number, y: number, pad: number) => ex.every((r) => x < r.l - pad || x > r.r + pad || y < r.t - pad || y > r.b + pad);
  let tries = 0;
  while (out.length < 62 && tries++ < 4000) {
    const i = out.length, spark = i >= 56;
    const x = rng() * W, y = rng() * H * 0.92;
    const roll = rng(), sunR = rng(), tw = rng(), twd = rng(), atR = rng();
    if (!free(x, y, spark ? 16 : 8)) continue;
    const s = spark ? lerp(10, 14, roll) * scale : i < 12 ? 1.5 * scale : (roll < 0.6 ? 1.5 : roll < 0.9 ? 2.5 : 3.5) * scale;
    const at = spark ? lerp(S.sparklesStart, S.starsFull - 30, atR) : i < 12 ? S.starsStart + atR * 15 : lerp(S.starsStart + 20, S.starsAppearEnd, atR);
    out.push({ x: (x / W) * 100, y: (y / H) * 100, s, at, sun: sunR < 0.15, tw: tw < 0.4 ? 2.5 + twd * 2.5 : 0, twd: -twd * 5, spark });
  }
  return out;
}

export const HeroScenery = forwardRef<SceneryHandle>(function HeroScenery(_, ref) {
  const root = useRef<HTMLDivElement>(null);
  const birds = useRef<(HTMLDivElement | null)[]>([]);
  const clouds = useRef<(HTMLDivElement | null)[]>([]);
  const starLayer = useRef<HTMLDivElement>(null);
  const starEls = useRef<(HTMLSpanElement | null)[]>([]);
  const stages = useRef<(SVGSVGElement | null)[]>([]);
  const owlEls = useRef<(SVGGElement | null)[]>([]);
  const birdLayer = useRef<HTMLDivElement>(null);
  const size = useRef({ W: 1, H: 1 });
  const lastM = useRef(S.start);
  /* write-gates for values that only flip at scene boundaries (Task 33) */
  const birdsOnRef = useRef<boolean | null>(null);
  const nightRef = useRef<string | null>(null);
  const owlsRef = useRef<string | null>(null);
  const [stars, setStars] = useState<Star[]>([]);
  const starsRef = useRef<Star[]>([]);
  useEffect(() => { starsRef.current = stars; }, [stars]);

  const apply = useCallback((m: number) => {
    lastM.current = m;
    const { W, H } = size.current;
    const el = root.current;
    if (!el) return;

    // Birds
    const birdsOn = m < S.exitEnd;
    if (birdsOnRef.current !== birdsOn) {
      birdsOnRef.current = birdsOn;
      birdLayer.current?.classList.toggle("scn-off", !birdsOn);
    }
    BIRDS.forEach((b, i) => {
      const n = birds.current[i];
      if (!n) return;
      const end = S.exitEnd - b.lead;
      const u = ramp(S.start, end, m);
      const split = (S.birdsDriftEnd - S.start) / (end - S.start);
      const q = u < split ? 0.5 * (u / split) : 0.5 + 0.5 * easeIn((u - split) / (1 - split));
      const [px, py] = along(i, q);
      const wob = Math.sin(u * Math.PI * 4 + b.ph) * 1.4;
      n.style.visibility = u >= 1 ? "hidden" : "visible";
      n.style.transform = `translate3d(${(px / 100) * W}px,${((py + wob) / 100) * H}px,0) translate(-50%,-50%)`;
    });

    // Clouds
    CLOUDS.forEach((c, i) => {
      const n = clouds.current[i];
      if (!n) return;
      const o = REVEAL_ORDER[i]!;
      const a = S.cloudRevealStart + o * S.cloudStagger;
      const r = smooth(ramp(a, a + S.cloudRevealDur, m));
      const end = S.exitEnd - c.lead;
      const sweep = easeIn(ramp(S.birdsDriftEnd, end, m));
      const drift = -Math.max(0, Math.min(m, S.birdsDriftEnd) - S.cloudRevealStart) * c.drift;
      const dx = drift - sweep * (c.x + c.w / 19 + 8);
      const on = r > 0 && m < end;
      n.style.visibility = on ? "visible" : "hidden";
      if (!on) return;
      n.style.opacity = String(r * c.op);
      n.style.clipPath = `inset(0 0 0 ${((1 - r) * 100).toFixed(2)}%)`;
      n.style.transform = `translate3d(${(dx / 100) * W}px,${(1 - r) * 14}px,0) scale(${0.92 + 0.08 * r})`;
    });

    // Stars
    const starsOn = m >= S.starsStart;
    if (starLayer.current) {
      starLayer.current.style.visibility = starsOn ? "visible" : "hidden";
      const night = m >= S.starsProminent ? "on" : "off";
      if (nightRef.current !== night) {
        nightRef.current = night;
        starLayer.current.dataset["night"] = night;
      }
    }
    if (starsOn) {
      const p1 = ramp(S.starsStart, S.starsProminent, m), p2 = ramp(S.starsProminent, S.starsFull, m);
      const bright = lerp(0.5, 0.85, p1) + 0.15 * p2;
      const grow = 1 + 0.15 * p1 + 0.15 * p2;
      starsRef.current.forEach((s, i) => {
        const n = starEls.current[i];
        if (!n) return;
        const a = easeOut(ramp(s.at, s.at + S.starFade, m));
        n.style.opacity = String(a * (s.spark ? 1 : bright));
        n.style.transform = `translate(-50%,-50%) scale(${(s.spark ? 0.6 + 0.4 * a : grow).toFixed(3)})`;
      });
    }

    // Tree
    const st: (readonly [number, number])[] = [S.trunk, S.primary, S.twigs];
    st.forEach(([a, b], i) => {
      const n = stages.current[i];
      if (!n) return;
      const g = easeOut(ramp(a, b, m));
      n.style.visibility = g > 0 ? "visible" : "hidden";
      n.style.clipPath = `inset(${((1 - g) * 100).toFixed(2)}% 0 0 0)`;
      n.style.transform = `translateY(${(1 - g) * 14}px)`;
    });
    const owlSvg = stages.current[3];
    if (owlSvg) {
      owlSvg.style.visibility = m >= S.owlsStart ? "visible" : "hidden";
      const owls = m >= S.owlsSettled ? "on" : "off";
      if (owlsRef.current !== owls) {
        owlsRef.current = owls;
        owlSvg.dataset["owls"] = owls;
      }
    }
    OWLS.forEach((o, i) => {
      const n = owlEls.current[i];
      if (!n) return;
      const a = S.owlsStart + i * S.owlStagger;
      const t = ramp(a, a + S.owlDur, m);
      const sc = (o.h / 60) * (0.85 + 0.15 * backOut(t));
      n.setAttribute("transform", `translate(${o.x} ${(o.y - 6 * (1 - easeOut(t))).toFixed(2)}) scale(${sc.toFixed(3)})`);
      n.style.opacity = String(t);
    });
  }, []);

  useImperativeHandle(ref, () => ({ update: apply }), [apply]);

  // Measure size + build stars with exclusion rects; re-run on resize (debounced).
  useLayoutEffect(() => {
    const el = root.current!;
    const hero = el.parentElement!;
    let t = 0;
    const measure = () => {
      const box = el.getBoundingClientRect();
      size.current = { W: box.width || 1, H: box.height || 1 };
      const rel = (r: DOMRect): Rect => ({ l: r.left - box.left, t: r.top - box.top, r: r.right - box.left, b: r.bottom - box.top });
      const ex: Rect[] = [{ l: 0, t: 0, r: box.width, b: 84 }];
      hero.querySelectorAll<HTMLElement>("#hero-title, [data-hero-ex]").forEach((n) => ex.push(rel(n.getBoundingClientRect())));
      const arc = hero.querySelector<SVGSVGElement>("[data-hero-arc]");
      const ctm = arc?.getScreenCTM();
      if (arc && ctm) {
        const pt = new DOMPoint(920, 260).matrixTransform(ctm);
        const rad = 34 * ctm.a + 40;
        ex.push({ l: pt.x - box.left - rad, t: pt.y - box.top - rad, r: pt.x - box.left + rad, b: pt.y - box.top + rad });
      }
      setStars(buildStars(box.width, box.height, ex));
      apply(lastM.current);
    };
    measure();
    const ro = new ResizeObserver(() => { clearTimeout(t); t = window.setTimeout(measure, 150); });
    ro.observe(el);
    return () => { ro.disconnect(); clearTimeout(t); };
  }, [apply]);

  useEffect(() => { apply(lastM.current); }, [stars, apply]);

  return (
    <div ref={root} aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden [contain:layout_paint]">
      {/* Stars */}
      <div ref={starLayer} className="absolute inset-0" style={{ visibility: "hidden" }}>
        {stars.map((s, i) => (
          <span
            key={i}
            ref={(n) => { starEls.current[i] = n; }}
            className={`absolute ${s.spark || i >= 30 ? "max-md:hidden" : ""}`}
            style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s, opacity: 0 }}
          >
            <span
              className={`block size-full ${s.tw ? "star-tw" : ""}`}
              style={{ "--tw": `${s.tw}s`, "--twd": `${s.twd}s` } as React.CSSProperties}
            >
              {s.spark ? (
                <svg viewBox="0 0 20 20" className={`size-full ${s.sun ? "fill-sun" : "fill-paper"}`}><path d="M10 0C11 7 13 9 20 10C13 11 11 13 10 20C9 13 7 11 0 10C7 9 9 7 10 0Z" /></svg>
              ) : (
                <span className={`block size-full rounded-full ${s.sun ? "bg-sun" : "bg-paper"}`} />
              )}
            </span>
          </span>
        ))}
      </div>

      {/* Clouds */}
      {CLOUDS.map((c, i) => (
        <div
          key={i}
          ref={(n) => { clouds.current[i] = n; }}
          className={`absolute will-change-transform ${c.mobile ? "" : "max-md:hidden"}`}
          style={{ left: `${c.x}%`, top: `${c.y}%`, width: `max(${c.w * 0.55}px, ${c.w / 19}%)`, visibility: "hidden" }}
        >
          <Cloud />
        </div>
      ))}

      {/* Birds */}
      <div ref={birdLayer} className="absolute inset-0">
        {BIRDS.map((b, i) => (
          <div
            key={i}
            ref={(n) => { birds.current[i] = n; }}
            className={`absolute left-0 top-0 will-change-transform ${b.mobile ? "" : "max-md:hidden"}`}
            style={{ width: `max(${b.w * 0.6}px, ${b.w / 19}%)` }}
          >
            <Bird flap={b.flap} ph={b.ph} />
          </div>
        ))}
      </div>

      {/* Tree + owls, anchored bottom-right */}
      <div className="absolute right-[clamp(12px,2vw,32px)] bottom-0 aspect-square h-[min(34%,72vw)] md:h-[min(64%,min(46vw,72vh))]">
        {[TRUNK, PRIMARY, TWIGS].map((d, i) => (
          <svg key={i} ref={(n) => { stages.current[i] = n; }} viewBox="0 0 600 600" overflow="visible" className="absolute inset-0 size-full" style={{ visibility: "hidden" }}>
            <path d={d} fill="var(--ink)" />
          </svg>
        ))}
        <svg ref={(n) => { stages.current[3] = n; }} viewBox="0 0 600 600" overflow="visible" className="absolute inset-0 size-full" style={{ visibility: "hidden" }}>
          {OWLS.map((_, i) => (
            <g key={i} ref={(n) => { owlEls.current[i] = n; }} style={{ opacity: 0 }}>
              <Owl i={i} />
            </g>
          ))}
          <g transform="translate(262 330)" fill="var(--paper)">
            {[0, 1, 2].map((k) => (
              <path key={k} className="owl-z" style={{ "--zd": `${-k * 1.33}s` } as React.CSSProperties} transform={`translate(${k * 9} ${-k * 9}) scale(${0.7 + k * 0.15})`} d="M0 0h8v1.8L2.6 7.2H8V9H0V7.2L5.4 1.8H0Z" />
            ))}
          </g>
        </svg>
      </div>
    </div>
  );
});