import { useCallback, useEffect, useRef, useState } from "react";
import { gsap, MOTION_OK } from "@/lib/motion";

type Msg = { from: "user" | "bot"; text: string };
const TRANSCRIPTS: Record<"clinic" | "estate", { title: string; who: string; msgs: Msg[] }> = {
  clinic: {
    title: "Sample Dental Clinic",
    who: "Patient",
    msgs: [
      { from: "user", text: "Hi, do you do dental implants? Can I book a consultation?" },
      { from: "bot", text: "Yes, implants are one of our core treatments. A consultation includes an exam and a written estimate. Which day suits you?" },
      { from: "user", text: "Saturday afternoon?" },
      { from: "bot", text: "I have 2:00 pm and 4:30 pm on Saturday. Which one?" },
      { from: "user", text: "4:30 please" },
      { from: "bot", text: "Noted for Saturday 4:30 pm. Our team confirms in the morning, and you\u2019ll get a reminder the day before." },
    ],
  },
  estate: {
    title: "Sample Properties",
    who: "Buyer",
    msgs: [
      { from: "user", text: "Is a 120 sq yd plot still available?" },
      { from: "bot", text: "Yes, a few are open. What budget range and timeline are you considering?" },
      { from: "user", text: "Within 3 months" },
      { from: "bot", text: "Thanks. Would you prefer a call from our sales team tomorrow, or a site visit on Saturday?" },
    ],
  },
};
const STEPS = [
  { t: "Answered", d: "A reply in seconds, at any hour." },
  { t: "Qualified", d: "The right questions, asked politely." },
  { t: "Booked", d: "A slot is held, not promised." },
  { t: "Team confirms", d: "A person on your team makes it final." },
];

/* Step-card class variants — swapped imperatively (never re-rendering the
   section mid-scroll). Identical class strings to the original render. */
const STEP_ON =
  "flex gap-5 rounded-[20px] border-2 p-5 transition-all duration-500 border-mint bg-mint text-ink";
const STEP_OFF =
  "flex gap-5 rounded-[20px] border-2 p-5 transition-all duration-500 border-paper/15 text-paper/60";

export function ChatDemo() {
  const root = useRef<HTMLElement>(null);
  /* The pinned stack: [statement screen] -> ["11:42" composition]. The
     translate scrubs the stack upward inside the pinned viewport (see the
     effect below); bodyRef wraps the pre-integration content so its settle
     position can be measured exactly. */
  const stackRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const [tab, setTab] = useState<"clinic" | "estate">("clinic");
  const data = TRANSCRIPTS[tab];

  /* Scroll progress lives in a ref and is applied straight to the DOM —
     the scrubbed 300vh pin never re-renders React (Task 33: the old
     setProgress-per-onUpdate re-rendered this whole section every scroll
     frame). Messages/typing/steps are pre-rendered and revealed by toggling
     `hidden`; the tw-animate entrance classes fire exactly when an element
     becomes rendered, matching the old mount-time animations. */
  const progressRef = useRef(1);
  const tabRef = useRef(tab);
  const msgRefs = useRef<(HTMLParagraphElement | null)[]>([]);
  const typingRef = useRef<HTMLSpanElement>(null);
  const stepRefs = useRef<(HTMLLIElement | null)[]>([]);

  const apply = useCallback((p: number) => {
    progressRef.current = p;
    const msgs = TRANSCRIPTS[tabRef.current].msgs;
    const n = msgs.length;
    const raw = p * (n + 0.6);
    const visible = Math.min(n, Math.floor(raw));
    const typing = visible < n && raw - visible > 0.45 && msgs[visible]?.from === "bot";
    const activeStep = p >= 0.97 ? 4 : Math.min(3, Math.floor((visible / n) * 3 + 0.0001));
    for (let i = 0; i < msgRefs.current.length; i++) {
      const el = msgRefs.current[i];
      if (el && el.hidden !== i >= visible) el.hidden = i >= visible;
    }
    if (typingRef.current && typingRef.current.hidden !== !typing) typingRef.current.hidden = !typing;
    for (let i = 0; i < stepRefs.current.length; i++) {
      const el = stepRefs.current[i];
      if (!el) continue;
      const on = i < activeStep || (i === 0 && visible > 0);
      const cls = on ? STEP_ON : STEP_OFF;
      if (el.className !== cls) el.className = cls;
    }
  }, []);

  useEffect(() => {
    const el = root.current!;
    const stack = stackRef.current!;
    const body = bodyRef.current!;
    const mm = gsap.matchMedia();
    mm.add(MOTION_OK, () => {
      el.dataset["motion"] = "on";
      apply(0);

      /* Two-screen pin geometry. The stack is taller than the pinned
         viewport: it opens on the "Never one and done." statement (the
         reference composition — deep negative space above the type) and
         scrubs upward to hand off to the "11:42 pm." composition, which
         settles exactly where the old my-auto centring put it. The section
         grows by precisely the translate distance (T), so the conversation
         reveal keeps its original 200vh scroll budget — only shifted later
         by T; ph is the translate's share of the (extended) pin. */
      const geo = { T: 0, ph: 0 };
      const nd = el.querySelector(".never-done") as HTMLElement;
      const measure = () => {
        const screen = stack.parentElement as HTMLElement;
        const cs = getComputedStyle(screen);
        const padTop = parseFloat(cs.paddingTop) || 0;
        const padBottom = parseFloat(cs.paddingBottom) || 0;
        const avail = screen.clientHeight - padTop - padBottom;
        /* Tall/narrow viewports (portrait tablets, phones): the responsive
           spacer can leave the 11:42 composition peeking into the statement
           screen. --nd-lead tops the spacer up by exactly the deficit, so
           the statement rides low with its support ending at the fold (the
           reference's own composition) and the body starts below it. On the
           desktop bands the deficit is 0 and the clamp stands alone. The
           delta is applied against the CURRENT lead so repeated measures
           stay idempotent (the lead itself inflates offsetTop). */
        const cur = parseFloat(nd.style.getPropertyValue("--nd-lead")) || 0;
        const lead = Math.max(0, cur + screen.clientHeight - padTop - body.offsetTop);
        nd.style.setProperty("--nd-lead", lead + "px");
        /* The body's resting offset inside the pinned screen — the same
           vertical centring the old my-auto wrapper produced. The stack
           starts at the screen's content top (below padTop), so padTop
           joins the translate: y = settle - padTop - offsetTop. */
        const settle = padTop + Math.max(0, (avail - body.offsetHeight) / 2);
        geo.T = Math.max(0, body.offsetTop + padTop - settle);
        el.style.height = `calc(200vh + 100svh + ${geo.T}px)`;
        const pin = el.offsetHeight - screen.offsetHeight;
        geo.ph = pin > 0 ? Math.min(0.9, geo.T / pin) : 0;
      };
      const render = (st: { progress: number }) => {
        const { T, ph } = geo;
        /* Phase 1 — the stack rise (statement screen -> 11:42 screen). */
        gsap.set(stack, { y: -T * (ph > 0 ? Math.min(1, st.progress / ph) : 1) });
        /* Phase 2 — the original reveal experience, its pixel budget
           preserved: remap the post-translate progress to 0..1. */
        const p2 = ph >= 1 ? st.progress : Math.max(0, (st.progress - ph) / (1 - ph));
        apply(Math.round(p2 * 200) / 200);
      };

      gsap.timeline({
        scrollTrigger: {
          trigger: el, start: "top top", end: "bottom bottom", scrub: true,
          /* Same 1/200 quantization the original React-state version used —
             keeps every reveal threshold at the exact same scroll position. */
          onRefreshInit: measure, /* re-measure + re-height before recalc */
          onRefresh: (st) => render(st),
          onUpdate: (st) => render(st),
        },
      });

      /* The statement's masked reveal — the site's signature entrance,
         fired once as the headline rises into view during the section's
         entry (before the pin engages). */
      gsap.fromTo(el.querySelectorAll(".never-done-title .reveal-line > span"), { yPercent: 112 }, {
        yPercent: 0, duration: 1.25, ease: "power4.out",
        scrollTrigger: { trigger: el.querySelector(".never-done-title"), start: "top 92%", once: true },
      });

      return () => { el.dataset["motion"] = "off"; el.style.height = ""; nd.style.removeProperty("--nd-lead"); apply(1); };
    });
    return () => mm.revert();
  }, [apply]);

  /* Tab switch re-populates the refs with a fresh transcript — re-apply the
     current progress before paint so no stale state shows. */
  useEffect(() => {
    tabRef.current = tab;
    apply(progressRef.current);
  }, [tab, apply]);

  return (
    <section ref={root} id="how" aria-labelledby="demo-title" data-motion="off" data-nav-theme="dark" className="group relative text-paper data-[motion=on]:h-[300vh]">
      {/* The pinned screen is full-bleed (the statement sets its own
          near-edge gutter, like "Our work."); the 11:42 composition keeps
          its container-site, moved onto the body wrapper below. Ground is
          the statement's flat #0D0B0A reference canvas (globals.css #how),
          continuous with the our-work zone above. */}
      <div className="chatdemo-screen flex min-h-[100svh] flex-col py-20 group-data-[motion=on]:sticky group-data-[motion=on]:top-0 group-data-[motion=on]:h-[100svh] group-data-[motion=on]:py-6">
        <div ref={stackRef} className="chatdemo-stack relative flex w-full flex-none flex-col will-change-transform">
          <div className="never-done">
            <p className="never-done-title">
              <span className="reveal-line"><span>Never one</span></span>
              <span className="reveal-line"><span>and done.</span></span>
            </p>
            <p className="never-done-sub">
              We co-create the future with our clients,<br />
              measure the impact and do it again.
            </p>
          </div>
          <div ref={bodyRef} className="container-site flex w-full flex-col">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <h2 id="demo-title" className="h2-fluid max-w-[14ch] text-[clamp(2rem,5vw,4.25rem)]">11:42 pm. Someone answers.</h2>
            <div role="tablist" aria-label="Demo type" className="flex rounded-full border-2 border-paper/30 p-1">
              {(["clinic", "estate"] as const).map((k) => (
                <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
                  className={`min-h-11 rounded-full px-5 text-sm font-semibold transition-colors ${tab === k ? "bg-mint text-ink" : "text-paper hover:bg-paper/10"}`}>
                  {k === "clinic" ? "Clinic" : "Real estate"}
                </button>
              ))}
            </div>
          </div>

          <div className="grid items-center gap-10 md:grid-cols-12">
            <figure className="md:col-span-6 lg:col-span-5">
              <div aria-hidden className="mx-auto w-full max-w-[360px] rounded-[var(--radius-phone)] border-[10px] border-paper/90 bg-paper text-ink">
                <div className="flex items-center gap-3 rounded-t-[26px] bg-ultramarine px-4 py-3 text-paper">
                  <span className="grid size-9 place-items-center rounded-full bg-mint font-display font-bold text-ink">{data.title[7]}</span>
                  <div className="leading-tight">
                    <p className="text-sm font-semibold">{data.title}</p>
                    <p className="text-xs opacity-80">Assistant, online</p>
                  </div>
                  <span className="ml-auto text-xs tabular opacity-80">11:42 pm</span>
                </div>
                <div className="flex h-[min(52svh,440px)] flex-col justify-end gap-2 overflow-hidden px-3 py-4">
                  {data.msgs.map((m, i) => (
                    <p
                      key={tab + i}
                      ref={(n) => { msgRefs.current[i] = n; }}
                      className={`max-w-[82%] animate-in slide-in-from-bottom-3 fade-in rounded-2xl px-3.5 py-2 text-[0.92rem] leading-snug duration-300 ${m.from === "user" ? "self-end rounded-br-md bg-lilac" : "self-start rounded-bl-md bg-mint"}`}
                    >
                      {m.text}
                    </p>
                  ))}
                  <span ref={typingRef} hidden className="flex gap-1 self-start rounded-2xl bg-mint px-4 py-3">
                    <i className="typing-dot size-1.5 rounded-full bg-ink" /><i className="typing-dot size-1.5 rounded-full bg-ink" /><i className="typing-dot size-1.5 rounded-full bg-ink" />
                  </span>
                </div>
              </div>
              <figcaption className="mx-auto mt-4 max-w-[360px] text-sm text-paper/80">
                Concept demo of how an assistant could work. Not a real conversation.
              </figcaption>
              <div className="sr-only">
                <p>Transcript, {data.title}, 11:42 pm:</p>
                <ol>{data.msgs.map((m, i) => <li key={i}>{m.from === "user" ? data.who : "Assistant"}: {m.text}</li>)}</ol>
              </div>
            </figure>

            <ol className="space-y-2 md:col-span-6 lg:col-span-6 lg:col-start-7">
              {STEPS.map((s, i) => (
                <li key={s.t} ref={(n) => { stepRefs.current[i] = n; }} className={STEP_ON}>
                  <span className="font-display text-3xl font-bold tabular">{i + 1}</span>
                  <div>
                    <p className="font-display text-2xl font-bold">{s.t}</p>
                    <p className="text-sm">{s.d}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
          </div>
        </div>
      </div>
    </section>
  );
}
