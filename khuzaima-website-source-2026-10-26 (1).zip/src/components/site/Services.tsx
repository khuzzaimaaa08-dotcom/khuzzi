import { useEffect, useRef } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { gsap, MOTION_OK } from "@/lib/motion";
import { useEffect as useIdleEffect } from "react";
import contactPerson from "@/assets/contact-person.png";

function FlowVisual() {
  return (
    <svg viewBox="0 0 400 260" className="w-full max-w-md" aria-hidden>
      <path d="M50 60 H200 V172 M228 200 H350 M200 60 H350" fill="none" stroke="currentColor" strokeWidth="3" strokeDasharray="6 8" />
      {[[50, 60], [200, 60], [350, 60], [350, 200]].map(([x, y], i) => (
        <circle key={i} className="flow-node" cx={x} cy={y} r="22" stroke="currentColor" strokeWidth="3" />
      ))}
      <rect x="172" y="172" width="56" height="56" rx="10" fill="none" stroke="currentColor" strokeWidth="3" />
      <text x="200" y="206" textAnchor="middle" fontSize="15" fontWeight="700" fill="currentColor">OK?</text>
    </svg>
  );
}
function AgentVisual() {
  return (
    <div className="w-full max-w-sm space-y-3" aria-hidden>
      <p className="w-4/5 rounded-2xl rounded-bl-md bg-paper px-4 py-3 text-sm">What are your Friday hours?</p>
      <p className="ml-auto w-4/5 rounded-2xl rounded-br-md bg-ink px-4 py-3 text-sm text-paper">Open 10 am to 6 pm. Shall I pass you to our coordinator?</p>
      <div className="flex items-center gap-3 rounded-2xl border-2 border-ink px-4 py-3">
        <svg viewBox="0 0 24 24" className="size-8" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="8" r="4" /><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" /></svg>
        <div className="text-sm leading-tight"><b>Handed to Sara</b><br />Summary: Friday visit, new patient.</div>
      </div>
    </div>
  );
}
function SiteVisual() {
  return (
    <div className="w-full max-w-md overflow-hidden rounded-[18px] border-[3px] border-ink bg-paper" aria-hidden>
      <div className="flex gap-1.5 border-b-[3px] border-ink px-3 py-2">{[0, 1, 2].map((i) => <span key={i} className="size-2.5 rounded-full bg-ink" />)}</div>
      <div className="h-56 overflow-hidden">
        <div data-site-scroll className="space-y-3 p-4">
          <div className="h-16 rounded-lg bg-ultramarine" />
          <div className="h-3 w-3/4 rounded bg-ink" /><div className="h-3 w-1/2 rounded bg-ink/40" />
          <div className="h-9 w-36 rounded-full bg-tangerine" />
          <div className="grid grid-cols-2 gap-2"><div className="h-20 rounded-lg bg-mint" /><div className="h-20 rounded-lg bg-lilac" /></div>
          <div className="h-3 w-2/3 rounded bg-ink/40" /><div className="h-24 rounded-lg bg-sun" />
          <div className="h-9 w-40 rounded-full bg-ink" />
        </div>
      </div>
    </div>
  );
}

const IC = { fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
const EXTRAS = [
  { t: "Lead generation", d: "Meta ads and landing pages that bring in enquiries", bg: "bg-mint", icon: <><path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1Z" /><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12" /></> },
  { t: "AI ad creatives", d: "Image and video made for your campaigns", bg: "bg-lilac", icon: <path d="M12 3c.6 4.6 2.4 6.4 7 7-4.6.6-6.4 2.4-7 7-.6-4.6-2.4-6.4-7-7 4.6-.6 6.4-2.4 7-7Z" /> },
  { t: "AI security review", d: "Check what your agents can access and do", bg: "bg-tangerine", icon: <><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6Z" /><path d="M9 12l2 2 4-4" /></> },
  { t: "Custom AI tools", d: "Integrations built around how you work", bg: "bg-paper", icon: <><path d="M9 2v5M15 2v5M6 7h12v4a6 6 0 0 1-12 0Z" /><path d="M12 17v5" /></> },
];
const DOTS = "pointer-events-none absolute hidden md:block [background-image:radial-gradient(color-mix(in_oklch,var(--sun),var(--ink)_15%)_1.6px,transparent_1.8px)] [background-size:18px_18px] opacity-60 [mask-image:radial-gradient(closest-side,black,transparent)]";
function Plus({ className }: { className: string }) {
  return <svg viewBox="0 0 20 20" aria-hidden className={`pointer-events-none absolute size-5 text-ink/30 ${className}`} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 3v14M3 10h14" /></svg>;
}
function MoreVisual() {
  return (
    <div className="relative w-full max-w-[600px] py-2">
      <div aria-hidden className={`${DOTS} left-0 top-0 h-24 w-16`} />
      <div aria-hidden className={`${DOTS} right-0 top-2 h-20 w-14`} />
      <div aria-hidden className={`${DOTS} left-0 bottom-0 h-24 w-16`} />
      <Plus className="left-0 top-0 size-4" />
      <Plus className="bottom-0 right-0 size-4" />
      <svg aria-hidden viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 h-full w-full text-ink/35">
        <path d="M25 30 C50 30 50 38 75 38 M75 38 C75 55 75 60 75 72 M75 72 C50 72 50 64 25 64 M25 64 C25 50 25 45 25 30" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 6" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      </svg>
      <ul className="relative grid grid-cols-2 gap-[clamp(0.625rem,1.4vw,1.125rem)] md:pb-7">
        {EXTRAS.map(({ t, d, bg, icon }, i) => (
          <li key={t} className={i % 2 ? "md:translate-y-6" : ""}><div data-more-row className="h-full">
            <div className={`flex h-full flex-col items-start rounded-[24px] border-[3px] border-ink ${bg} p-[clamp(0.875rem,1.6vw,1.375rem)] shadow-[0_10px_24px_-8px_color-mix(in_oklch,var(--sun),var(--ink)_45%)] transition-[transform,box-shadow] duration-200 ease-out motion-safe:md:hover:-translate-y-1 md:hover:shadow-[0_16px_30px_-8px_color-mix(in_oklch,var(--sun),var(--ink)_50%)]`}>
              <span className="grid size-[clamp(2.5rem,3.4vw,3rem)] place-items-center rounded-full border-2 border-ink bg-paper">
                <svg viewBox="0 0 24 24" className="size-[clamp(1.125rem,1.6vw,1.375rem)]" aria-hidden {...IC}>{icon}</svg>
              </span>
              <b className="mt-[clamp(0.625rem,1.2vw,1rem)] line-clamp-2 font-display text-[clamp(1rem,1.6vw,1.375rem)] font-bold leading-[1.15] tracking-tight">{t}</b>
              <span className="mt-1.5 line-clamp-2 text-[clamp(0.8125rem,1.1vw,0.9375rem)] leading-[1.4] text-ink/85">{d}</span>
            </div>
          </div></li>
        ))}
      </ul>
    </div>
  );
}
function MoreCta() {
  const router = useRouter();
  useIdleEffect(() => {
    const warm = () => { try { router.prefetch("/contact"); } catch {} const i = new Image(); i.src = contactPerson.src; };
    const ric = "requestIdleCallback" in window ? window.requestIdleCallback : undefined;
    const id = ric ? ric(warm, { timeout: 2500 }) : window.setTimeout(warm, 1500);
    return () => { if (ric) window.cancelIdleCallback(id); else clearTimeout(id); };
  }, [router]);
  return (
    <Link href="/contact" data-cursor="book" className="group mt-10 inline-flex min-h-[clamp(3.5rem,4.5vw,4rem)] items-center gap-6 rounded-full bg-ink py-2 pl-10 pr-2.5 text-lg font-semibold text-paper transition-transform duration-200 ease-out motion-safe:hover:-translate-y-px">
      Let&apos;s connect
      <span className="grid size-11 place-items-center rounded-full bg-paper text-ink transition-transform duration-200 ease-out motion-safe:group-hover:translate-x-[3px]">
        <svg viewBox="0 0 24 24" className="size-5" aria-hidden fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
      </span>
    </Link>
  );
}

/* "Solutions." — the reference's statement header (huge matter type riding
   low on the dark canvas, subtext two lines below) followed by the four
   full-width stacked scroll cards: mint AI automation, lilac Custom AI
   agents, tangerine Premium websites, sun "And more" — each card sticky-
   stacking over the previous one (scale + dim as the next covers it),
   ~50px radius on desktop. Same #services anchor the nav "Solutions"
   link and the craft "Discover our solutions." link point at. */

type Panel = { bg: string; title: string; body: string; V: () => React.JSX.Element; cta?: boolean };
const PANELS: Panel[] = [
  { bg: "bg-mint", title: "AI automation", body: "Booking requests, reminders, follow-ups and lead routing that run on their own, with your team approving what matters.", V: FlowVisual },
  { bg: "bg-lilac", title: "Custom AI agents", body: "Assistants that know your services, hours and policies. They answer, qualify the inquiry and hand over to a person with a clean summary.", V: AgentVisual },
  { bg: "bg-tangerine", title: "Premium websites", body: "Fast, clear websites designed to turn visitors into booked calls and appointments, not just good-looking pages.", V: SiteVisual },
  { bg: "bg-sun", title: "And more", body: "Beyond the big three, we build the pieces around them, from ads that bring in enquiries to security checks. Something else in mind? Let's talk.", V: MoreVisual, cta: true },
];

export function Services() {
  const root = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = root.current!;
    const mm = gsap.matchMedia();
    mm.add(MOTION_OK, () => {
      const panels = el.querySelectorAll<HTMLElement>("[data-panel]");
      panels.forEach((p, i) => {
        const next = panels[i + 1];
        if (!next) return;
        gsap.to(p, { scale: 0.92, ease: "none", scrollTrigger: { trigger: next, start: "top bottom", end: "top 12%", scrub: true } });
        gsap.to(p.querySelector("[data-dim]"), { opacity: 0.45, ease: "none", scrollTrigger: { trigger: next, start: "top bottom", end: "top 12%", scrub: true } });
      });
      const site = el.querySelector("[data-site-scroll]");
      const sitePanel = site?.closest<HTMLElement>("[data-panel]");
      if (site && sitePanel) gsap.fromTo(site, { yPercent: 0 }, { yPercent: -45, ease: "none", scrollTrigger: { trigger: sitePanel, start: "top bottom", end: "bottom top", scrub: true } });
      const rows = el.querySelectorAll<HTMLElement>("[data-more-row]");
      const morePanel = rows[0]?.closest<HTMLElement>("[data-panel]");
      if (morePanel) gsap.fromTo(rows, { opacity: 0, y: 16 }, { opacity: 1, y: 0, ease: "none", stagger: 0.08, scrollTrigger: { trigger: morePanel, start: "top 85%", end: "top 25%", scrub: true } });
    });
    return () => mm.revert();
  }, []);

  return (
    <section ref={root} id="services" aria-labelledby="services-title" data-nav-theme="dark" className="solutions theme-canvas">
      <div className="solutions-head">
        <h2 id="services-title" className="solutions-title theme-fg">Solutions.</h2>
        <p className="solutions-sub theme-fg">
          AI-native. Systems-driven. Expert-led.<br />
          The capabilities that turn ideas into impact.
        </p>
      </div>
      <div className="solutions-stack">
        {PANELS.map(({ bg, title, body, V, cta }, i) => (
          <article key={title} data-panel className={`solutions-card relative top-[12svh] origin-top ${bg} text-ink md:sticky md:min-h-[76svh]`}>
            <div data-dim className="pointer-events-none absolute inset-0 bg-ink opacity-0" />
            <div className="relative grid gap-10 p-[clamp(1.75rem,3vw,2.75rem)] max-md:pt-14 md:min-h-[76svh] md:grid-cols-12 md:items-center md:p-14">
              <div className="md:col-span-6">
                <p className="solutions-num" aria-hidden>0{i + 1}</p>
                <h3 className="text-[clamp(2.25rem,5vw,4.5rem)] font-extrabold">{title}</h3>
                <p className="mt-6 max-w-[42ch] text-lg">{body}</p>
                {cta && <MoreCta />}
              </div>
              <div className="flex max-md:pt-2 justify-center md:col-span-6"><V /></div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
