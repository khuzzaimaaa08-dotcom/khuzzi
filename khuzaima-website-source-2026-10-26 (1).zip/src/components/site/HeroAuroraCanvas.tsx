"use client";
import { useEffect, useRef } from "react";
import { WINTER } from "./heroSceneTimeline";
import { addWinterFx, wakeWinterFx, winterFxState } from "./heroWinterFx";

const VERT_SRC = `attribute vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`;

/**
 * Realistic aurora: wavy bright hem, 3 layered curtains, tall noise rays with
 * fast shimmer, soft exponential falloff (no rectangles / tiles / hard edges),
 * green → teal → violet/pink, edge vignette so the box boundary is never
 * visible, tone-mapped premultiplied output (additive-like glow), tiny
 * hash dither to kill 8-bit banding.
 */
const FRAG_SRC = `#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform vec2  uRes;
uniform float uTime;
uniform float uIntensity;

float hash1(float n) { return fract(sin(n) * 43758.5453123); }
float hash2(vec2 p)  { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }

float n1(float x) {
  float i = floor(x);
  float f = fract(x);
  f = f * f * (3.0 - 2.0 * f);
  return mix(hash1(i), hash1(i + 1.0), f);
}

float n2(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash2(i);
  float b = hash2(i + vec2(1.0, 0.0));
  float c = hash2(i + vec2(0.0, 1.0));
  float d = hash2(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Base arc in the box's local coords (x: 0..1 left to right, y: 0..1 top to bottom). Follows the dotted arc.
float baseHem(float x) {
  float y = 0.47;
  y += (0.24 - 0.47) * smoothstep(0.03, 0.38, x);
  y += (0.26 - 0.24) * smoothstep(0.38, 0.69, x);
  y += (0.61 - 0.26) * smoothstep(0.69, 0.90, x);
  y += (0.84 - 0.61) * smoothstep(0.90, 0.98, x);
  return y;
}

vec3 auroraColor(float up, float x) {
  vec3 green  = vec3(0.16, 1.00, 0.30);
  vec3 teal   = vec3(0.15, 0.95, 0.58);
  vec3 violet = vec3(0.65, 0.40, 1.00);
  vec3 pink   = vec3(1.00, 0.42, 0.78);
  vec3 c   = mix(green, teal, smoothstep(0.25, 1.0, up));
  vec3 top = mix(violet, pink, smoothstep(0.15, 0.85, x));
  return mix(c, top, smoothstep(0.45, 0.95, up));
}

void main() {
  vec2 p = vec2(gl_FragCoord.x / uRes.x, 1.0 - gl_FragCoord.y / uRes.y);
  float t = uTime;
  vec3  col = vec3(0.0);
  float acc = 0.0;

  for (int i = 0; i < 3; i++) {
    float fi = float(i);
    // wavy hem: each layer sits slightly higher and folds at its own speed
    float hem = baseHem(p.x) - 0.045 * fi
              + 0.030 * sin(p.x * (6.0 + 1.7 * fi) + t * (0.22 + 0.07 * fi) + fi * 1.9)
              + 0.016 * sin(p.x * (15.0 + 3.0 * fi) - t * (0.38 + 0.05 * fi) + fi * 2.7);
    float h  = (0.20 + 0.15 * n1(p.x * 5.0 + t * 0.08 + fi * 7.0)) * (1.0 - 0.18 * fi);
    float d  = hem - p.y;            // > 0 above the hem
    float up = d / h;

    // bright lower edge, fast exponential fade + longer tail that carries the
    // violet/pink fringe well past the green body (up is unclamped above)
    float prof = (d >= 0.0) ? (exp(-up * 2.4) + 0.48 * exp(-up * 1.0)) : exp(d * 60.0);
    prof += 0.55 * exp(-abs(d) * 26.0);   // thin bright hem core, soft on both sides

    // vertical rays: tall thin noise cells + very thin fast-flickering rays
    float rayA = n2(vec2(p.x * 78.0  + fi * 13.0, p.y * 1.4 - t * 0.35));
    float rayB = n2(vec2(p.x * 170.0 + fi * 5.0,  t * 0.8 + fi));
    float ray  = smoothstep(0.28, 0.82, 0.7 * rayA + 0.3 * rayB);
    float clump = 0.7 + 0.3 * n1(p.x * 9.0 + fi * 3.0 + t * 0.05);   // rays cluster into groups
    float rayF = mix(0.70, mix(0.22, 1.0, ray), smoothstep(0.0, 0.05, d)) * clump;

    float fold    = 0.65 + 0.35 * n1(p.x * 4.0 + t * 0.12 + fi * 5.0);   // slow drapery folds
    float shimmer = 0.86 + 0.14 * n1(t * 1.6 + p.x * 24.0 + fi * 3.0);
    float depth   = 1.0 - 0.28 * fi;

    float a = prof * rayF * fold * shimmer * depth;
    col += auroraColor(clamp(up, 0.0, 1.0), p.x) * a;
    acc += a;
  }

  // soft vignette so no edge of the box is ever visible
  float fx = smoothstep(0.0, 0.10, p.x) * (1.0 - smoothstep(0.88, 1.0, p.x));
  float fy = smoothstep(0.0, 0.10, p.y) * (1.0 - smoothstep(0.92, 1.0, p.y));
  float v  = fx * fy * uIntensity;

  vec3  rgb   = (1.0 - exp(-col * 0.95)) * v;
  float alpha = (1.0 - exp(-acc * 0.95)) * v * 0.6;  // color > alpha = additive-like glow (premultiplied)
  // subtle hash dither only where the aurora exists: breaks 8-bit banding, stays invisible outside
  float dith = (hash2(gl_FragCoord.xy) - 0.5) * 0.007 * step(0.02, acc);
  gl_FragColor = vec4(rgb + dith, clamp(alpha + dith * 0.5, 0.0, 1.0));
}`;

const GL_ATTRS: WebGLContextAttributes = {
  alpha: true,
  premultipliedAlpha: true,
  antialias: false,
  depth: false,
  stencil: false,
  powerPreference: "low-power",
};

/**
 * A1 aurora — WebGL1 fragment shader in a box that follows the dotted arc.
 * Layer order: stars < AURORA < moon (the arc svg renders after the night
 * layers, so the moon stays in front). The wrapper is masked by the shared
 * copy-safe luminance mask (heroLayerTools) so the glow keeps ≥ 24 px away
 * from the clock/tagline; the shader vignette fades the right end before it.
 */
export function HeroAuroraCanvas() {
  const boxRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fallbackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const box = boxRef.current;
    const canvas = canvasRef.current;
    const fallback = fallbackRef.current;
    if (!box || !canvas || !fallback) return;
    const cvs: HTMLCanvasElement = canvas; // non-null alias, narrowed for closures
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");

    let gl: WebGLRenderingContext | null = null;
    let uRes: WebGLUniformLocation | null = null;
    let uTime: WebGLUniformLocation | null = null;
    let uIntensity: WebGLUniformLocation | null = null;
    let lost = false;
    let ok = false;

    const resize = () => {
      const scale = window.innerWidth < 768 ? WINTER.aurora.mobileScale : WINTER.aurora.scale;
      const w = Math.max(2, Math.round((cvs.clientWidth || 2) * scale));
      const h = Math.max(2, Math.round((cvs.clientHeight || 2) * scale));
      if (cvs.width !== w || cvs.height !== h) {
        cvs.width = w;
        cvs.height = h;
      }
      gl?.viewport(0, 0, cvs.width, cvs.height);
    };

    const initGL = (): boolean => {
      gl = cvs.getContext("webgl", GL_ATTRS) as WebGLRenderingContext | null;
      if (!gl) return false;
      const g = gl;
      const compile = (type: number, src: string) => {
        const sh = g.createShader(type);
        if (!sh) return null;
        g.shaderSource(sh, src);
        g.compileShader(sh);
        return g.getShaderParameter(sh, g.COMPILE_STATUS) ? sh : null;
      };
      const vs = compile(g.VERTEX_SHADER, VERT_SRC);
      const fs = compile(g.FRAGMENT_SHADER, FRAG_SRC);
      if (!vs || !fs) return false;
      const prog = g.createProgram();
      if (!prog) return false;
      g.attachShader(prog, vs);
      g.attachShader(prog, fs);
      g.linkProgram(prog);
      if (!g.getProgramParameter(prog, g.LINK_STATUS)) return false;
      g.useProgram(prog);
      const buf = g.createBuffer();
      g.bindBuffer(g.ARRAY_BUFFER, buf);
      g.bufferData(g.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), g.STATIC_DRAW);
      const aPos = g.getAttribLocation(prog, "aPos");
      g.enableVertexAttribArray(aPos);
      g.vertexAttribPointer(aPos, 2, g.FLOAT, false, 0, 0);
      uRes = g.getUniformLocation(prog, "uRes");
      uTime = g.getUniformLocation(prog, "uTime");
      uIntensity = g.getUniformLocation(prog, "uIntensity");
      resize();
      return true;
    };

    const draw = (time: number, intensity: number) => {
      if (!gl || !ok) return;
      gl.uniform2f(uRes, cvs.width, cvs.height);
      gl.uniform1f(uTime, time);
      gl.uniform1f(uIntensity, intensity);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    };

    const onLost = (e: Event) => {
      e.preventDefault();
      lost = true;
    };
    const onRestored = () => {
      lost = false;
      ok = initGL();
    };
    cvs.addEventListener("webglcontextlost", onLost);
    cvs.addEventListener("webglcontextrestored", onRestored);

    ok = initGL();
    // Dev aid: ?no-gl=1 forces the CSS fallback path (never in production).
    if (process.env.NODE_ENV === "development" && new URLSearchParams(location.search).has("no-gl")) ok = false;
    if (!ok) cvs.style.display = "none";

    const ro = new ResizeObserver(resize);
    ro.observe(cvs);

    let tAbs = 0;
    let lastI = -1;
    let lastStaticI = -1;
    let lastDrift = -1;

    const task = (dt: number): boolean => {
      const I = winterFxState.aurora;
      if (winterFxState.hardZero || I <= 0.003) {
        box.style.visibility = "hidden";
        return false;
      }
      if (box.style.visibility !== "visible") box.style.visibility = "visible";
      // gentle scroll-linked parallax drift on the wrapper (±drift % of box width)
      const drift = winterFxState.drift;
      if (Math.abs(drift - lastDrift) > 0.001) {
        lastDrift = drift;
        const px = WINTER.aurora.drift * (drift * 2 - 1);
        box.style.transform = `translate3d(${px.toFixed(2)}%,0,0)`;
      }
      if (!ok) {
        // CSS fallback: 3 soft elliptical gradients riding the arc, same intensity
        if (Math.abs(I - lastI) > 0.002) {
          lastI = I;
          fallback.style.opacity = I.toFixed(3);
        }
        return !reduced.matches;
      }
      if (reduced.matches) {
        // reduced motion: ONE static frame at the current intensity, no animation
        if (Math.abs(I - lastStaticI) > 0.004 || lastStaticI < 0) {
          lastStaticI = I;
          draw(40, I);
        }
        return false;
      }
      if (lost) return true; // context lost; wait for restore
      tAbs += dt;
      draw(tAbs, I);
      return true;
    };

    const remove = addWinterFx(task);
    wakeWinterFx(); // in case the scene is already active at mount (refresh mid-page)
    return () => {
      remove();
      ro.disconnect();
      cvs.removeEventListener("webglcontextlost", onLost);
      cvs.removeEventListener("webglcontextrestored", onRestored);
      gl?.getExtension("WEBGL_lose_context")?.loseContext();
      gl = null;
    };
  }, []);

  const B = WINTER.aurora.box;
  return (
    <div
      ref={boxRef}
      className="aurora-box absolute"
      style={{ left: `${B.left}%`, top: `${B.top}%`, width: `${B.width}%`, height: `${B.height}%`, visibility: "hidden" }}
    >
      <canvas ref={canvasRef} className="block size-full" />
      <div ref={fallbackRef} aria-hidden className="aurora-fallback absolute inset-0" style={{ opacity: 0 }} />
    </div>
  );
}
