"use client";

import { useEffect, useRef } from "react";
import type { CSSProperties } from "react";
import { gsap, ScrollTrigger, MOTION_OK } from "@/lib/motion";
import { WORK_CASES } from "./our-work-cases";

/* Our Work — the giant "Our work." heading plus the pinned, scroll-driven
   horizontal case-study slider.

   Structure:

     section.our-work            dark #0D0B0A canvas (ThemeTransition),
     │                           opens with the Task 41 dissolve runway
     └ .work-stage               PINNED for the whole slider (100svh),
       │                         flex column, justify-content: flex-end —
       │                         the composition is bottom-anchored
       ├ container-site          "Our work." heading — glued above the
       │                         card (~5rem gap); crops off the top on
       │                         short viewports (ratio never squashes)
       └ .work-track             flex row of N viewport-wide slides,
                                 scrubbed 1:1 with the scrollbar
         └ .work-slide × N       100vw + 20px padding on all sides →
           └ a.work-card         card = viewport − 40px, ~3.587:1 from
                                 aspect-ratio ONLY (no height caps)
             ├ picture           art-directed media (mobile/tablet/desktop)
             └ article           bottom-anchored 12-column text grid

   Scroll behaviour (GSAP ScrollTrigger + the site's Lenis, already wired
   in Chrome.tsx): the stage pins when its top hits the viewport top and
   releases after (N−1) slide-widths of vertical scroll, while the track
   translates right-to-left as one rigid body — no snapping, no stacking,
   the next card entering from the right with the 40px gap visible.
   Smoothness comes from the scrub + Lenis, never from easing (ease
   "none"). Everything runs on transforms with will-change, and every
   value is a function + invalidateOnRefresh so resizes re-measure.

   Card height comes ONLY from its aspect-ratio (1185/330.354 desktop):
   the pinned stage bottom-anchors the slide row, so the card's bottom
   rides 20px above the viewport bottom at every height and the heading
   crops off the top on short viewports instead of the card ever being
   squashed (globals.css .work-stage / .work-card).

   prefers-reduced-motion: the pin is never created and the track falls
   back to native horizontal scroll-snap (globals.css). Cleanup reverts
   the matchMedia context, so React StrictMode double-mounts are safe.

   Card + copy specs (measured at a 1225px viewport, implemented
   relative): slide 100vw with 20px padding (20px page gutter, 40px
   slide-to-slide gap), card aspect 1185/330.354 with 8px radius and
   32px inner padding, text grid 12 columns / 16px gaps with the title
   spanning columns 1–8 and the subtitle 1–6, both matter 600 at
   −0.05em tracking, 0.9 line-height and clamp(2rem, 4.52vw, 5.5rem)
   (55.39px @1225), themed per card via --wc-* tokens set from the data.

   TODO(content): the four clients + SVG artwork are placeholders in the
   Khuzaima Labs brand palette — see our-work-cases.ts. */

/** Tunable: vertical scroll distance per slide, in multiples of one slide
 *  width. 1 = the track travels exactly one viewport-width per viewport
 *  of scroll (1:1 scrub). Raise it to slow the slider down. */
const SCROLL_PER_SLIDE = 1;

export function OurWork() {
  const stageRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stage = stageRef.current;
    const track = trackRef.current;
    if (!stage || !track) return;

    /* iOS/Android URL-bar resizes shouldn't re-pin mid-gesture. */
    ScrollTrigger.config({ ignoreMobileResize: true });

    const mm = gsap.matchMedia();
    mm.add(MOTION_OK, () => {
      const slides = track.children;
      const slideWidth = () => (slides[0] as HTMLElement).offsetWidth;
      /* Rigid track travel: (N−1) slide widths, whatever the scroll
         distance (SCROLL_PER_SLIDE) happens to be. */
      const travel = () => (WORK_CASES.length - 1) * slideWidth();

      const tween = gsap.to(track, {
        x: () => -travel(),
        ease: "none",
        scrollTrigger: {
          trigger: stage,
          start: "top top",
          end: () => "+=" + travel() * SCROLL_PER_SLIDE,
          pin: true,
          scrub: true, // 1:1 with the (Lenis-smoothed) scroll position
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      /* Geometry can shift after first paint (font swap, image decode);
       * re-measure then. Resize is covered by invalidateOnRefresh +
       * ScrollTrigger's own resize refresh. */
      const st = tween.scrollTrigger!;
      let disposed = false;
      const refresh = () => {
        if (!disposed && ScrollTrigger.getAll().includes(st)) st.refresh();
      };
      document.fonts?.ready.then(refresh).catch(() => undefined);
      const imgs = Array.from(track.querySelectorAll("img"));
      const onImgLoad = () => refresh();
      imgs.forEach((img) => {
        if (!img.complete) img.addEventListener("load", onImgLoad, { once: true });
      });
      return () => {
        disposed = true;
        imgs.forEach((img) => img.removeEventListener("load", onImgLoad));
      };
    });
    return () => mm.revert();
  }, []);

  return (
    <section
      id="work"
      aria-labelledby="our-work-title"
      data-nav-theme="dark"
      className="our-work theme-canvas"
    >
      <div className="work-stage" ref={stageRef}>
        <div className="container-site">
          <h2 id="our-work-title" className="our-work-heading">Our work.</h2>
        </div>
        <div className="work-track" ref={trackRef}>
          {WORK_CASES.map((c) => (
            <div className="work-slide" key={c.slug}>
              <a
                className="work-card"
                href={`/case-study/${c.slug}`}
                aria-label={`${c.client}. ${c.subtitle}`}
                style={
                  {
                    "--wc-title": c.theme.title,
                    "--wc-sub": c.theme.subtitle,
                  } as CSSProperties
                }
              >
                <picture className="work-card__media">
                  <source media="(max-width: 767px)" srcSet={c.art.mobile} />
                  <source media="(max-width: 1023px)" srcSet={c.art.tablet} />
                  {/* Eager (not lazy): off-screen slides live inside the
                      translated track, so lazy art would pop in mid-scrub.
                      Local SVGs are tiny; dimensions are explicit to keep
                      the card free of layout shift. */}
                  <img
                    className="work-card__img"
                    src={c.art.desktop}
                    alt=""
                    width={2370}
                    height={661}
                    decoding="async"
                  />
                </picture>
                <article className="work-card__inner">
                  <div className="work-card__text">
                    <h3 className="work-card__title">{c.client}.</h3>
                    <p className="work-card__sub">{c.subtitle}</p>
                  </div>
                </article>
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
