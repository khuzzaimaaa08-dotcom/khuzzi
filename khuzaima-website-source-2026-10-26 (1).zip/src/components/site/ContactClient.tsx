"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { site } from "@/site.config";
import { REGIONS } from "@/lib/contact-schema";
import { gsap } from "@/lib/motion";
import person from "@/assets/contact-person.png";

const field =
  "w-full h-[clamp(52px,4.4vw,64px)] rounded-[24px] bg-paper px-6 text-[17px] text-ink placeholder:text-ink/80 outline-none transition-shadow duration-150 focus:shadow-[0_0_0_1.5px_var(--ink)]";

export function ContactClient() {
  const router = useRouter();
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const root = useRef<HTMLElement>(null);
  const img = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") router.push("/"); };
    window.addEventListener("keydown", onKey);
    root.current?.querySelector<HTMLInputElement>("input")?.focus({ preventScroll: true });
    const html = document.documentElement;
    const prev = html.style.overflow;
    html.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); html.style.overflow = prev; };
  }, [router]);

  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      const mm = gsap.matchMedia();
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        gsap.timeline({ defaults: { ease: "power3.out", duration: 0.4 } })
          .fromTo(el, { yPercent: -100 }, { yPercent: 0, duration: 0.55, ease: "expo.out", force3D: true, clearProps: "transform" }, 0)
          .from("[data-a=h] > span", { y: 16, opacity: 0 }, 0.15)
          .from("[data-a=img]", { scale: 0.96, opacity: 0 }, 0.15)
          .from("[data-a=f]", { y: 16, opacity: 0, stagger: 0.04 }, 0.19)
          .from("[data-a=x]", { opacity: 0 }, 0.2);
      });
    }, el);
    return () => ctx.revert();
  }, []);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const g = (k: string) => String(f.get(k) ?? "");
    setState("sending");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          first_name: g("first_name"),
          last_name: g("last_name"),
          email: g("email"),
          company: g("company"),
          job_title: g("job_title"),
          region: g("region"),
          message: g("message"),
        }),
      });
      if (!res.ok) throw new Error("Could not send");
      setState("done");
    } catch {
      setState("error");
    }
  }

  return (
    <main ref={root} role="dialog" aria-modal="true" aria-labelledby="contact-title"
      data-lenis-prevent
      className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden overscroll-contain bg-lilac text-ink [scrollbar-gutter:stable] [scroll-padding-block:96px_48px]">
      <div className="container-site relative min-h-dvh pb-[max(96px,calc(env(safe-area-inset-bottom)+72px))]">
      <div className="sticky top-0 z-10 -mb-14 flex h-14 justify-end translate-y-[max(24px,env(safe-area-inset-top))]">
      <Link href="/" aria-label="Close" data-a="x"
        className="group grid size-14 shrink-0 place-items-center rounded-full bg-ink text-paper transition-transform duration-200 hover:scale-[1.06] focus-visible:!rounded-full">
        <svg viewBox="0 0 24 24" className="size-5 transition-transform duration-300 group-hover:rotate-90" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
      </Link>
      </div>
      <div className="grid min-h-dvh items-center gap-8 py-24 md:grid-cols-12 md:gap-12">
        <div className="flex flex-col items-center md:col-span-5 md:items-start">
          <h1 id="contact-title" data-a="h" className="reveal-line mb-6 self-start text-[clamp(2.75rem,5vw,5rem)] font-extrabold">
            <span>Let&rsquo;s connect.</span>
          </h1>
          <div data-a="img" className="mix-blend-multiply aspect-square w-[min(100%,38vw,62vh)] max-md:w-[min(70vw,340px)]">
            <img ref={img} src={person.src} alt="" width={720} height={720} loading="eager" decoding="async" fetchPriority="high"
              className="size-full" />
          </div>
        </div>
        <div className="md:col-span-7">
          <div className="mx-auto w-full max-w-[680px]">
            {state === "done" ? (
              <div data-a="f" className="rounded-[24px] bg-paper p-8">
                <h2 className="text-3xl font-extrabold">Thanks, message received.</h2>
                <p className="mt-3 text-lg">We&rsquo;ll get back to you within one working day.</p>
                <Link href="/" className="btn-pill mt-6">Back to home</Link>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-[15px]">
                <div data-a="f" className="grid gap-[15px] min-[480px]:grid-cols-2">
                  <input name="first_name" required maxLength={100} placeholder="First Name*" aria-label="First name" className={field} />
                  <input name="last_name" required maxLength={100} placeholder="Last Name*" aria-label="Last name" className={field} />
                </div>
                <input data-a="f" name="email" type="email" required maxLength={255} placeholder="Work Email*" aria-label="Work email" className={field} />
                <div data-a="f" className="grid gap-[15px] min-[480px]:grid-cols-2">
                  <input name="company" required maxLength={150} placeholder="Company*" aria-label="Company" className={field} />
                  <input name="job_title" required maxLength={150} placeholder="Job Title*" aria-label="Job title" className={field} />
                </div>
                <fieldset data-a="f">
                  <legend className="mb-1 text-base font-semibold">Select a Region*</legend>
                  <div className="flex flex-wrap gap-x-7 text-base">
                    {REGIONS.map((r, i) => (
                      <label key={r} className="flex min-h-11 cursor-pointer items-center gap-2.5">
                        <input type="radio" name="region" value={r} required={i === 0} className="radio-ink" />{r}
                      </label>
                    ))}
                  </div>
                </fieldset>
                <textarea data-a="f" name="message" rows={4} maxLength={2000} placeholder="Message" aria-label="Message"
                  className={`${field} h-auto min-h-[clamp(110px,18vh,170px)] resize-y py-4`} />
                <div data-a="f" className="flex items-center gap-4">
                  <button type="submit" disabled={state === "sending"} className="btn-pill disabled:opacity-60">{state === "sending" ? "Sending…" : "Send message"}</button>
                  {state === "error" && <p role="alert">Something went wrong. Please try again.</p>}
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
      </div>
    </main>
  );
}
