/* Data-driven case-study cards for the "Our work." horizontal slider
   (OurWork.tsx) and the /case-study/[slug] stub pages.
 *
 * TODO(content): clients, one-line outcomes and artwork below are
 * placeholders in the Khuzaima Labs brand palette (aster + meridian are
 * light cards with ink text; northfield + halcyon are saturated cards
 * with white text). Swap the entries — and the SVGs in public/work/ —
 * for real case studies when content lands; the slider, card geometry
 * and case-study routes are all driven from this array.
 */

export type WorkCaseTheme = {
  /* Text colors on top of the card art (per-card theme tokens). */
  title: string;
  subtitle: string;
};

export type WorkCase = {
  slug: string;
  /** Display title — rendered on the card as "{client}." */
  client: string;
  /** One-line outcome; the card subtitle and the link's accessible name. */
  subtitle: string;
  theme: WorkCaseTheme;
  /** Art-directed placeholder art per breakpoint. */
  art: {
    desktop: string;
    tablet: string;
    mobile: string;
  };
};

const ART = (slug: string) => ({
  desktop: `/work/${slug}-desktop.svg`,
  tablet: `/work/${slug}-tablet.svg`,
  mobile: `/work/${slug}-mobile.svg`,
});

export const WORK_CASES: WorkCase[] = [
  {
    slug: "aster",
    client: "Aster",
    subtitle: "Logistics control towers, rebuilt around live data.",
    theme: { title: "#0D0B0A", subtitle: "rgba(0, 0, 0, 0.5)" },
    art: ART("aster"),
  },
  {
    slug: "northfield",
    client: "Northfield",
    subtitle: "Banking that clears in seconds, not days.",
    theme: { title: "#FFFFFF", subtitle: "rgba(255, 255, 255, 0.55)" },
    art: ART("northfield"),
  },
  {
    slug: "halcyon",
    client: "Halcyon",
    subtitle: "Fraud detection that thinks in real time.",
    theme: { title: "#FFFFFF", subtitle: "rgba(255, 255, 255, 0.55)" },
    art: ART("halcyon"),
  },
  {
    slug: "meridian",
    client: "Meridian",
    subtitle: "Renewable portfolios, monitored from anywhere.",
    theme: { title: "#0D0B0A", subtitle: "rgba(0, 0, 0, 0.5)" },
    art: ART("meridian"),
  },
];
