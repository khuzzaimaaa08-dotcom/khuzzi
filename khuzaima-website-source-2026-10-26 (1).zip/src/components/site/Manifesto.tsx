import { useEffect, useRef } from "react";
import { gsap, ScrollTrigger, MOTION_OK } from "@/lib/motion";

/* The statement interlude: one oversized editorial sentence, flat and full-width,
   in normal document flow between the hero's closing frame and the 11:42 pm demo.
   Type per spec: matter stack, 137px cap / 700 / 123px line / tightened tracking / #000.
   The closing accent word is set in the reference pink (#ff0391) and cycles —
   customers., users., businesses., culture., teams., people., brands., consumers.
   — every word carries its period. One word per second: the outgoing word lifts and fades behind a line-height
   mask while the next rises from below. The slot is measured to the widest word
   so swaps never shift the layout; before hydration (or without JS) it shows the
   final word, "consumers.", as static text. */

const WORDS = [
  "customers.",
  "users.",
  "businesses.",
  "culture.",
  "teams.",
  "people.",
  "brands.",
  "consumers.",
] as const;

const STEP = 1; // seconds each word holds
const SWAP = 0.42; // swap transition (spec: 350–450ms)
const FADE = 0.2; // reduced-motion crossfade

export function Manifesto() {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = root.current;
    if (!el) return;

    const rotator = el.querySelector<HTMLElement>(".manifesto-rotator");
    const sizer = el.querySelector<HTMLElement>(".manifesto-rotator-sizer");
    const words = gsap.utils.toArray<HTMLElement>(".manifesto-rotator-word", el);
    if (!rotator || !sizer || words.length === 0) return;

    // Size the slot to the widest word so every swap happens inside a stable
    // box — zero layout shift, nothing clipped. Re-measured on resize and once
    // fonts settle, because the cap scales with the viewport.
    const sizeToWidest = () => {
      const widest = Math.max(...words.map((w) => w.getBoundingClientRect().width));
      rotator.style.width = `${Math.ceil(widest) + 1}px`;
    };
    sizeToWidest();
    document.fonts.ready.then(() => sizeToWidest()).catch(() => {});
    window.addEventListener("resize", sizeToWidest);

    // Hand the slot from the static sizer to the animated words and start the
    // loop once the section scrolls into view.
    const armRotation = (tl: ReturnType<typeof gsap.timeline>) => {
      gsap.set(sizer, { opacity: 0 });
      gsap.set(words, { yPercent: 0, autoAlpha: 0 });
      gsap.set(words[0], { autoAlpha: 1 });
      let armed = false;
      const st = ScrollTrigger.create({
        trigger: el,
        start: "top 76%",
        once: true,
        onEnter: () => {
          armed = true;
          tl.play();
        },
      });
      /* Task 33: pause the rotation while the section is off-screen. The
         cycle is time-based, not scroll-based, so nothing visible changes —
         it just stops ticking GSAP frames for an unseen animation. The
         armed flag keeps the original "top 76%" start moment untouched. */
      const io = new IntersectionObserver(
        (entries) => {
          if (!armed) return;
          const e = entries[entries.length - 1];
          if (e.isIntersecting) tl.play();
          else tl.pause();
        },
        { rootMargin: "10% 0px" },
      );
      io.observe(el);
      return () => {
        io.disconnect();
        st.kill();
        tl.kill();
      };
    };

    const mm = gsap.matchMedia();

    mm.add(MOTION_OK, () => {
      // Masked block reveal — the site's signature entrance, fired once on entry.
      gsap.fromTo(el.querySelectorAll(".reveal-line > span"), { yPercent: 112 }, {
        yPercent: 0, duration: 1.25, ease: "power4.out",
        scrollTrigger: { trigger: el, start: "top 76%", once: true },
      });

      const tl = gsap.timeline({ repeat: -1, paused: true });
      words.forEach((word, i) => {
        tl.to(word, { yPercent: -112, autoAlpha: 0, duration: SWAP, ease: "power3.inOut" }, i * STEP)
          .fromTo(words[(i + 1) % words.length],
            { yPercent: 112, autoAlpha: 0 },
            { yPercent: 0, autoAlpha: 1, duration: SWAP, ease: "power3.inOut", immediateRender: false },
            i * STEP);
      });
      tl.to({}, { duration: Math.max(0, WORDS.length * STEP - tl.duration()) });
      return armRotation(tl);
    });

    mm.add("(prefers-reduced-motion: reduce)", () => {
      // Same rotation, gentle crossfade only — no movement.
      const tl = gsap.timeline({ repeat: -1, paused: true });
      words.forEach((word, i) => {
        tl.to(word, { autoAlpha: 0, duration: FADE }, i * STEP)
          .to(words[(i + 1) % words.length], { autoAlpha: 1, duration: FADE }, i * STEP + FADE);
      });
      tl.to({}, { duration: Math.max(0, WORDS.length * STEP - tl.duration()) });
      return armRotation(tl);
    });

    return () => {
      window.removeEventListener("resize", sizeToWidest);
      mm.revert();
    };
  }, []);

  return (
    <section ref={root} id="manifesto" aria-labelledby="manifesto-title" data-nav-theme="light" className="bg-white">
      <div className="container-site pt-[clamp(5rem,13.5vh,9.5rem)] pb-[clamp(5.5rem,15vh,10.5rem)]">
        <h2 id="manifesto-title" className="manifesto-text">
          <span className="reveal-line">
            <span>
              We make things that
              <span className="hidden md:block" />
              {" "}matter to <span className="manifesto-rotator">
                <span className="manifesto-rotator-sizer">consumers.</span>
                {WORDS.map((word) => (
                  <span key={word} className="manifesto-rotator-word" aria-hidden="true">{word}</span>
                ))}
              </span>
            </span>
          </span>
        </h2>
      </div>
    </section>
  );
}
