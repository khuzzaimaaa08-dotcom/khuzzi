import { useEffect, useRef } from "react";
import Link from "next/link";
import { gsap, ScrollTrigger, MOTION_OK } from "@/lib/motion";
import { Magnetic } from "./Magnetic";
import { HeroScenery, type SceneryHandle } from "./HeroScenery";
import { HeroSkyLayers, GoldenHourGlow, type SkyHandle } from "./HeroSkyLayers";
import { HeroNightLayers, type NightHandle } from "./HeroNightLayers";

const START = 9 * 60;
const END = 23 * 60 + 42;
const LINES = [
  { at: 9 * 60, text: "Doors open. Phones ring." },
  { at: 13 * 60, text: "The front desk is busy." },
  { at: 20 * 60, text: "You close for the day." },
  { at: 23 * 60 + 42, text: "A patient messages." },
];

const fmt = (m: number) => {
  const h24 = Math.floor(m / 60);
  const mm = String(Math.floor(m % 60)).padStart(2, "0");
  const h = h24 % 12 === 0 ? 12 : h24 % 12;
  return { time: `${h}:${mm}`, ap: h24 < 12 ? "am" : "pm" };
};

export function Hero() {
  const root = useRef<HTMLElement>(null);
  const clock = useRef<HTMLSpanElement>(null);
  const ampm = useRef<HTMLSpanElement>(null);
  const line = useRef<HTMLParagraphElement>(null);
  const orb = useRef<SVGGElement>(null);
  const moon = useRef<SVGCircleElement>(null);
  const h1 = useRef<HTMLHeadingElement>(null);
  const scene = useRef<SceneryHandle>(null);
  const sky = useRef<SkyHandle>(null);
  const glow = useRef<SkyHandle>(null);
  const night = useRef<NightHandle>(null);

  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const mm = gsap.matchMedia();
    mm.add(MOTION_OK, () => {
      el.dataset["motion"] = "on";
      const layers = el.querySelectorAll<HTMLElement>("[data-sky]");
      let lastLine = -1;
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: el,
          start: "top top",
          end: "bottom bottom",
          scrub: 1,
          onUpdate: (st) => {
            const p = st.progress;
            const m = START + (END - START) * p;
            scene.current?.update(m);
            sky.current?.update(m);
            glow.current?.update(m);
            const f = fmt(m);
            if (clock.current && clock.current.textContent !== f.time) clock.current.textContent = f.time;
            if (ampm.current && ampm.current.textContent !== f.ap) ampm.current.textContent = f.ap;
            let idx = 0;
            LINES.forEach((l, i) => { if (m >= l.at - 0.5) idx = i; });
            if (idx !== lastLine) {
              lastLine = idx;
              gsap.fromTo(line.current, { yPercent: 100, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 0.5, ease: "power3.out" });
              if (line.current) line.current.textContent = LINES[idx]?.text ?? "";
            }
            const isNight = p > 0.62;
            el.classList.toggle("is-night", isNight);
            // Publish the hero's text tone for the adaptive navbar: data-hero-tone
            // mirrors the headline's own ink→paper flip. The navbar's theme tag is
            // deliberately NOT tied to that flip: the dusk sky (≈6–9:30 pm) is a
            // lilac→ultramarine crossfade whose luminance only drops below the
            // WCAG 4.5:1 floor for #F5F7FF near p≈0.86, so the nav keeps its dark
            // foreground (≥4.3:1 throughout dusk, 6.5:1 on full ultramarine) until
            // the sky is genuinely night — the tone-threshold-only remedy the
            // navbar spec prescribes for a failing hero color.
            el.dataset.heroTone = isNight ? "light" : "dark";
            const navTheme = p > 0.855 ? "dark" : "light";
            if (el.dataset.navTheme !== navTheme) el.dataset.navTheme = navTheme;
            // orb along arc
            const a = Math.PI * (1 - p);
            gsap.set(orb.current, { x: 500 + Math.cos(a) * 420, y: 260 - Math.sin(a) * 200 });
            gsap.set(moon.current, { attr: { cx: 80 - 66 * gsap.utils.clamp(0, 1, (p - 0.6) / 0.15) } });
            night.current?.update(m, p);
          },
        },
      });
      tl.to(layers[1] as HTMLElement, { opacity: 1, ease: "none", duration: 1 }, 0.25)
        .to(layers[2] as HTMLElement, { opacity: 1, ease: "none", duration: 1 }, 1.5)
        .to(layers[3] as HTMLElement, { opacity: 1, ease: "none", duration: 1 }, 2.6)
        .set({}, {}, 4);
      ScrollTrigger.refresh();
      // Dev aid: ?t=HH:MM jumps to that clock time (never in production).
      const t = process.env.NODE_ENV === "development" ? new URLSearchParams(location.search).get("t") : null;
      if (t && /^\d{1,2}:\d{2}$/.test(t)) {
        const [h, mi] = t.split(":").map(Number);
        const p = gsap.utils.clamp(0, 1, ((h ?? 0) * 60 + (mi ?? 0) - START) / (END - START));
        requestAnimationFrame(() => window.scrollTo(0, el.offsetTop + (el.offsetHeight - window.innerHeight) * p));
      }
      return () => {
          el.dataset["motion"] = "off";
          el.classList.remove("is-night");
          el.dataset.heroTone = "dark";
          el.dataset.navTheme = "light";
        };
    });
    return () => mm.revert();
  }, []);

  return (
    <section
      ref={root}
      id="top"
      aria-labelledby="hero-title"
      data-motion="off"
      data-nav-theme="light"
      data-hero-tone="dark"
      className="group relative data-[motion=on]:h-[400vh]"
    >
      <div className="relative min-h-[100svh] overflow-hidden group-data-[motion=on]:sticky group-data-[motion=on]:top-0 group-data-[motion=on]:h-[100svh]">
        {/* Sky layers: the only gradient story on the page */}
        <div data-sky className="absolute inset-0 bg-tangerine" />
        <div data-sky className="absolute inset-0 bg-sun opacity-0" />
        <div data-sky className="absolute inset-0 bg-lilac opacity-0" />
        <div data-sky className="absolute inset-0 bg-ultramarine opacity-0 group-data-[motion=off]:opacity-0" />
        <HeroScenery ref={scene} />
        <HeroSkyLayers ref={sky} />

        <HeroNightLayers ref={night} />

        <svg aria-hidden data-hero-arc viewBox="0 0 1000 300" className="pointer-events-none absolute inset-x-0 top-[14%] mx-auto w-[min(1100px,120vw)] opacity-90" preserveAspectRatio="xMidYMid meet">
          <path d="M80 260 A420 200 0 0 1 920 260" fill="none" stroke="currentColor" strokeOpacity=".25" strokeDasharray="2 10" strokeWidth="2" className="text-ink group-[.is-night]:text-paper" />
          <g ref={orb} transform="translate(80 260)">
            <mask id="moon-cut" maskUnits="userSpaceOnUse" x="-40" y="-40" width="80" height="80">
              <rect x="-40" y="-40" width="80" height="80" fill="white" />
              <circle ref={moon} r="30" cx="80" cy="-8" fill="black" />
            </mask>
            <GoldenHourGlow ref={glow} />
            <circle r="34" className="fill-sun" mask="url(#moon-cut)" />
          </g>
        </svg>
        <div className="container-site relative flex h-full min-h-[100svh] flex-col justify-end pb-[8vh] pt-28 text-ink transition-colors duration-500 group-[.is-night]:text-paper">
          <div
            data-hero-ex
            className="mb-10 self-end text-right font-display tabular md:absolute md:right-[var(--gutter,1.5rem)] md:top-[calc(var(--nav-h)+16px)] md:mb-0 lg:right-10"
            aria-hidden
          >
            <div className="mb-3 flex items-center justify-end gap-3 text-[0.7rem] font-semibold uppercase tracking-[0.25em] opacity-70">
              <span className="h-px w-10 bg-current" />
              Local time
            </div>
            <div className="flex items-start justify-end gap-2 leading-none">
              <span ref={clock} className="text-[clamp(3rem,7vw,6.5rem)] font-extrabold tracking-[-0.05em] [@media(max-height:650px)]:text-[3rem]">9:00</span>
              <span ref={ampm} className="mt-[0.4em] text-[clamp(0.9rem,1.4vw,1.25rem)] font-semibold uppercase tracking-[0.15em]">am</span>
            </div>
            <p ref={line} className="mt-3 h-6 overflow-hidden text-sm font-medium opacity-80 md:text-base">
              Doors open. Phones ring.
            </p>
          </div>
          <h1
            ref={h1}
            id="hero-title"
            className="max-w-[13ch] text-[clamp(2.5rem,7vw,6.75rem)] !leading-[0.92] tracking-[-0.035em] md:max-w-[60%] lg:max-w-[13ch]"
            style={{ fontVariationSettings: '"wdth" 100, "wght" 600' }}
          >
            Every inquiry answered, even at 11&nbsp;pm.
          </h1>
          <div data-hero-ex className="mt-8 grid gap-8 md:grid-cols-12 md:items-end">
            <p className="max-w-[60ch] text-lg md:col-span-7">
              We build WhatsApp and website assistants for clinics and real estate teams in Pakistan and the UAE, so no booking request or property inquiry waits until morning.
            </p>
            <div className="md:col-span-5 md:justify-self-end">
              <Magnetic>
                <Link href="/book" data-cursor="book" className="btn-pill group-[.is-night]:btn-pill-light">
                  Book a free 15-minute call
                </Link>
              </Magnetic>
            </div>
          </div>
          <p className="sr-only">The hero tells a story across one day: 9 am doors open, 1 pm the front desk is busy, 8 pm you close, 11:42 pm a patient messages.</p>
        </div>
      </div>
    </section>
  );
}