/* The brand showcase: a wall of eight Pakistani client marks set directly
   below the craft statement ("human judgment."), mirroring the reference's
   logo-wall geometry — wrapping 8px-gap grid (2-up / 3-up / 4-up), square
   warm-white #FAF8F4 tiles, 8px radii, no borders or shadows, and per-brand
   optical size caps so every mark carries equal visual weight.

   The logos are authentic brand assets (official sites, brand apps, and
   Wikimedia Commons) in a uniform monochrome treatment — letterforms
   preserved exactly, rendered as solid dark-charcoal #242424 ink at full
   opacity with anti-aliased edges (scripts/darken-brand-logos.py; the
   originals live in scripts/brand-logos-backup-v1/). One substitution from
   the requested list: LAMA → Shan Foods (see worklog — LAMA's official mark
   could not be verified from any trustworthy source, and Shan's authentic
   asset was; swap back by adding a verified LAMA file and updating BRANDS). */

const BRANDS = [
  { name: "HBL", file: "hbl", alt: "HBL — Habib Bank Limited", w: "66%", h: "20%" },
  { name: "Meezan Bank", file: "meezan", alt: "Meezan Bank", w: "62%", h: "19%" },
  { name: "Jazz", file: "jazz", alt: "Jazz", w: "34%", h: "29%" },
  { name: "Khaadi", file: "khaadi", alt: "Khaadi", w: "70%", h: "15%" },
  { name: "Shan Foods", file: "shan", alt: "Shan Foods", w: "44%", h: "22%" },
  { name: "Sapphire", file: "sapphire", alt: "Sapphire", w: "46%", h: "23%" },
  { name: "Systems Limited", file: "systems", alt: "Systems Limited", w: "64%", h: "17%" },
  { name: "Bank Alfalah", file: "alfalah", alt: "Bank Alfalah", w: "52%", h: "31%" },
] as const;

/* Intrinsic source dimensions (px) for correct aspect-ratio reservation. */
const SIZES: Record<string, { width: number; height: number }> = {
  hbl: { width: 365, height: 107 },
  meezan: { width: 958, height: 289 },
  jazz: { width: 1040, height: 850 },
  khaadi: { width: 832, height: 171 },
  shan: { width: 483, height: 235 },
  sapphire: { width: 1024, height: 500 },
  systems: { width: 1470, height: 391 },
  alfalah: { width: 1588, height: 914 },
};

export function BrandShowcase() {
  return (
    <section aria-label="Selected clients" data-nav-theme="light" className="brand-show bg-white">
      <div className="container-site">
        <ul className="brand-grid">
          {BRANDS.map((brand) => {
            const size = SIZES[brand.file];
            return (
              <li key={brand.file} className="brand-cell">
                <div className="brand-card">
                  <span className="brand-card-sizer" aria-hidden="true" />
                  <span className="brand-logo-box">
                    <img
                      src={`/brands/${brand.file}.png`}
                      alt={brand.alt}
                      width={size.width}
                      height={size.height}
                      loading="lazy"
                      decoding="async"
                      className="brand-logo"
                      style={{ "--logo-w": brand.w, "--logo-h": brand.h } as React.CSSProperties}
                    />
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
