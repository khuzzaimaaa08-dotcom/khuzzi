import { useLayoutEffect, type RefObject } from "react";

export const HIDDEN = { visibility: "hidden", opacity: 0 } as const;

/* Per-element last-written signature (Task 33): the scrub loops call show()
   on ~180 scenery elements every scroll frame; most are off-stage with
   unchanged values at any given moment. Skipping identical writes keeps
   style recalc scoped to the elements that actually changed — the rendered
   result is byte-identical. */
const showSig = new WeakMap<Element, string>();

export function show(n: HTMLElement | SVGElement | null | undefined, opacity: number) {
  if (!n) return false;
  const on = opacity > 0.001;
  const sig = on ? `v${opacity.toFixed(3)}` : "0";
  if (showSig.get(n) === sig) return on;
  showSig.set(n, sig);
  n.style.opacity = on ? opacity.toFixed(3) : "0";
  n.style.visibility = on ? "visible" : "hidden";
  n.classList.toggle("scn-off", !on);
  return on;
}

/** Exclude real copy bounds rather than guessing where text wraps at each size. */
export function useSceneBounds(root: RefObject<HTMLDivElement | null>, measure: (w: number, h: number) => void) {
  useLayoutEffect(() => {
    const el = root.current;
    const hero = el?.parentElement;
    if (!el || !hero) return;
    const update = () => {
      const b = el.getBoundingClientRect();
      const rects = [{ x: 0, y: 0, w: b.width, h: 90 }];
      hero.querySelectorAll<HTMLElement>("#hero-title, [data-hero-ex]").forEach((n) => {
        const r = n.getBoundingClientRect();
        rects.push({ x: r.left - b.left - 24, y: r.top - b.top - 24, w: r.width + 48, h: r.height + 48 });
      });
      // Feathered luminance mask: black rects (blurred) protect copy, white shows
      // the scene — soft edges instead of a hard rectangular cutout.
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${b.width}" height="${b.height}"><defs><filter id="f"><feGaussianBlur stdDeviation="14"/></filter></defs><rect width="100%" height="100%" fill="white"/><g filter="url(#f)">${rects.map((r) => `<rect x="${r.x}" y="${r.y}" width="${r.w}" height="${r.h}" fill="black"/>`).join("")}</g></svg>`;
      const mask = `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
      el.querySelectorAll<HTMLElement>("[data-copy-safe]").forEach((n) => {
        n.style.maskImage = mask;
        n.style.maskMode = "luminance";
        n.style.maskSize = "100% 100%";
      });
      measure(b.width || 1, b.height || 1);
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    hero.querySelectorAll<HTMLElement>("#hero-title, [data-hero-ex]").forEach((n) => observer.observe(n));
    document.fonts.ready.then(update);
    return () => observer.disconnect();
  }, [root, measure]);
}