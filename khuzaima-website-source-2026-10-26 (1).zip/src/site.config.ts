// Single source of truth for brand + contact details. Edit here only.
export const site = {
  name: "Khuzaima Labs",
  shortName: "Khuzaima",
  domain: "khuzaimalabs.com",
  url: "https://khuzaimalabs.com",
  email: (process.env.NEXT_PUBLIC_CONTACT_EMAIL as string | undefined) ?? "hello@khuzaimalabs.com",
  whatsapp: (process.env.NEXT_PUBLIC_WHATSAPP_URL as string | undefined) ?? "https://wa.me/920000000000",
  location: "Karachi, Pakistan",
};

export const mailtoBooking = () => {
  const subject = "Free 15-minute call";
  const body =
    "Hi Khuzaima,\n\nI run a (clinic / real estate team) in (city).\nRight now inquiries reach us through:\n\nThe best time for a 15-minute call is:\n\nThanks,";
  return `mailto:${site.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
};
