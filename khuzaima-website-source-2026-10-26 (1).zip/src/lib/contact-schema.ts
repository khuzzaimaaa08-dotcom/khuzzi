import { z } from "zod";

export const REGIONS = ["North America", "Latin America", "Asia Pacific", "Europe, the Middle East, and Africa", "Global"] as const;

export const contactSchema = z.object({
  first_name: z.string().trim().min(1).max(100),
  last_name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  company: z.string().trim().min(1).max(150),
  job_title: z.string().trim().min(1).max(150),
  region: z.enum(REGIONS),
  message: z.string().trim().max(2000).optional(),
});

export type ContactInput = z.infer<typeof contactSchema>;
