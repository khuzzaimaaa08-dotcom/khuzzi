import { z } from "zod";

export const TOPICS = ["Clinic", "Real estate team", "Something else"] as const;

export const TIME_SLOTS = [
  "09:00", "09:45", "10:30", "11:15", "12:00",
  "14:00", "14:45", "15:30", "16:15", "17:00",
] as const;

const dateRe = /^\d{4}-\d{2}-\d{2}$/;

/** Weekday + within the next 21 days (server-side sanity, same rules as the picker). */
export function validCallDate(iso: string): boolean {
  if (!dateRe.test(iso)) return false;
  const d = new Date(`${iso}T00:00:00Z`);
  if (Number.isNaN(d.getTime())) return false;
  const dow = d.getUTCDay();
  if (dow === 0 || dow === 6) return false;
  const today = new Date();
  const start = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
  const max = start + 21 * 86_400_000;
  const t = d.getTime();
  return t >= start && t <= max;
}

export const bookingSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(255),
  company: z.string().trim().min(2).max(150),
  topic: z.enum(TOPICS),
  call_date: z.string().trim().regex(dateRe),
  call_time: z.enum(TIME_SLOTS),
  notes: z.string().trim().max(1000).optional(),
});

export type BookingInput = z.infer<typeof bookingSchema>;
