import type { Metadata } from "next";
import { site } from "@/site.config";
import { ContactClient } from "@/components/site/ContactClient";

const title = `Let's connect | ${site.name}`;
const description =
  "Tell us about your clinic or real estate team and we'll reply within one working day.";

export const metadata: Metadata = {
  title: { absolute: title },
  description,
  openGraph: {
    title,
    description,
    type: "website",
  },
  twitter: {
    card: "summary",
    title,
    description,
  },
};

export default function ContactPage() {
  return <ContactClient />;
}
