import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { bookingSchema, validCallDate } from "@/lib/booking-schema";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const data = bookingSchema.parse(body);
    if (!validCallDate(data.call_date)) {
      return NextResponse.json({ error: "Invalid date" }, { status: 400 });
    }

    // One pending booking per slot; 409 lets the UI offer the next free time.
    const clash = await db.callBooking.findFirst({
      where: { callDate: data.call_date, callTime: data.call_time, status: "pending" },
      select: { id: true },
    });
    if (clash) {
      return NextResponse.json({ error: "Slot taken" }, { status: 409 });
    }

    const booking = await db.callBooking.create({
      data: {
        name: data.name,
        email: data.email,
        company: data.company,
        topic: data.topic,
        callDate: data.call_date,
        callTime: data.call_time,
        notes: data.notes || null,
      },
    });
    return NextResponse.json({ ok: true, id: booking.id });
  } catch (error) {
    console.error("Call booking failed:", error);
    return NextResponse.json({ error: "Could not book" }, { status: 400 });
  }
}
