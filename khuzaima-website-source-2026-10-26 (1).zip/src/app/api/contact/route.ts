import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { contactSchema } from "@/lib/contact-schema";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const data = contactSchema.parse(body);
    await db.contactSubmission.create({
      data: {
        firstName: data.first_name,
        lastName: data.last_name,
        email: data.email,
        company: data.company,
        jobTitle: data.job_title,
        region: data.region,
        message: data.message || null,
      },
    });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Contact submission failed:", error);
    return NextResponse.json({ error: "Could not send" }, { status: 400 });
  }
}
