import type { Metadata } from "next";
import { BookClient } from "@/components/site/BookClient";

export const metadata: Metadata = {
  title: "Book a free 15-minute call",
  description:
    "Fifteen minutes, zero pitch. Tell us where inquiries pile up and leave with a plan — free calls for clinics and real estate teams.",
  alternates: { canonical: "/book" },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  name: "Book a free 15-minute call — Khuzaima Labs",
  description: "Free 15-minute discovery call for clinics and real estate teams.",
};

export default function BookPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <BookClient />
    </>
  );
}
