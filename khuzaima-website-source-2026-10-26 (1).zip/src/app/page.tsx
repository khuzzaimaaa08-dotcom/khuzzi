import type { Metadata } from "next";
import { site } from "@/site.config";
import { HomeClient } from "@/components/site/HomeClient";

const title = `${site.name} | AI assistants for clinics and real estate`;
const description =
  "WhatsApp and website assistants for clinics and real estate teams in Pakistan and the UAE, so no inquiry waits until morning.";

export const metadata: Metadata = {
  title,
  description,
  alternates: { canonical: site.url },
  openGraph: {
    title,
    description,
    type: "website",
    url: site.url,
  },
  twitter: {
    card: "summary_large_image",
    title,
    description,
  },
};

export default function Index() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: site.name,
    url: site.url,
    email: site.email,
    address: { "@type": "PostalAddress", addressLocality: "Karachi", addressCountry: "PK" },
    areaServed: ["PK", "AE"],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <HomeClient />
    </>
  );
}
