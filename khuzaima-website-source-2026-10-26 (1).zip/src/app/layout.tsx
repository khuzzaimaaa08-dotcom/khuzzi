import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Khuzaima Labs",
    template: "%s | Khuzaima Labs",
  },
  description:
    "AI assistants and premium websites for clinics and real estate teams.",
  authors: [{ name: "Khuzaima Labs" }],
  openGraph: {
    type: "website",
    siteName: "Khuzaima Labs",
    url: "https://khuzaimalabs.com",
  },
  twitter: {
    card: "summary_large_image",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,200..800&family=DM+Sans:opsz,wght@9..40,400..700&display=swap"
        />
        {/* The matter stack's workhorse weight (nav index, manifesto, craft
            statement all resolve here) — preloaded to cut the swap flash. */}
        <link
          rel="preload"
          href="/fonts/matter-semibold.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
