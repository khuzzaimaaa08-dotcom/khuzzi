import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { WORK_CASES } from "@/components/site/our-work-cases";

/* Case-study stub pages — the /case-study/{slug} destinations the "Our
 * work." slider cards link to.
 *
 * TODO(content): these are intentionally minimal placeholders (headline +
 * one-line outcome + note + back link) so the card links resolve; replace
 * with real case-study layouts when content lands. Unknown slugs 404. */

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return WORK_CASES.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const c = WORK_CASES.find((x) => x.slug === slug);
  return { title: c ? `${c.client}. — Case study` : "Case study" };
}

export default async function CaseStudyPage({ params }: Props) {
  const { slug } = await params;
  const c = WORK_CASES.find((x) => x.slug === slug);
  if (!c) notFound();

  return (
    <main className="case-study-page">
      <div className="container-site">
        <Link href="/#work" className="case-back">
          <svg viewBox="0 0 16 16" width="14" height="14" fill="none" aria-hidden="true">
            <path d="M13 8H3m0 0 4.5-4.5M3 8l4.5 4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Back to our work
        </Link>
        <h1>{c.client}.</h1>
        <p className="case-study-lede">{c.subtitle}</p>
        <p className="case-study-soon">
          Full case study coming soon — this page is a placeholder while the
          story is being written.
        </p>
      </div>
    </main>
  );
}
