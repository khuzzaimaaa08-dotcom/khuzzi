#!/usr/bin/env python3
"""ASCII visualization of the reference image to see layout structure."""
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792417586109.png").convert("RGB")
W, H = img.size
px = img.load()

COLS, ROWS = 110, 44
cw, ch = W / COLS, H / ROWS

for gy in range(ROWS):
    line = []
    for gx in range(COLS):
        d = p = 0
        for y in range(int(gy * ch), min(H, int((gy + 1) * ch)), 3):
            for x in range(int(gx * cw), min(W, int((gx + 1) * cw)), 3):
                r, g, b = px[x, y]
                if r < 90 and g < 90 and b < 90: d += 1
                elif r > 180 and g < 130 and 90 < b < 220 and (r - g) > 80: p += 1
        if p > 2: line.append("P")
        elif d > 6: line.append("#")
        elif d > 1: line.append(".")
        else: line.append(" ")
    print("".join(line))
