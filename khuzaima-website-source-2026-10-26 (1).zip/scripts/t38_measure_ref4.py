#!/usr/bin/env python3
"""Pass 4: decisive fine measurements.
- Title 'N' cap span vs description 'E' cap span (font size comparison)
- Desc line bands with loose mask
- Showreel exact bbox, border, pill
"""
from PIL import Image
import numpy as np

im = Image.open("/home/z/my-project/upload/pasted_image_1792667125776.png").convert("RGB")
a = np.asarray(im).astype(int)

def rows_of(mask, x0, x1, y0, y1, thresh=0):
    sub = mask[y0:y1, x0:x1]
    rr = np.where(sub.sum(axis=1) > thresh)[0]
    return (y0 + rr.min(), y0 + rr.max()) if len(rr) else None

# Title first letter 'N': x 108-140 (white, >200)
wm = (a[:,:,0] > 200) & (a[:,:,1] > 200) & (a[:,:,2] > 200)
print("title N rows:", rows_of(wm, 106, 145, 170, 270), " (cap span)")
# title full extent
print("title full rows:", rows_of(wm, 100, 340, 170, 270))
print("title full cols x:", end=" ")
sub = wm[170:270, 100:340]
cc = np.where(sub.any(axis=0))[0]
print(100 + cc.min(), 100 + cc.max())

# Desc line 1 'E' of Enabling: x 105-145, y 280-370 — pale (brighter than bg, not pure white)
pm = (a[:,:,0] > 165) & (a[:,:,1] > 190) & (a[:,:,2] > 215)
print("desc E rows (x105-150):", rows_of(pm, 100, 155, 280, 375))
# desc line 1 full band
print("desc line1 rows (x100-780):", rows_of(pm, 100, 780, 280, 375))
print("desc line2 rows (x100-780):", rows_of(pm, 100, 780, 360, 450))
print("desc line3 rows (x100-780):", rows_of(pm, 100, 780, 435, 545))
# desc col extents per line
for name, y0, y1 in [("l1", 290, 365), ("l2", 365, 440), ("l3", 440, 520)]:
    sub = pm[y0:y1, 60:900]
    cc = np.where(sub.any(axis=0))[0]
    if len(cc):
        print(f"desc {name} cols: {60+cc.min()}-{60+cc.max()} w={cc.max()-cc.min()}")

# sample desc glyph color mid-stroke
print("desc color sample:", tuple(a[325, 130]), tuple(a[325, 200]))

# ---- SHOWREEL precise ----
# white border ring: white pixels in x 1400-1850, y 240-570
wm2 = (a[:,:,0] > 225) & (a[:,:,1] > 232) & (a[:,:,2] > 238)
sub = wm2[240:570, 1400:1850]
ys, xs = np.where(sub)
print(f"\nshowreel white-border pixels: y {240+ys.min()}-{240+ys.max()} x {1400+xs.min()}-{1400+xs.max()} count {len(ys)}")
# pink interior
pk = (a[:,:,0] > 150) & (a[:,:,1] < 140) & (a[:,:,2] > 90) & (a[:,:,2] < 215)
sub = pk[240:570, 1400:1850]
ys, xs = np.where(sub)
print(f"showreel pink pixels: y {240+ys.min()}-{240+ys.max()} x {1400+xs.min()}-{1400+xs.max()} count {len(ys)}")
# black interior incl border: dark pixels
bk = (a[:,:,0] < 45) & (a[:,:,1] < 45) & (a[:,:,2] < 55)
sub = bk[240:570, 1400:1850]
ys, xs = np.where(sub)
print(f"showreel black pixels: y {240+ys.min()}-{240+ys.max()} x {1400+xs.min()}-{1400+xs.max()}")

# scan a vertical line at x=1650 (through showreel) from y=240 to 570: classify pixels
print("\nvertical scan x=1650:")
for y in range(240, 570, 6):
    r, g, b = tuple(a[y, 1650])
    c = ("W" if r > 225 and b > 238 else "P" if r > 150 and g < 140 else "#" if r < 45 and g < 45 else "g" if 60 < r < 200 and g < 160 else ".")
    print(f"  y{y}: rgb({r},{g},{b}) {c}", end="")
print()
# horizontal scan y=460 through showreel
print("horizontal scan y=460, x 1420-1850:")
out = []
for x in range(1420, 1850, 6):
    r, g, b = tuple(a[460, x])
    c = ("W" if r > 225 and b > 238 else "P" if r > 150 and g < 140 else "#" if r < 45 and g < 45 else "g" if 60 < r < 200 and g < 160 else ".")
    out.append(f"x{x}:{c}")
print(" ".join(out))
