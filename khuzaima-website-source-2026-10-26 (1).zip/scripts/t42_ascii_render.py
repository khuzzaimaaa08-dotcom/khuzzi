#!/usr/bin/env python3
"""Task 42 — ASCII-map the RENDERED phones zone with the same classifier
used for the reference, for a direct visual diff."""
import sys
from PIL import Image

path = sys.argv[1] if len(sys.argv) > 1 else "qa/work-t42/v03-phones-v2.png"
x0, y0, x1, y1 = (int(v) for v in sys.argv[2].split(",")) if len(sys.argv) > 2 else (57, 120, 57+1793, 120+498)

img = Image.open(path).convert("RGB")
W, H = img.size
px = img.load()
print(f"image {W}x{H}, zone ({x0},{y0})-({x1},{y1}) size {x1-x0}x{y1-y0}")
cw, chh = x1 - x0, y1 - y0

def sym(x, y):
    r, g, b = px[x, y]
    if r > 225 and g > 232 and b > 238: return "W"
    if r > 185 and g < 140 and r - g > 80: return "K"
    if r < 45 and g < 45 and b < 50: return "k"
    if r < 30 and g < 55 and 25 < b < 100 and b > r + 10: return "n"
    if b > 110 and b - r > 55 and g < 175: return "."
    if r > 200 and g > 190 and b > 160: return "c"
    return "?"

COLS, ROWS = 110, 26
for j in range(ROWS):
    line = ""
    for i in range(COLS):
        xa = x0 + int(cw * i / COLS); xb = x0 + int(cw * (i + 1) / COLS)
        ya = y0 + int(chh * j / ROWS); yb = y0 + int(chh * (j + 1) / ROWS)
        line += sym(xa, ya)
    print(f"{j*chh/ROWS:5.0f} {line}")
