#!/usr/bin/env python3
"""Pixel-analyze the Huge navbar reference screenshot: geometry, colors, glow profile."""
from PIL import Image
import numpy as np

img = Image.open("/home/z/my-project/upload/pasted_image_1792513631375.png").convert("RGB")
a = np.array(img).astype(np.int32)
H, W = a.shape[:2]
print(f"image: {W}x{H}")

# --- pink wordmask (hot pink: high R, low-mid G, mid-high B) ---
r, g, b = a[:,:,0], a[:,:,1], a[:,:,2]
pink = (r > 150) & (g < 120) & (b > 60) & (b < 200)
ys, xs = np.where(pink)
if len(xs):
    print(f"pink pixels: {len(xs)}  bbox x[{xs.min()},{xs.max()}] y[{ys.min()},{ys.max()}]  wordmark h={ys.max()-ys.min()+1}px")

# --- white text / button (near-white) ---
white = (r > 225) & (g > 225) & (b > 225)
# column profile of white pixels to find button vs links
colw = white.sum(axis=0)
# find button: contiguous white run of tall column counts (>25px)
runs, start = [], None
for x in range(W):
    if colw[x] > 25 and start is None: start = x
    elif colw[x] <= 25 and start is not None: runs.append((start, x-1)); start = None
if start is not None: runs.append((start, W-1))
runs = [(s,e) for s,e in runs if e-s > 40]
print("white column runs (button candidates):", runs)
if runs:
    s, e = max(runs, key=lambda t: t[1]-t[0])
    sub = white[:, s:e+1]
    ys2 = np.where(sub.any(axis=1))[0]
    print(f"  biggest: x[{s},{e}] w={e-s+1} y[{ys2.min()},{ys2.max()}] h={ys2.max()-ys2.min()+1}")

# link text: white-ish pixels with lower column counts
linkw = white.copy()
if runs:
    s, e = max(runs, key=lambda t: t[1]-t[0])
    linkw[:, s:e+1] = False
coll = linkw.sum(axis=0)
lruns, start = [], None
for x in range(W):
    if coll[x] > 2 and start is None: start = x
    elif coll[x] <= 2 and start is not None:
        if x-1-start > 3: lruns.append((start, x-1))
        start = None
print(f"link-text runs: {len(lruns)}", lruns)

# --- background colors: far left, far right, center ---
for label, x in [("far-left", 8), ("left-mid", 300), ("center", W//2), ("right-mid", W-300), ("far-right", W-8)]:
    col = a[:, max(0,x-2):x+3].reshape(-1,3).mean(axis=0)
    print(f"bg {label:9s} rgb({col[0]:.0f},{col[1]:.0f},{col[2]:.0f})")

# --- glow horizontal profile at navbar mid-height ---
mid = H//2
row = a[mid]
print("\nglow profile at y=mid (every 60px): r,g,b")
for x in range(0, W, 60):
    print(f"  x={x:4d}  {row[x][0]:3d},{row[x][1]:3d},{row[x][2]:3d}")

# brightest glow point
lum = 0.2126*r + 0.7152*g + 0.0722*b
glow_zone = lum.copy()
bi = np.unravel_index(np.argmax(glow_zone), glow_zone.shape)
print(f"\nbrightest pixel: ({bi[1]},{bi[0]}) rgb {a[bi[0],bi[1]]}")

# vertical profile at glow center
gx = bi[1]
print(f"vertical profile at x={gx}:")
for y in range(0, H, 8):
    print(f"  y={y:3d}  {a[y,gx][0]:3d},{a[y,gx][1]:3d},{a[y,gx][2]:3d}")

# pink wordmark color
if len(xs):
    ys3 = np.where(pink.any(axis=1))[0]
    mask = pink[ys3.min():ys3.max()+1]
    px = a[ys3.min():ys3.max()+1][mask]
    print(f"\nwordmark mean color rgb({px[:,0].mean():.0f},{px[:,1].mean():.0f},{px[:,2].mean():.0f}), brightest {px.max(axis=0)}")
