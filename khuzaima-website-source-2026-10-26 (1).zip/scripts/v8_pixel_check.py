#!/usr/bin/env python3
"""v8 pixel gates: aurora green presence, snow flake counts, 21:30 cleanliness."""
from PIL import Image
import sys

def analyze(path, label):
    im = Image.open(path).convert("RGB")
    W, H = im.size
    px = im.load()
    green = 0      # aurora-green pixels (g dominant, luminous)
    bright_green = 0
    white_dots = 0 # snow flakes in the sky region
    max_g = 0
    for y in range(0, H, 2):
        for x in range(0, W, 2):
            r, g, b = px[x, y]
            if g > 90 and g > r + 25 and g > b + 15:
                green += 1
                if g > 150:
                    bright_green += 1
                max_g = max(max_g, g)
            # snow: bright near-white dot on dark sky (upper 70%, avoiding text col x>66%)
            if y < H * 0.7 and x < W * 0.62 and r > 185 and g > 185 and b > 185:
                white_dots += 1
    total = (W // 2) * (H // 2)
    print(f"{label}: green_px={green} ({100*green/total:.2f}%) bright_green={bright_green} max_g={max_g} snow_dots_upper_left={white_dots}")
    return green, white_dots

if __name__ == "__main__":
    for path, label in [
        ("scripts/shots/v8/d-1958.png", "19:58"),
        ("scripts/shots/v8/d-2000.png", "20:00"),
        ("scripts/shots/v8/d-2025.png", "20:25"),
        ("scripts/shots/v8/d-2045.png", "20:45"),
        ("scripts/shots/v8/d-2100.png", "21:00"),
        ("scripts/shots/v8/d-2115.png", "21:15"),
        ("scripts/shots/v8/d-2125.png", "21:25"),
        ("scripts/shots/v8/d-2130.png", "21:30"),
    ]:
        analyze(path, label)
