#!/usr/bin/env bash
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
shot() { $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1; sleep 2; $AB screenshot "$OUT/$2.png" >/dev/null 2>&1; echo "$2"; }
shot 11000 x02-junction-1
shot 11350 x03-junction-2
shot 11750 x04-statement-open
shot 12000 x05-wheel-mid1
shot 12250 x06-wheel-mid2
shot 12800 x07-body-early
shot 13200 x08-body-msgs
shot 14000 x09-body-late
