#!/usr/bin/env bash
# Task 46 — measure current ChatDemo pinned geometry at 1792x837
set -u
AB="agent-browser"
$AB open http://localhost:3000 >/dev/null 2>&1
$AB set viewport 1792 837 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 2
$AB eval "window.scrollTo(0, 13529)" >/dev/null 2>&1
sleep 1.5
$AB eval "
(() => {
  const how = document.getElementById('how');
  const sticky = how.querySelector(':scope > div');
  const head = document.getElementById('demo-title');
  const grid = how.querySelector('.grid');
  const phone = how.querySelector('figure');
  const steps = how.querySelector('ol');
  const inner = sticky.firstElementChild; // .my-auto wrapper
  const r = el => { const b = el.getBoundingClientRect(); return {t: Math.round(b.top), b: Math.round(b.bottom), l: Math.round(b.left), r: Math.round(b.right), w: Math.round(b.width), h: Math.round(b.height)}; };
  return JSON.stringify({
    section: {h: how.offsetHeight, top: Math.round(how.getBoundingClientRect().top)},
    sticky: r(sticky),
    inner: r(inner),
    heading: r(head),
    grid: r(grid),
    phone: r(phone),
    steps: r(steps),
    viewport: {w: innerWidth, h: innerHeight}
  }, null, 1);
})()
"
