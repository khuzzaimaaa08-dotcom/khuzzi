#!/usr/bin/env python3
"""Pixel-diff the before/after QA screenshots (Task 33 visual gate).

Reports per-shot: max channel delta, mean abs delta, % pixels differing
beyond a 2/255 tolerance. Screenshots include dithered shader output and
animation mid-states, so tiny deltas are expected; the gate is "no
structural/visual change".
"""
import sys
from pathlib import Path
from PIL import Image, ImageChops

BEFORE = Path("/home/z/my-project/qa/perf-task33/before")
AFTER = Path("/home/z/my-project/qa/perf-task33/after")

def stats(a: Path, b: Path):
    ia, ib = Image.open(a).convert("RGB"), Image.open(b).convert("RGB")
    if ia.size != ib.size:
        return None, f"SIZE MISMATCH {ia.size} vs {ib.size}"
    diff = ImageChops.difference(ia, ib)
    px = diff.getdata()
    n = ia.size[0] * ia.size[1]
    maxd = 0
    total = 0
    changed = 0
    for r, g, bl in px:
        d = max(r, g, bl)
        total += (r + g + bl) / 3
        if d > maxd:
            maxd = d
        if d > 2:
            changed += 1
    return (maxd, total / n, changed / n * 100), None

def main():
    files = sorted(p.name for p in BEFORE.glob("*.png"))
    if not files:
        print("no before shots")
        sys.exit(1)
    worst = []
    for name in files:
        a, b = BEFORE / name, AFTER / name
        if not b.exists():
            print(f"{name:32s} MISSING AFTER")
            continue
        s, err = stats(a, b)
        if err:
            print(f"{name:32s} {err}")
            continue
        maxd, mean, pct = s
        flag = "  <-- CHECK" if (maxd > 24 or pct > 0.5) else ""
        print(f"{name:32s} max={maxd:3d} mean={mean:7.3f} changed>2/255: {pct:6.3f}%{flag}")
        worst.append((pct, maxd, name))
    worst.sort(reverse=True)
    print("\nworst 3:", ", ".join(f"{n} ({p:.3f}%/{m})" for p, m, n in worst[:3]))

if __name__ == "__main__":
    main()
