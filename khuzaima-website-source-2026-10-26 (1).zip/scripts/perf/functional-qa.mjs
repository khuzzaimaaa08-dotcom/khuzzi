#!/usr/bin/env node
/**
 * Functional QA for the Task 33 performance changes — proves behaviors are
 * preserved: mobile drawer, ChatDemo imperative reveal (+ tab switch),
 * reduced-motion paths, nav-blur engagement, ThemeTransition sleep/wake,
 * /book isolation, and a clean console throughout.
 */
import { chromium } from "playwright-core";
import fs from "node:fs";

const URL = process.env.QA_URL || "http://localhost:3001";
const EXECUTABLE = "/home/z/.cache/puppeteer/chrome/linux-155.0.8059.39/chrome-linux64/chrome";
const results = [];
const ok = (name, pass, detail = "") => {
  results.push([pass ? "PASS" : "FAIL", name, detail]);
  console.log(`${pass ? "✓" : "✗"} ${name}${detail ? " — " + detail : ""}`);
};

const browser = await chromium.launch({ executablePath: EXECUTABLE, headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"] });

/* ---------- 1. Mobile: drawer + ChatDemo reveal + blur gating ---------- */
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 3 });
  const page = await ctx.newPage();
  const errs = [];
  page.on("pageerror", (e) => errs.push(String(e)));
  page.on("console", (m) => { if (m.type() === "error") errs.push(m.text()); });
  await page.goto(URL, { waitUntil: "networkidle" });
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  await page.waitForTimeout(1200);

  // nav-blur gating: expanded = visibility hidden, no backdrop sampling
  const blurExpanded = await page.evaluate(() => {
    const s = document.querySelector(".nav-blur > span");
    return getComputedStyle(s).visibility;
  });
  ok("nav-blur hidden at top (expanded)", blurExpanded === "hidden", `visibility=${blurExpanded}`);

  await page.evaluate(() => window.scrollTo(0, 400));
  await page.waitForTimeout(600);
  const blurCompact = await page.evaluate(() => {
    const s = document.querySelector(".nav-blur > span");
    return { vis: getComputedStyle(s).visibility, bf: getComputedStyle(s).backdropFilter !== "none" };
  });
  ok("nav-blur engaged when compact", blurCompact.vis === "visible" && blurCompact.bf, JSON.stringify(blurCompact));

  // drawer: open -> scroll lock; Esc -> close + focus back
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(400);
  await page.click(".nav-menu-btn");
  await page.waitForTimeout(500);
  const drawerOpen = await page.evaluate(() => {
    const d = document.getElementById("nav-drawer");
    return { hidden: d.hidden, lock: document.documentElement.style.overflow === "hidden" };
  });
  ok("drawer opens + scroll lock", !drawerOpen.hidden && drawerOpen.lock, JSON.stringify(drawerOpen));
  await page.keyboard.press("Escape");
  await page.waitForTimeout(400);
  const drawerClosed = await page.evaluate(() => {
    const d = document.getElementById("nav-drawer");
    return { hidden: d.hidden, lock: document.documentElement.style.overflow !== "hidden", focus: document.activeElement?.className };
  });
  ok("Esc closes drawer + lock released", drawerClosed.hidden && drawerClosed.lock, JSON.stringify(drawerClosed));

  // ChatDemo imperative reveal: check message visibility tracks progress, both tabs
  const how = await page.evaluate(() => document.getElementById("how").getBoundingClientRect().top + window.scrollY);
  const pinRange = await page.evaluate(() => {
    const s = document.getElementById("how");
    return s.offsetHeight - window.innerHeight;
  });
  const p = 0.5;
  await page.evaluate((y) => window.scrollTo(0, y), how + pinRange * p);
  await page.waitForTimeout(2200);
  const chatClinic = await page.evaluate(() => {
    const msgs = Array.from(document.querySelectorAll("#how figure p")).filter((m) => m.className.includes("animate-in"));
    const vis = msgs.filter((m) => !m.hidden).length;
    const steps = Array.from(document.querySelectorAll("#how ol li"));
    const on = steps.filter((s) => s.className.includes("border-mint")).length;
    return { total: msgs.length, vis, stepOn: on };
  });
  ok("ChatDemo clinic reveal at p=0.5 (quantized 0.5)", chatClinic.vis === 3 && chatClinic.stepOn === 1, JSON.stringify(chatClinic));

  // tab switch mid-scrub: estate transcript must re-apply progress
  await page.click("#how [role=tab]:nth-child(2)");
  await page.waitForTimeout(700);
  const chatEstate = await page.evaluate(() => {
    const msgs = Array.from(document.querySelectorAll("#how figure p")).filter((m) => m.className.includes("animate-in"));
    return { total: msgs.length, vis: msgs.filter((m) => !m.hidden).length };
  });
  ok("ChatDemo tab switch re-applies progress", chatEstate.total === 4 && chatEstate.vis === 2, JSON.stringify(chatEstate));

  ok("mobile console clean", errs.length === 0, errs.slice(0, 3).join(" | ") || "0 errors");
  await ctx.close();
}

/* ---------- 2. Desktop: theme transition + idle sleep ---------- */
{
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
  const page = await ctx.newPage();
  const errs = [];
  page.on("pageerror", (e) => errs.push(String(e)));
  await page.goto(URL, { waitUntil: "networkidle" });
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  await page.waitForTimeout(1200);

  // MutationObserver on the work section's style attr: must be SILENT at rest
  const quiet = await page.evaluate(() => new Promise((resolve) => {
    const work = document.querySelector(".theme-canvas");
    let mutations = 0;
    const mo = new MutationObserver(() => mutations++);
    mo.observe(work, { attributes: true, attributeFilter: ["style"] });
    setTimeout(() => { mo.disconnect(); resolve(mutations); }, 1200);
  }));
  ok("ThemeTransition asleep at top (no idle writes)", quiet === 0, `${quiet} style mutations in 1.2s idle`);

  // walk the ramp: values must scrub on the sections and match the expected curve
  // (at 1920x1080 the heading crosses the 68vh ramp across scroll fracs ~0.351-0.399)
  const total = await page.evaluate(() => document.documentElement.scrollHeight - window.innerHeight);
  const ramp = [];
  for (const frac of [0.345, 0.36, 0.375, 0.39, 0.41, 0.43]) {
    await page.evaluate((y) => window.scrollTo(0, y), Math.round(total * frac));
    await page.waitForTimeout(1400);
    const v = await page.evaluate(() => {
      const work = document.querySelector("#work");
      const bg = getComputedStyle(work).backgroundColor;
      const fg = getComputedStyle(document.getElementById("our-work-title")).color;
      const rootVar = getComputedStyle(document.documentElement).getPropertyValue("--pg-bg").trim();
      return { bg, fg, rootVar };
    });
    ramp.push(v);
  }
  const bgs = ramp.map((r) => r.bg);
  const monotonic = bgs.every((b, i) => i === 0 || parseLum(b) <= parseLum(bgs[i - 1]) + 1);
  function parseLum(rgb) { const m = rgb.match(/(\d+)[,\s]+(\d+)[,\s]+(\d+)/); return m ? +m[1] + +m[2] + +m[3] : 0; }
  const sectionScoped = await page.evaluate(() => {
    const work = document.querySelector("#work");
    return {
      sectionVar: work.style.getPropertyValue("--pg-bg") !== "",
      rootInline: document.documentElement.style.getPropertyValue("--pg-bg") === "",
    };
  });
  ok("theme ramp scrubs + reverses on sections", monotonic, bgs.join(" -> "));
  ok("vars scoped to sections (root untouched)", sectionScoped.sectionVar && sectionScoped.rootInline, JSON.stringify(sectionScoped));

  // dark zone fully dark at rest + white at top
  await page.evaluate((y) => window.scrollTo(0, y), total);
  await page.waitForTimeout(1500);
  const darkBg = await page.evaluate(() => getComputedStyle(document.querySelector("#services")).backgroundColor);
  ok("services canvas dark at bottom", darkBg === "rgb(10, 10, 10)", darkBg);

  ok("desktop console clean", errs.length === 0, errs.slice(0, 3).join(" | ") || "0 errors");
  await ctx.close();
}

/* ---------- 3. Reduced motion ---------- */
{
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, reducedMotion: "reduce" });
  const page = await ctx.newPage();
  const errs = [];
  page.on("pageerror", (e) => errs.push(String(e)));
  await page.goto(URL, { waitUntil: "networkidle" });
  await page.waitForTimeout(1000);
  const heroH = await page.evaluate(() => document.getElementById("top").offsetHeight);
  ok("reduced-motion: hero not pinned (no 400vh)", heroH < 2.5 * 1080, `${heroH}px`);
  const msgs = await page.evaluate(() => {
    const all = Array.from(document.querySelectorAll("#how figure p")).filter((m) => m.className.includes("animate-in"));
    return { total: all.length, hidden: all.filter((m) => m.hidden).length };
  });
  ok("reduced-motion: chat messages all visible", msgs.total === 6 && msgs.hidden === 0, JSON.stringify(msgs));
  // theme: endpoints only, never interpolated
  const total = await page.evaluate(() => document.documentElement.scrollHeight - window.innerHeight);
  const mids = [];
  for (const frac of [0.42, 0.46, 0.5, 0.54]) {
    await page.evaluate((y) => window.scrollTo(0, y), Math.round(total * frac));
    await page.waitForTimeout(500);
    mids.push(await page.evaluate(() => getComputedStyle(document.querySelector("#work")).backgroundColor));
  }
  const endpoints = mids.every((m) => m === "rgb(255, 255, 255)" || m === "rgb(10, 10, 10)");
  ok("reduced-motion: theme snaps to endpoints only", endpoints, mids.join(", "));
  ok("reduced-motion console clean", errs.length === 0, errs.slice(0, 3).join(" | ") || "0 errors");
  await ctx.close();
}

/* ---------- 4. /book isolation ---------- */
{
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 900 } });
  const page = await ctx.newPage();
  const errs = [];
  page.on("pageerror", (e) => errs.push(String(e)));
  await page.goto(URL + "/book", { waitUntil: "networkidle" });
  await page.waitForTimeout(1200);
  const book = await page.evaluate(() => {
    const canvases = document.querySelectorAll(".theme-canvas").length;
    const head = document.querySelector(".site-head");
    return { canvases, hasNav: !!head, pad: getComputedStyle(document.body).paddingTop };
  });
  await page.evaluate(() => window.scrollTo(0, 600));
  await page.waitForTimeout(600);
  ok("/book: no theme-canvas, navbar present", book.canvases === 0 && book.hasNav, JSON.stringify(book));
  ok("/book console clean", errs.length === 0, errs.slice(0, 3).join(" | ") || "0 errors");
  await ctx.close();
}

await browser.close();
const fails = results.filter((r) => r[0] === "FAIL").length;
console.log(`\n${results.length - fails}/${results.length} checks passed`);
process.exit(fails ? 1 : 0);
