#!/usr/bin/env node
/**
 * Production scroll-performance harness (Task 33).
 *
 * Drives a REAL production URL in headless Chrome via CDP:
 *  - CPU throttling (Emulation.setCPUThrottlingRate) to emulate low-end laptops
 *  - Continuous scroll via Input.synthesizeScrollGesture (trusted wheel/touch
 *    events — exactly what Lenis + ScrollTrigger consume in production)
 *  - Page-side collector: per-frame rAF deltas + scrollY (for section
 *    attribution), longtasks, page errors
 *  - CDP Performance.getMetrics deltas: ScriptDuration / LayoutDuration /
 *    RecalcStyleDuration / TaskDuration — the DevTools main-thread breakdown
 *
 * Usage:
 *   node scripts/perf/measure.mjs --url http://localhost:3001 \
 *        --out scripts/perf/results/baseline --throttle 4 --viewport desktop
 *
 * Relative before/after comparisons under an identical protocol are the point;
 * absolute headless numbers include software rasterization and are not
 * representative of real device frame rates.
 */
import { chromium } from "playwright-core";
import fs from "node:fs";
import path from "node:path";

const argv = process.argv.slice(2);
const arg = (name, def) => {
  const i = argv.indexOf(`--${name}`);
  if (i === -1) return def;
  const v = argv[i + 1];
  return v && !v.startsWith("--") ? v : true;
};

const URL = arg("url", "http://localhost:3000");
const OUT = arg("out", "scripts/perf/results/run");
const THROTTLE = Number(arg("throttle", 1));
const VIEWPORT = arg("viewport", "desktop");
const SPEED = Number(arg("speed", 1200)); // px/s scroll velocity
const PASSES = arg("passes", "down,up").split(",");

const EXECUTABLES = [
  "/home/z/.cache/puppeteer/chrome/linux-155.0.8059.39/chrome-linux64/chrome",
  "/home/z/.agent-browser/browsers/chrome-155.0.8059.39/chrome-linux64/chrome",
  "/home/z/.cache/ms-playwright/chromium-1200/chrome-linux64/chrome",
];
const EXECUTABLE = EXECUTABLES.find((p) => fs.existsSync(p));
if (!EXECUTABLE) {
  console.error("No chrome binary found");
  process.exit(1);
}

const VP =
  VIEWPORT === "mobile"
    ? { viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 3 }
    : { viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 };

/* Continuous, deadline-paced input stream. Desktop: trusted wheel notches
   (120px each — exactly what Lenis consumes). Mobile: raw touch drag stream
   (native momentum path; Lenis is disabled on coarse pointers). */
async function driveScroll(page, cdp, dir, total, speed) {
  const sign = dir === "down" ? 1 : -1;
  if (VIEWPORT !== "mobile") {
    const notches = Math.ceil(total / 120) + 3;
    const interval = (1000 * 120) / speed;
    let next = performance.now();
    for (let i = 0; i < notches; i++) {
      await page.mouse.wheel(0, 120 * sign);
      next += interval;
      const wait = next - performance.now();
      if (wait > 2) await new Promise((r) => setTimeout(r, wait));
    }
  } else {
    const x = Math.round(VP.viewport.width / 2);
    let y = Math.round(VP.viewport.height * 0.75);
    const dtMs = 16;
    const step = (speed * dtMs) / 1000;
    const ticks = Math.ceil(total / step) + 3;
    await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x, y, id: 1 }] });
    let next = performance.now();
    for (let i = 1; i <= ticks; i++) {
      y -= step * sign;
      await cdp.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ x, y, id: 1 }] });
      next += dtMs;
      const wait = next - performance.now();
      if (wait > 2) await new Promise((r) => setTimeout(r, wait));
    }
    await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  }
}

const COLLECTOR = `(() => {
  if (window.__perfInstalled) return;
  window.__perfInstalled = true;
  const P = { running: false, frames: [], longtasks: [], errors: [], lastT: null };
  window.__perf = P;
  window.addEventListener('error', (e) => P.errors.push(String(e.message)));
  window.addEventListener('unhandledrejection', (e) => P.errors.push(String(e.reason)));
  try {
    new PerformanceObserver((list) => {
      for (const e of list.getEntries()) if (P.running) P.longtasks.push({ t: e.startTime, d: e.duration });
    }).observe({ entryTypes: ['longtask'] });
  } catch {}
  const loop = (t) => {
    if (P.lastT != null && P.running) P.frames.push({ dt: Math.round((t - P.lastT) * 10) / 10, y: Math.round(window.scrollY) });
    P.lastT = t;
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
  window.__perfStart = () => { P.frames.length = 0; P.longtasks.length = 0; P.errors.length = 0; P.running = true; };
  window.__perfStop = () => { P.running = false; return { frames: P.frames, longtasks: P.longtasks, errors: P.errors }; };
})();`;

const pct = (sorted, q) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * q))];

function frameStats(frames) {
  const dts = frames.map((f) => f.dt).sort((a, b) => a - b);
  if (!dts.length) return { n: 0 };
  const sum = dts.reduce((a, b) => a + b, 0);
  return {
    n: dts.length,
    avgMs: Math.round((sum / dts.length) * 10) / 10,
    p95Ms: pct(dts, 0.95),
    p99Ms: pct(dts, 0.99),
    maxMs: dts[dts.length - 1],
    over20: dts.filter((d) => d > 20).length,
    over34: dts.filter((d) => d > 34).length,
    over50: dts.filter((d) => d > 50).length,
    fps: Math.round((1000 / (sum / dts.length)) * 10) / 10,
  };
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch({
    executablePath: EXECUTABLE,
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--hide-scrollbars"],
  });
  const context = await browser.newContext(VP);
  await context.addInitScript(COLLECTOR);
  const page = await context.newPage();
  const pageErrors = [];
  page.on("pageerror", (e) => pageErrors.push(String(e)));

  const cdp = await context.newCDPSession(page);
  await cdp.send("Performance.enable");
  if (THROTTLE !== 1) await cdp.send("Emulation.setCPUThrottlingRate", { rate: THROTTLE });

  console.log(`[measure] ${URL} viewport=${VIEWPORT} throttle=${THROTTLE}x speed=${SPEED}px/s`);

  await page.goto(URL, { waitUntil: "networkidle", timeout: 60000 });
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  await page.waitForTimeout(1500);

  const page0 = await page.evaluate(() => ({
    scrollH: document.documentElement.scrollHeight,
    innerH: window.innerHeight,
  }));
  const sections = await page.evaluate(() => {
    const y0 = window.scrollY;
    return Array.from(document.querySelectorAll("main > section, body > div > footer"))
      .map((s) => {
        const r = s.getBoundingClientRect();
        return { id: s.id || (s.className || "section").toString().split(" ")[0], top: Math.round(r.top + y0), h: Math.round(r.height) };
      })
      .filter((s) => s.h > 50);
  });
  const total = page0.scrollH - page0.innerH;
  console.log(`[measure] page scroll range: ${total}px; sections: ${sections.map((s) => `${s.id}@${s.top}+${s.h}`).join(", ")}`);

  const results = { meta: { url: URL, viewport: VIEWPORT, throttle: THROTTLE, speed: SPEED, executable: EXECUTABLE, totalScroll: total, sections }, passes: {} };

  for (const pass of PASSES) {
    // start position
    await page.evaluate((y) => window.scrollTo(0, y), pass === "down" ? 0 : total);
    await page.waitForTimeout(1000);

    const pre = Object.fromEntries((await cdp.send("Performance.getMetrics")).metrics.map((m) => [m.name, m.value]));
    const heapPre = await page.evaluate(() => (performance.memory ? performance.memory.usedJSHeapSize : 0));

    await page.evaluate(() => window.__perfStart());
    // Continuous input-driven scroll across the whole page
    await driveScroll(page, cdp, pass, total + 40, SPEED);
    await page.waitForTimeout(1800); // Lenis tail + theme chase settle
    const raw = await page.evaluate(() => window.__perfStop());

    const post = Object.fromEntries((await cdp.send("Performance.getMetrics")).metrics.map((m) => [m.name, m.value]));
    const heapPost = await page.evaluate(() => (performance.memory ? performance.memory.usedJSHeapSize : 0));

    // attribute frames to the section covering the viewport top
    const bySection = {};
    for (const f of raw.frames) {
      const sec = sections.find((s) => f.y >= s.top - 2 && f.y < s.top + s.h) || { id: f.y < sections[0].top ? "above" : "below" };
      (bySection[sec.id] ||= []).push(f);
    }
    const sectionStats = Object.fromEntries(
      Object.entries(bySection)
        .map(([k, v]) => [k, frameStats(v)])
        .sort((a, b) => b[1].avgMs - a[1].avgMs)
    );

    const ltBuckets = {};
    for (const lt of raw.longtasks) {
      const nearest = raw.frames.reduce((best, f) => (Math.abs(f.t - lt.t) < Math.abs((best?.t ?? -1e9) - lt.t) ? f : best), null);
      const y = nearest?.y ?? 0;
      const sec = sections.find((s) => y >= s.top - 2 && y < s.top + s.h)?.id || "?";
      ltBuckets[sec] = (ltBuckets[sec] || 0) + 1;
    }

    results.passes[pass] = {
      frames: frameStats(raw.frames),
      sections: sectionStats,
      longtasks: { count: raw.longtasks.length, totalMs: Math.round(raw.longtasks.reduce((a, b) => a + b.d, 0)), maxMs: Math.round(Math.max(0, ...raw.longtasks.map((l) => l.d))), bySection: ltBuckets },
      cdp: {
        ScriptDuration: Math.round((post.ScriptDuration - pre.ScriptDuration) * 100) / 100,
        TaskDuration: Math.round((post.TaskDuration - pre.TaskDuration) * 100) / 100,
        LayoutDuration: Math.round((post.LayoutDuration - pre.LayoutDuration) * 1000) / 1000,
        RecalcStyleDuration: Math.round((post.RecalcStyleDuration - pre.RecalcStyleDuration) * 1000) / 1000,
        LayoutCount: post.LayoutCount - pre.LayoutCount,
        RecalcStyleCount: post.RecalcStyleCount - pre.RecalcStyleCount,
      },
      heapDeltaMB: Math.round(((heapPost - heapPre) / 1048576) * 10) / 10,
      pageErrors: [...raw.errors, ...pageErrors],
    };
    pageErrors.length = 0;

    const r = results.passes[pass];
    console.log(`\n[${pass}] frames=${r.frames.n} avg=${r.frames.avgMs}ms p95=${r.frames.p95Ms}ms max=${r.frames.maxMs}ms >20ms=${r.frames.over20} >34ms=${r.frames.over34} fps~${r.frames.fps}`);
    console.log(`      script=${r.cdp.ScriptDuration}s task=${r.cdp.TaskDuration}s layout=${r.cdp.LayoutDuration}s(${r.cdp.LayoutCount}) style=${r.cdp.RecalcStyleDuration}s(${r.cdp.RecalcStyleCount}) longtasks=${r.longtasks.count} (${r.longtasks.totalMs}ms)`);
    console.log(`      slowest sections: ${Object.entries(r.sections).slice(0, 5).map(([k, v]) => `${k} ${v.avgMs}ms/n=${v.n}`).join(" | ")}`);
    if (r.pageErrors.length) console.log(`      PAGE ERRORS: ${r.pageErrors.slice(0, 5).join(" | ")}`);
  }

  fs.writeFileSync(path.join(OUT, `${VIEWPORT}-${THROTTLE}x.json`), JSON.stringify(results, null, 2));
  console.log(`\n[measure] wrote ${path.join(OUT, `${VIEWPORT}-${THROTTLE}x.json`)}`);
  await browser.close();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
