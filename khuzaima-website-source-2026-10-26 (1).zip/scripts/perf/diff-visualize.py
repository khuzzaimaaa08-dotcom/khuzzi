#!/usr/bin/env python3
"""Visualize where before/after screenshots differ (Task 33)."""
import sys
from pathlib import Path
from PIL import Image, ImageChops

BEFORE = Path("/home/z/my-project/qa/perf-task33/before")
AFTER = Path("/home/z/my-project/qa/perf-task33/after")
OUT = Path("/home/z/my-project/qa/perf-task33/diffs")

SHOTS = sys.argv[1:] or ["mobile-manifesto.png", "desktop-work-dark.png", "mobile-work-dark.png", "desktop-top.png", "desktop-work-mid.png", "mobile-top.png"]

for name in SHOTS:
    a, b = BEFORE / name, AFTER / name
    if not (a.exists() and b.exists()):
        print(f"{name}: missing")
        continue
    ia, ib = Image.open(a).convert("RGB"), Image.open(b).convert("RGB")
    diff = ImageChops.difference(ia, ib).convert("L")
    bbox = diff.getbbox()
    if bbox is None:
        print(f"{name}: identical")
        continue
    # bounding box of pixels > 2
    mask = diff.point(lambda v: 255 if v > 2 else 0)
    bbox = mask.getbbox()
    print(f"{name}: changed bbox {bbox}  image {ia.size}")
    pad = 40
    l, t, r, bo = bbox
    l, t = max(0, l - pad), max(0, t - pad)
    r, bo = min(ia.size[0], r + pad), min(ia.size[1], bo + pad)
    W = r - l
    canvas = Image.new("RGB", (W * 3 + 20, bo - t), (20, 20, 20))
    canvas.paste(ia.crop((l, t, r, bo)), (0, 0))
    canvas.paste(ib.crop((l, t, r, bo)), (W + 10, 0))
    canvas.paste(Image.merge("RGB", (mask.crop((l, t, r, bo)), mask.crop((l, t, r, bo)), mask.crop((l, t, r, bo)))), (W * 2 + 20, 0))
    OUT.mkdir(parents=True, exist_ok=True)
    canvas.save(OUT / f"{name.replace('.png', '')}-crop.png")
    print(f"  saved {OUT / (name.replace('.png', '') + '-crop.png')}  (before | after | mask)")
