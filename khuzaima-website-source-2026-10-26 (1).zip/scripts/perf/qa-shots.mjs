#!/usr/bin/env node
/**
 * Deterministic QA screenshots for before/after pixel comparison (Task 33).
 * Jumps to fixed scroll positions (settled: Lenis bypassed via direct
 * scrollTo, 2.5s wait for the theme chase + scrub), captures PNGs.
 *
 * Usage: node scripts/perf/qa-shots.mjs --url http://localhost:3001 \
 *          --out qa/perf-task33/before --viewport desktop
 */
import { chromium } from "playwright-core";
import fs from "node:fs";

const argv = process.argv.slice(2);
const arg = (name, def) => {
  const i = argv.indexOf(`--${name}`);
  if (i === -1) return def;
  const v = argv[i + 1];
  return v && !v.startsWith("--") ? v : true;
};

const URL = arg("url", "http://localhost:3001");
const OUT = arg("out", "qa/perf-task33/run");
const VIEWPORT = arg("viewport", "desktop");

const EXECUTABLE = [
  "/home/z/.cache/puppeteer/chrome/linux-155.0.8059.39/chrome-linux64/chrome",
  "/home/z/.agent-browser/browsers/chrome-155.0.8059.39/chrome-linux64/chrome",
].find((p) => fs.existsSync(p));

// scroll positions as FRACTIONS of the page scroll range (stable across builds
// even if section heights shift by a few px)
const STOPS = [
  ["top", 0.0],
  ["hero-morning", 0.1],
  ["hero-noon", 0.22],
  ["hero-dusk", 0.35],
  ["hero-night", 0.42],
  ["manifesto", 0.5],
  ["brands", 0.585],
  ["work-mid", 0.635],
  ["work-dark", 0.66],
  ["chatdemo", 0.71],
  ["services", 0.8],
  ["process", 0.925],
  ["privacy", 0.96],
  ["footer", 1.0],
];

const VP =
  VIEWPORT === "mobile"
    ? { viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 3 }
    : { viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 };

const browser = await chromium.launch({
  executablePath: EXECUTABLE,
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage", "--hide-scrollbars", "--force-device-scale-factor=1"],
});
const context = await browser.newContext({ ...VP, deviceScaleFactor: 1 });
const page = await context.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));

await page.goto(URL, { waitUntil: "networkidle", timeout: 60000 });
await page.evaluate(() => document.fonts.ready.then(() => undefined));
await page.waitForTimeout(1500);

const total = await page.evaluate(() => document.documentElement.scrollHeight - window.innerHeight);
fs.mkdirSync(OUT, { recursive: true });

for (const [name, frac] of STOPS) {
  const y = Math.round(total * frac);
  await page.evaluate((yy) => window.scrollTo(0, yy), y);
  await page.waitForTimeout(2600); // scrub + theme chase settle
  await page.screenshot({ path: `${OUT}/${VIEWPORT}-${name}.png` });
  console.log(`shot ${VIEWPORT}-${name}.png @${y}`);
}
console.log("pageErrors:", errors.length ? errors : "none");
await browser.close();
