#!/usr/bin/env bash
# Task 46 — reveal cadence + reversal (fixed selectors)
set -u
AB="agent-browser"

probe() { $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1; sleep 1.5; echo "=== y=$1 ==="; $AB eval "
(() => {
  const how = document.getElementById('how');
  const chatHost = [...how.querySelectorAll('figure div')].find(d => (d.className||'').includes('52svh'));
  const vis = chatHost ? [...chatHost.querySelectorAll('p')].filter(p => !p.hidden).length : -1;
  const steps = [...how.querySelectorAll('ol li')].filter(s => (s.className||'').includes('border-mint')).length;
  const stack = how.querySelector('.chatdemo-stack');
  const typing = how.querySelector('figure span[hidden]');
  return JSON.stringify({visMsgs: vis, stepsOn: steps, ty: getComputedStyle(stack).transform, typingHidden: typing ? typing.hidden : 'n/a', y: Math.round(scrollY)});
})()
"; }

echo "--- reveal cadence (msg1 ~12764, spacing ~254px) ---"
probe 12750; probe 12800; probe 13010; probe 13260; probe 13520; probe 14020
echo "--- reversal: scroll back up ---"
probe 12511; probe 12100; probe 11679; probe 11200; probe 10800
