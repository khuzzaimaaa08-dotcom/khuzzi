#!/usr/bin/env bash
# Task 46 — verify reveal cadence thresholds + reversal + old-location cleanup
set -u
AB="agent-browser"

bubblecount() { # visible chat bubbles only
  $AB eval "
(() => {
  const how = document.getElementById('how');
  const bubbles = [...how.querySelectorAll('figure .grid p, figure div.flex p')];
  const chat = [...how.querySelectorAll('figure div')].filter(d => d.className.includes('h-[min(52svh'))[0];
  const vis = chat ? [...chat.querySelectorAll('p')].filter(p => !p.hidden).length : -1;
  const steps = [...how.querySelectorAll('ol.md\\:col-span-6 li, ol li')].filter(s => s.className.includes('border-mint')).length;
  const stack = how.querySelector('.chatdemo-stack');
  return JSON.stringify({vis, steps, y: Math.round(scrollY), ty: getComputedStyle(stack).transform});
})()
"
}

probe() { $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1; sleep 1.5; echo "=== y=$1 ==="; bubblecount; }

echo "--- reveal cadence (expect msg i at ~254px spacing, msg1 at ~12764) ---"
probe 12760; probe 13010; probe 13260; probe 14020
echo "--- reversal: scroll back up ---"
probe 12511; probe 11900; probe 11679; probe 11200
echo "--- old location: hero->manifesto junction (statement must NOT appear) ---"
$AB eval "window.scrollTo(0, 0)" >/dev/null 2>&1; sleep 1
$AB eval "
(() => {
  const nd = document.querySelectorAll('.never-done').length;
  const hero = document.querySelector('main section');
  const mani = document.getElementById('manifesto') || document.querySelector('main > *:nth-child(2)');
  return JSON.stringify({neverDoneCount: nd, heroId: hero?.id, second: mani?.id || mani?.className?.slice(0,40)});
})()
"
