#!/usr/bin/env python3
"""Measure the blue NBCU card bounding box + heading position in the
reference screenshot and the current-website screenshot (pixel-exact)."""
from PIL import Image

def analyze(path, label):
    im = Image.open(path).convert("RGB")
    W, H = im.size
    px = im.load()

    # Find blue-dominant pixels (NBCU card): B significantly > R and G, B > 90
    minx, miny, maxx, maxy = W, H, -1, -1
    for y in range(0, H, 2):
        for x in range(0, W, 2):
            r, g, b = px[x, y]
            if b > 120 and b - r > 60 and b - g > 40 and r < 140:
                if x < minx: minx = x
                if x > maxx: maxx = x
                if y < miny: miny = y
                if y > maxy: maxy = y
    print(f"== {label} == image {W}x{H}")
    if maxx < 0:
        print("  no blue card found")
        return
    cw, ch = maxx - minx, maxy - miny
    print(f"  blue card bbox: x[{minx}..{maxx}] y[{miny}..{maxy}]  size {cw}x{ch}")
    print(f"  width  = {cw/W*100:.1f}% of viewport  | margins L {minx/W*100:.1f}%  R {(W-1-maxx)/W*100:.1f}%")
    print(f"  top    = {miny/H*100:.1f}% of vh   bottom = {maxy/H*100:.1f}% of vh")
    print(f"  aspect = {cw/ch:.2f}:1")

    # Find big white text ("Our work.") in the upper-left region: rows with
    # many near-white pixels on dark background
    for y in range(0, int(H*0.45), 2):
        white = 0
        for x in range(0, int(W*0.7), 2):
            r, g, b = px[x, y]
            if r > 220 and g > 220 and b > 220:
                white += 1
        if white > 30:
            print(f"  first big-white-text row: y={y} ({y/H*100:.1f}% of vh)")
            break

for p, l in [
    ("/home/z/my-project/upload/pasted_image_1792664597584.png", "REFERENCE (desired)"),
    ("/home/z/my-project/upload/pasted_image_1792664391321.png", "CURRENT website"),
]:
    analyze(p, l)
    print()
