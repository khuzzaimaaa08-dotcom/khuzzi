/* QA: verify the ThemeTransition reduced-motion branch.
 * With prefers-reduced-motion: reduce emulated, the theme must never
 * interpolate — --pg-bg is only ever the exact light or dark endpoint
 * (snapped with hysteresis), and scrolling back up restores light. */
const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1920, height: 1080 },
    reducedMotion: "reduce",
  });
  const page = await ctx.newPage();
  await page.goto("http://localhost:3000", { waitUntil: "networkidle" });
  await page.waitForTimeout(2500);

  const absTop = await page.evaluate(() =>
    Math.round(document.getElementById("our-work-title").getBoundingClientRect().top + scrollY));
  console.log("heading absTop:", absTop);

  const readVars = () =>
    page.evaluate(() => {
      const st = getComputedStyle(document.documentElement);
      return {
        bg: st.getPropertyValue("--pg-bg").trim(),
        fg: st.getPropertyValue("--pg-fg").trim(),
      };
    });

  const positions = [1.2, 1.0, 0.7, 0.55, 0.45, 0.32, 0.2, 0.45, 0.55, 0.7, 1.0, 1.2];
  let fail = 0;
  for (const f of positions) {
    await page.evaluate((y) => scrollTo(0, y), absTop - 1080 * f);
    await page.waitForTimeout(450);
    const v = await readVars();
    const ok = v.bg === "rgb(255 255 255)" || v.bg === "rgb(10 10 10)";
    if (!ok) fail++;
    console.log(
      `heading@${f}vh -> bg=${v.bg} fg=${v.fg} ${ok ? "SNAPPED-OK" : "!! INTERPOLATED (FAIL)"}`
    );
  }
  console.log(fail === 0 ? "REDUCED-MOTION BRANCH: PASS" : `REDUCED-MOTION BRANCH: FAIL (${fail})`);
  await browser.close();
  process.exit(fail === 0 ? 0 : 1);
})();
