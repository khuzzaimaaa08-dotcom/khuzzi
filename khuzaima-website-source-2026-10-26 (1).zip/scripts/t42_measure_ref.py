#!/usr/bin/env python3
"""Task 42 — measure the NEW NBCU reference screenshot (1837x580).

Measures: card bounds/radius, heading bounds, heading->card gap, text group
(NBCU. label + 3-line headline) positions/sizes/colors, phone extents,
particle colors, showreel tile bounds/colors/pill geometry.
Outputs JSON to stdout.
"""
import json
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()

def row_scan(y, x0=0, x1=W):
    """first/last x where pixel differs notably from the page bg at that row's left edge"""
    bg = px[x0 + 2, y]
    first = last = None
    for x in range(x0, x1):
        r, g, b = px[x, y]
        if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) > 60:
            if first is None:
                first = x
            last = x
    return first, last

def col_scan(x, y0=0, y1=H):
    bg = px[x, y0 + 2]
    first = last = None
    for y in range(y0, y1):
        r, g, b = px[x, y]
        if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) > 60:
            if first is None:
                first = y
            last = y
    return first, last

out = {"image": [W, H]}

# ── page bg color (corner) ────────────────────────────────────────────────
out["page_bg_topleft"] = px[3, 3]
out["page_bg_topright"] = px[W - 4, 3]

# ── card bounds: scan mid-height rows for the blue surface ────────────────
# find a row clearly inside the card (blue) - scan down the middle column
mid_x = W // 2
card_rows = [y for y in range(H) if
             px[mid_x, y][2] > 120 and px[mid_x, y][0] < 120 and px[mid_x, y][1] < 160]
card_top0, card_bot0 = min(card_rows), max(card_rows)
out["card_rows_at_midcol"] = [card_top0, card_bot0]

# left/right edges at a row inside the card
y_in = (card_top0 + card_bot0) // 2
bgL = px[3, y_in]
def edge_row(y):
    first = last = None
    for x in range(W):
        r, g, b = px[x, y]
        if abs(r - bgL[0]) + abs(g - bgL[1]) + abs(b - bgL[2]) > 60:
            if first is None: first = x
            last = x
    return first, last
# scan several rows to be safe
edges = [edge_row(y) for y in range(card_top0 + 40, card_bot0 - 40, max(1, (card_bot0 - card_top0) // 8))]
card_left = min(e[0] for e in edges)
card_right = max(e[1] for e in edges)
out["card_bbox"] = [card_left, card_top0, card_right, card_bot0]
cw = card_right - card_left
ch = card_bot0 - card_top0
out["card_size"] = [cw, ch]
out["card_ratio"] = round(cw / ch, 4)
out["card_margins_pct"] = [round(card_left / W * 100, 2), round((W - card_right) / W * 100, 2)]

# card bg color sample (clean blue area, left-center)
out["card_bg_samples"] = {
    "left_mid": px[card_left + 30, (card_top0 + card_bot0) // 2],
    "left_low": px[card_left + 30, card_bot0 - 60],
    "center": px[cw // 2 + card_left, card_top0 + 40],
    "right_mid": px[card_right - 200, (card_top0 + card_bot0) // 2],
    "vignette_right": px[card_right - 40, card_bot0 - 120],
}

# corner radius: at the top edge, find where the straight edge starts
y_just_in = card_top0 + 1
f, l = edge_row(y_just_in + 2)
out["radius_probe_row_top"] = [f, l]  # inset from card_left at y=+3

# ── heading (white "Our work." top-left on dark bg) ───────────────────────
# scan for white-ish pixels in the top-left quadrant
hy = {}
for y in range(0, card_top0):
    for x in range(0, W // 2):
        r, g, b = px[x, y]
        if r > 200 and g > 200 and b > 200:
            hy.setdefault(y, []).append(x)
if hy:
    ys = sorted(hy)
    hd_top, hd_bot = ys[0], ys[-1]
    xs = [x for lst in hy.values() for x in lst]
    out["heading_bbox"] = [min(xs), hd_top, max(xs), hd_bot]
    out["heading_gap_to_card"] = card_top0 - hd_bot

# ── text group inside card (white NBCU. + pale blue headline) ─────────────
# white text: scan inside card for near-white pixels in left half
white_rows = {}
for y in range(card_top0, card_bot0):
    for x in range(card_left, card_left + cw // 2):
        r, g, b = px[x, y]
        if r > 225 and g > 235 and b > 245:  # white-ish (not the blue bg)
            white_rows.setdefault(y, []).append(x)
# pale blue text: scan for pale blue
blue_rows = {}
for y in range(card_top0, card_bot0):
    for x in range(card_left, card_left + cw // 2):
        r, g, b = px[x, y]
        if b > 200 and 120 < r < 210 and 150 < g < 220 and b - r > 40:
            blue_rows.setdefault(y, []).append(x)

def summarize(rows, name):
    if not rows:
        out[name] = None
        return
    ys = sorted(rows)
    # cluster contiguous runs (line groups)
    lines = []
    start = prev = ys[0]
    for y in ys[1:]:
        if y - prev > 4:
            lines.append((start, prev))
            start = y
        prev = y
    lines.append((start, prev))
    res = []
    for (a, b) in lines:
        xs = [x for y in range(a, b + 1) for x in rows.get(y, [])]
        res.append({
            "y": [a, b], "h": b - a + 1,
            "x0": min(xs) - card_left, "x1": max(xs) - card_left,
            "color": px[min(rows[a], key=lambda x: 0) if False else rows[a][len(rows[a]) // 2], a],
        })
    out[name] = res

summarize(white_rows, "white_text_lines")
summarize(blue_rows, "blue_text_lines")

# ── phones: scan right half for light/dark UI areas vs blue bg ────────────
# phones are big; find columns in right half where pixels deviate from blue
phone_cols = {}
for x in range(card_left + cw // 3, card_right):
    cnt = 0
    for y in range(card_top0, card_bot0):
        r, g, b = px[x, y]
        if not (b > 120 and r < 130):  # not blue
            cnt += 1
    if cnt > 8:
        phone_cols[x] = cnt
if phone_cols:
    xs = sorted(phone_cols)
    # cluster
    groups = []
    s = p = xs[0]
    for x in xs[1:]:
        if x - p > 25:
            groups.append((s, p)); s = x
        p = x
    groups.append((s, p))
    out["phone_col_groups_pct_of_card"] = [
        [round((g[0] - card_left) / cw * 100, 1), round((g[1] - card_left) / cw * 100, 1)]
        for g in groups
    ]
# phone vertical extent (do they cross card top/bottom? check above/below card for non-bg)
above = 0
for y in range(0, card_top0):
    r, g, b = px[card_right - 250, y]
    if b > 90 and not (r < 40 and g < 40 and b < 45):
        above += 1
out["nonbg_rows_above_card_at_phone_x"] = above

# ── gold particles: sample colors in the blue area right-of-center ────────
goldish = []
for y in range(card_top0 + 20, card_bot0 - 20, 7):
    for x in range(card_left + int(cw * 0.42), card_right - 15, 7):
        r, g, b = px[x, y]
        if r > 180 and g > 130 and b < 130 and r - b > 70:
            goldish.append(((x - card_left) / cw, (y - card_top0) / ch, (r, g, b)))
out["gold_particle_samples"] = [
    [round(a, 3), round(b, 3), c] for a, b, c in goldish[:14]
]
out["gold_particle_count_sampled"] = len(goldish)

# ── showreel tile (bottom-right, black with white border) ─────────────────
# scan bottom-right region for the white border frame
sr_rows = {}
for y in range(card_top0, H):
    for x in range(card_left + int(cw * 0.55), W - 4):
        r, g, b = px[x, y]
        if r > 235 and g > 235 and b > 235:
            sr_rows.setdefault(y, []).append(x)
if sr_rows:
    ys = sorted(sr_rows)
    xs = [x for lst in sr_rows.values() for x in lst]
    srx0, srx1 = min(xs), max(xs)
    sry0, sry1 = ys[0], ys[-1]
    out["showreel_bbox"] = [srx0, sry0, srx1, sry1]
    out["showreel_size"] = [srx1 - srx0, sry1 - sry0]
    out["showreel_ratio"] = round((srx1 - srx0) / (sry1 - sry0), 3)
    out["showreel_right_inset_px"] = W - srx1
    out["showreel_bottom_inset_px"] = H - sry1
    out["showreel_right_inset_vw_pct"] = round((W - srx1) / W * 100, 2)
    # inner black area
    out["showreel_inner_sample"] = px[(srx0 + srx1) // 2, sry0 + 15]
    # border thickness: white run at mid height
    y_m = (sry0 + sry1) // 2
    run = 0
    for x in range(srx0, srx0 + 40):
        r, g, b = px[x, y_m]
        if r > 235 and g > 235 and b > 235:
            run += 1
        else:
            break
    out["showreel_border_px"] = run
    # gap between border and black (narrow separation)
    gap = 0
    if run:
        for x in range(srx0 + run, srx0 + run + 20):
            r, g, b = px[x, y_m]
            if r < 90 and g < 90 and b < 90:
                break
            gap += 1
    out["showreel_border_gap_px"] = gap

print(json.dumps(out, indent=1, default=str))
