#!/usr/bin/env python3
"""Task 42 pass 5 — exact headline line metrics (x-window excludes phones),
pill geometry, tile inner gap, corner radius, gold particle map."""
import json
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()
CARD = (25, 64, 1805, 558)
cl, ct, cr, cb = CARD
cw, ch = cr - cl, cb - ct
TILE = (1332, 232, 1806, 528)

# ── headline lines: pale-blue pixels, x in [40, 45% cardW] ────────────────
rows = {}
for y in range(ct, cb):
    n = 0
    for x in range(cl + 40, cl + int(cw * 0.45)):
        r, g, b = px[x, y]
        if b > 195 and 130 < r < 230 and 150 < g < 240 and b - r > 30 and b - g > 12:
            n += 1
    if n > 4:
        rows[y] = n
ys = sorted(rows)
lines = []
s = p = ys[0]
for y in ys[1:]:
    if y - p > 5:
        lines.append([s, p]); s = y
    p = y
lines.append([s, p])
print("HEADLINE LINES (x-window 40px..45% cardW):")
for i, (a, b) in enumerate(lines):
    # x extent at this line's core rows
    xs = []
    for y in range(a, b + 1):
        for x in range(cl, cl + int(cw * 0.6)):
            r, g, b2 = px[x, y]
            if b2 > 195 and 130 < r < 230 and 150 < g < 240 and b2 - r > 30 and b2 - g > 12:
                xs.append(x)
    core = [y for y in range(a, b + 1) if rows.get(y, 0) > max(6, max(rows[y] for y in [a]) if a in rows else 6)]
    print(f"  L{i+1}: y {a-ct}..{b-ct} (h={b-a+1})  x {min(xs)-cl}..{max(xs)-cl}  "
          f"peak_row_counts={[rows.get(y,0) for y in range(a,b+1,3)]}")
if len(lines) >= 2:
    print("  pitches:", [lines[i+1][0]-lines[i][0] for i in range(len(lines)-1)])

# ── pill geometry inside the tile ─────────────────────────────────────────
tx0, ty0, tx1, ty1 = TILE
tw, th = tx1 - tx0, ty1 - ty0
# pill: lighter-than-black pixels (the translucent plum pill over black+pink)
pill_rows = {}
for y in range(ty0, ty1):
    n = 0
    for x in range(tx0, tx1):
        r, g, b = px[x, y]
        if r > 60 and b > 70 and r < 200 and abs(r - b) < 60 and not (r > 185 and g < 140):
            n += 1
    if n > 40:
        pill_rows[y] = n
ys = sorted(pill_rows)
if ys:
    groups = []
    s = p = ys[0]
    for y in ys[1:]:
        if y - p > 4:
            groups.append([s, p]); s = y
        p = y
    groups.append([s, p])
    print("\nPILL ROW GROUPS:", [[a, b] for a, b in groups])
    # widest group = the pill body
    best = max(groups, key=lambda g: g[1] - g[0])
    pa, pb = best
    xs = []
    for y in range(pa, pb + 1):
        for x in range(tx0, tx1):
            r, g, b = px[x, y]
            if r > 60 and b > 70 and r < 200 and abs(r - b) < 60 and not (r > 185 and g < 140):
                xs.append(x)
    print(f"PILL: y {pa-ty0}..{pb-ty0} of {th}  x {min(xs)-tx0}..{max(xs)-tx0} of {tw}")
    print(f"  pill w% = {round((max(xs)-min(xs))/tw*100,1)}  h% = {round((pb-pa)/th*100,1)}")
    print(f"  center: x {round((min(xs)+max(xs))/2 - tx0 - tw/2)} from tile center, "
          f"y {round((pa+pb)/2 - ty0 - th/2)} from tile center")
    # pill color sample (center of pill, avoiding text)
    print("  pill color samples:", [px[(min(xs)+max(xs))//2 - 60, (pa+pb)//2], px[(min(xs)+max(xs))//2 + 60, (pa+pb)//2]])

# ── tile: gap between white border and black media ────────────────────────
print("\nTILE COLUMN at x=tile_mid (colors y 230..250):")
xm = (tx0 + tx1) // 2
seq = []
for y in range(230, 250):
    seq.append((y, px[xm, y]))
print(seq)

# corner radius: measure where the top border's straight run starts vs tile x0
# top border row y=233: find first/last white x
yr = ty0 + 1
first = last = None
for x in range(tx0 - 10, tx1 + 10):
    r, g, b = px[x, yr]
    if r > 225 and g > 232 and b > 238:
        if first is None: first = x
        last = x
print(f"\ntile top border straight run at y={yr}: x {first}..{last}")
print(f"  -> corner cut = {first - tx0}px each side (outer radius ~ this + border/2)")

# ── gold particles: full map (x,y in card %) ──────────────────────────────
gold = []
for y in range(ct, cb, 3):
    for x in range(cl, cr, 3):
        r, g, b = px[x, y]
        if r > 170 and g > 125 and b < 145 and r - b > 55 and g - b > 25:
            gold.append((round((x - cl) / cw, 3), round((y - ct) / ch, 3)))
print(f"\nGOLD PARTICLES (n={len(gold)}):")
print(gold)

# ── headline glyph color: sample core pixels of L1 ────────────────────────
if lines:
    a, b = lines[0]
    from collections import Counter
    cols = Counter()
    for y in range(a, b + 1):
        for x in range(cl + 40, cl + int(cw * 0.45)):
            r, g, bb = px[x, y]
            if bb > 195 and 130 < r < 230 and 150 < g < 240 and bb - r > 30 and bb - g > 12:
                cols[(r, g, bb)] += 1
    print("\nHEADLINE GLYPH COLORS (top 6):", json.dumps([[*c[0], c[1]] for c in cols.most_common(6)]))
