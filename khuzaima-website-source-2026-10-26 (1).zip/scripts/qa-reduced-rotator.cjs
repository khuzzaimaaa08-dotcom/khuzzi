/* eslint-disable @typescript-eslint/no-require-imports */
/* QA: manifesto rotator under prefers-reduced-motion — words must still cycle
   (crossfade only, no vertical movement), sizer handed off, no errors. */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1920, height: 1080 },
    reducedMotion: "reduce",
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });

  await page.goto("http://localhost:3000/", { waitUntil: "networkidle" });
  await page.evaluate(() =>
    window.scrollTo(0, document.getElementById("manifesto").offsetTop - 40));
  await page.waitForTimeout(2500);

  const sample = () => page.evaluate(() => {
    const words = [...document.querySelectorAll(".manifesto-rotator-word")];
    // word with the highest opacity (settled or mid-crossfade)
    const vis = words.reduce((best, w) =>
      parseFloat(w.style.opacity || "0") > parseFloat(best.style.opacity || "0") ? w : best, words[0]);
    const sizerOp = document.querySelector(".manifesto-rotator-sizer").style.opacity;
    // GSAP writes "translate(0px, 0px)" at rest — real movement shows % or non-zero px
    const moved = words.some((w) =>
      parseFloat(w.style.opacity || "0") > 0.5 &&
      /translate\([^)]*[1-9][\d.%]*[,)]/.test(w.style.transform || ""));
    return { word: vis ? vis.textContent : "?", sizerOp, moved };
  });

  const a = await sample();
  await page.waitForTimeout(2300);
  const b = await sample();
  await page.waitForTimeout(2300);
  const c = await sample();

  await page.screenshot({ path: "/home/z/my-project/scripts/shot-reduced.png" });

  console.log(JSON.stringify({ a, b, c, errors }, null, 1));
  const ok = a.word !== "?" && b.word !== "?" && c.word !== "?" &&
    (a.word !== b.word || b.word !== c.word) && !a.moved && !b.moved && !c.moved &&
    errors.length === 0;
  console.log(ok ? "REDUCED-MOTION QA: PASS" : "REDUCED-MOTION QA: FAIL");
  await browser.close();
  process.exit(ok ? 0 : 1);
})();
