#!/bin/bash
set -e
cd /home/z/my-project
S="agent-browser --session winter"
probe='(() => {
  const root = document.querySelector("[data-winter]");
  const ribbons = [...root.children[0].children].length;
  const flakes = [...root.querySelectorAll(".snow-y")].filter(n => n.parentElement.offsetParent !== null).length;
  const pines = [...root.querySelectorAll(".pine-lean")].filter(n => n.offsetParent !== null).length;
  const sparkles = [...root.querySelectorAll(".winter-twinkle")].filter(n => n.offsetParent !== null).length;
  const clock = document.querySelectorAll("[data-hero-ex] span")[1]?.textContent;
  return JSON.stringify({clock, ribbons, flakes, pines, sparkles, hScroll: document.documentElement.scrollWidth > document.documentElement.clientWidth});
})()'
for vp in "1440 900" "1366 768" "1280 720" "390 844"; do
  set -- $vp
  $S set viewport $1 $2 > /dev/null
  $S open "http://localhost:3000/?t=20:25" > /dev/null
  $S wait 2400 > /dev/null
  echo -n "$1x$2  "
  $S eval "$probe" | tail -1
done
$S set viewport 1920 1080 > /dev/null
