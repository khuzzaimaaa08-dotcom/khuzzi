#!/usr/bin/env python3
from PIL import Image
import numpy as np

ref = Image.open("/home/z/my-project/upload/pasted_image_1792669449481.png").convert("RGB")
a = np.asarray(ref).astype(int)
CX0, CY0, CW, CH = 74, 88, 1776, 491

print("     " + "".join(str((CX0 + i * 18) // 100 % 10) for i in range((CW) // 18)))
for yy in range(CY0, CY0 + CH, 18):
    row = ""
    for xx in range(CX0, CX0 + CW, 18):
        r, g, b = a[yy, xx]
        if r < 45 and g < 45 and b < 45: ch = "#"          # black (showreel bg / phone)
        elif r > 150 and g < 140 and 90 < b < 215: ch = "P" # pink
        elif r < 120 and g < 115 and b < 110: ch = "T"      # dark text/ink
        elif abs(r-235) < 14 and abs(g-231) < 14 and abs(b-226) < 16: ch = "."  # cream bg
        else: ch = "o"                                       # other (person, shadows)
        row += ch
    print(f"{yy:4d} {row}")
