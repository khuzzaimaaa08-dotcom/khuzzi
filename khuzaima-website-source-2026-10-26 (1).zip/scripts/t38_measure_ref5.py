#!/usr/bin/env python3
"""Pass 5: font-metric ground truth + showreel full bbox."""
from PIL import Image
import numpy as np

# ---- font metrics via fontTools ----
from fontTools.ttLib import TTFont
f = TTFont("/home/z/my-project/public/fonts/matter-semibold.woff2")
upem = f["head"].unitsPerEm
cap = f["OS/2"].sCapHeight if hasattr(f["OS/2"], "sCapHeight") else None
print(f"matter-semibold upem={upem} capHeight={cap} ({cap/upem:.3f}em)")
cmap = f.getBestCmap()
hmtx = f["hmtx"]
for ch in "NBCU.EnablgdiscofvrypO .":
    g = cmap.get(ord(ch))
    if g:
        adv = hmtx[g][0]
        print(f"  '{ch}' advance {adv} ({adv/upem:.3f}em)")

# title "NBCU." run = 220px, cap span = 59px
# run = em * (sum adv) / upem + 4 * tracking ; tracking = -0.05*em (source -2.77/55.39)
s = sum(hmtx[cmap[ord(c)]][0] for c in "NBCU.") / upem
print(f"\n'NBCU.' total advance {s:.3f}em")
em_from_cap = 59 / (cap / upem)
print(f"em from cap span 59px: {em_from_cap:.1f}px")
em_from_run = 220 / (s - 4 * 0.05)
print(f"em from run 220px (tracking -0.05em): {em_from_run:.1f}px")

im = Image.open("/home/z/my-project/upload/pasted_image_1792667125776.png").convert("RGB")
a = np.asarray(im).astype(int)

# desc 'E' first glyph: pale mask, y 293-352, x 105-200 — column profile
pm = (a[:,:,0] > 165) & (a[:,:,1] > 190) & (a[:,:,2] > 215)
sub = pm[293:353, 100:210]
cols = sub.sum(axis=0)
runs = []
inr = False
for i, c in enumerate(cols):
    if c > 0 and not inr: st = i; inr = True
    elif c == 0 and inr: runs.append((100+st, 100+i)); inr = False
if inr: runs.append((100+st, 210))
print(f"\ndesc first glyph runs (x): {runs[:8]}")

# title 'N' first glyph: white mask, y 194-253, x 105-200
wm = (a[:,:,0] > 200) & (a[:,:,1] > 200) & (a[:,:,2] > 200)
sub = wm[194:254, 100:210]
cols = sub.sum(axis=0)
runs = []
inr = False
for i, c in enumerate(cols):
    if c > 0 and not inr: st = i; inr = True
    elif c == 0 and inr: runs.append((100+st, 100+i)); inr = False
if inr: runs.append((100+st, 210))
print(f"title first glyph runs (x): {runs[:8]}")

# ---- showreel full-region scan: white ring in x 1250-1850, y 130-570 ----
wm2 = (a[:,:,0] > 225) & (a[:,:,1] > 232) & (a[:,:,2] > 238)
sub = wm2[130:570, 1250:1850]
ys, xs = np.where(sub)
print(f"\nshowreel-zone white pixels: y {130+ys.min()}-{130+ys.max()} x {1250+xs.min()}-{1250+xs.max()}")
# row and col density to find the ring edges
rd = sub.mean(axis=1)
cd = sub.mean(axis=0)
rr = np.where(rd > 0.10)[0]
cc = np.where(cd > 0.10)[0]
print(f"strong white rows: {130+rr.min() if len(rr) else '-'}..{130+rr.max() if len(rr) else '-'}; strong cols: {1250+cc.min() if len(cc) else '-'}..{1250+cc.max() if len(cc) else '-'}")

# scan horizontal at y=310 (through showreel upper area) from x=1250 to 1850
print("\nhorizontal scan y=310:")
out = []
for x in range(1250, 1850, 8):
    r, g, b = tuple(a[310, x])
    c = ("W" if r > 225 and b > 238 else "P" if r > 150 and g < 140 else "#" if r < 45 and g < 45 else "g" if 60 < r < 200 and g < 160 else ".")
    out.append(f"{x}:{c}")
print(" ".join(out))
# vertical scan at x=1750 (near right edge, through showreel)
print("vertical scan x=1750:")
out = []
for y in range(130, 570, 8):
    r, g, b = tuple(a[y, 1750])
    c = ("W" if r > 225 and b > 238 else "P" if r > 150 and g < 140 else "#" if r < 45 and g < 45 else "g" if 60 < r < 200 and g < 160 else ".")
    out.append(f"{y}:{c}")
print(" ".join(out))
