#!/usr/bin/env python3
"""Precise text + showreel measurement on the coin reference card."""
from PIL import Image
import numpy as np

ref = Image.open("/home/z/my-project/upload/pasted_image_1792669449481.png").convert("RGB")
a = np.asarray(ref).astype(int)
CX0, CY0, CW, CH = 74, 88, 1776, 491
card = a[CY0:CY0+CH, CX0:CX0+CW]

# title: DARK text (near #14110c) on cream bg — strict threshold
dark = (card[:,:,0] < 110) & (card[:,:,1] < 105) & (card[:,:,2] < 100)
# exclude showreel zone (right 30%, bottom 65%) — find it first
# showreel: black tile (very dark, large solid block) bottom-right
blk = (card[:,:,0] < 40) & (card[:,:,1] < 40) & (card[:,:,2] < 40)
br = blk[int(CH*0.3):, int(CW*0.55):]
ys, xs = np.where(br)
if len(ys):
    st, sb = int(CH*0.3)+ys.min(), int(CH*0.3)+ys.max()
    sl, sr_ = int(CW*0.55)+xs.min(), int(CW*0.55)+xs.max()
    print(f"SHOWREEL black tile: x {sl}-{sr_} y {st}-{sb}")
    print(f"  -> w {100*(sr_-sl)/CW:.1f}%W h {100*(sb-st)/CH:.1f}%H top {100*st/CH:.1f}%H right-gap {100*(CW-sr_)/CW:.1f}%W bottom-gap {100*(CH-sb)/CH:.1f}%H")

# title text: dark pixels in left 60%, excluding showreel columns
tz = dark[:, :int(CW*0.60)]
ys2, xs2 = np.where(tz)
if len(ys2):
    print(f"TITLE dark-text zone: x {xs2.min()}-{xs2.max()} y {ys2.min()}-{ys2.max()}")
    print(f"  -> left {100*xs2.min()/CW:.1f}%W top {100*ys2.min()/CH:.1f}%H glyph-h {ys2.max()-ys2.min()}px = {100*(ys2.max()-ys2.min())/CH:.1f}%H")
    # separate title line vs description by row gaps
    dens = tz.mean(axis=1)
    bands, inb = [], False
    for i, d in enumerate(dens):
        if d > 0.004 and not inb: s = i; inb = True
        elif d <= 0.004 and inb: bands.append((s, i)); inb = False
    if inb: bands.append((len(dens), 0))
    for s, e in bands:
        if e - s < 10: continue
        sub = tz[s:e]
        xx = np.where(sub.any(axis=0))[0]
        sample = np.where(sub)
        cy, cx = sample[0][len(sample[0])//2], sample[1][len(sample[0])//2]
        print(f"    band y {s}-{e} (h={e-s}) x {xx.min()}-{xx.max()} color rgb{tuple(card[cy, cx])}")

# gray description color check: sample between title bands
# CTA chip? look for a pill with border top-left
print("bg samples:", tuple(card[int(CH*0.12), int(CW*0.05)]), tuple(card[int(CH*0.9), int(CW*0.05)]))
