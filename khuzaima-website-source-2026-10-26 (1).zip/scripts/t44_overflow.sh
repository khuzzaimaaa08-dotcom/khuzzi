#!/bin/bash
# Task 44 — h-overflow sweep at odd widths, rest + pinned + released.
PORT=3000

check() { # $1=w $2=h
  agent-browser set viewport "$1" "$2" >/dev/null 2>&1
  agent-browser open "http://localhost:$PORT/?ov=$1x$2" >/dev/null 2>&1
  agent-browser wait --load networkidle >/dev/null 2>&1
  sleep 1.2
  agent-browser eval "(() => {
    const d = document.scrollingElement;
    const stage = document.querySelector('.work-stage');
    const top = stage.getBoundingClientRect().top + scrollY;
    const travel = 3 * document.querySelector('.work-slide').offsetWidth;
    const rest = d.scrollWidth - d.clientWidth;
    scrollTo(0, top + travel * 0.5);
    return new Promise(r => setTimeout(() => {
      const mid = d.scrollWidth - d.clientWidth;
      const card = document.querySelector('.work-card');
      const cr = card.getBoundingClientRect();
      scrollTo(0, top + travel + 300);
      setTimeout(() => {
        const done = d.scrollWidth - d.clientWidth;
        const gutter = Math.round(card.getBoundingClientRect().left);
        r(JSON.stringify({vp: '$1x$2', rest, mid, done, gutterAtStart: gutter, ratio: +(cr.width/cr.height).toFixed(4)}));
      }, 1800);
    }), 1800);
  })()" 2>&1
}

for wh in "1367 850" "1025 700" "800 900" "375 700" "320 600" "1921 900"; do
  check ${wh}
done
