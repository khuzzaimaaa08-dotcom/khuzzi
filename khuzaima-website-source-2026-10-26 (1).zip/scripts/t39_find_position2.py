#!/usr/bin/env python3
"""Locate the cream-clad person via distance from the flat off-white bg."""
from PIL import Image
import numpy as np

def person_bbox(img, bg=(245, 242, 235), tol=26):
    a = np.asarray(img.convert("RGB")).astype(int)
    d = np.sqrt(((a - np.array(bg)) ** 2).sum(axis=2))
    m = d > tol
    # clean: erode-ish via row/col density
    H, W = m.shape
    rd = np.convolve(m.mean(axis=1), np.ones(9) / 9, "same")
    cd = np.convolve(m.mean(axis=0), np.ones(9) / 9, "same")
    rows = np.where(rd > 0.06)[0]; cols = np.where(cd > 0.05)[0]
    if not len(rows) or not len(cols):
        return None
    return cols.min(), cols.max(), rows.min(), rows.max()

ref = Image.open("/home/z/my-project/upload/pasted_image_1792669449481.png").convert("RGB")
card = ref.crop((74, 88, 74 + 1776, 88 + 491))
r = person_bbox(card)
W, H = card.size
print(f"REF person: x {r[0]}-{r[1]} center {((r[0]+r[1])/2/W*100):.1f}%W  y {r[2]}-{r[3]} center {((r[2]+r[3])/2/H*100):.1f}%H  (w {(r[1]-r[0])/W*100:.0f}%W)")

asset = Image.open("/tmp/coin-desktop.png").convert("RGB")
r2 = person_bbox(asset)
aw, ah = asset.size
print(f"ASSET person: x {r2[0]}-{r2[1]} center {((r2[0]+r2[1])/2/aw*100):.1f}%W  y {r2[2]}-{r2[3]} center {((r2[2]+r2[3])/2/ah*100):.1f}%H")

# cover into 1776x491: scale 1776/1360=1.3059 -> 1776x963.7
sh = ah * 1776 / aw
for p in [0.3, 0.4, 0.5, 0.6, 0.7]:
    top = (sh - 491) * p
    crop = asset.resize((1776, round(sh)), Image.LANCZOS).crop((0, round(top), 1776, round(top + 491)))
    rr = person_bbox(crop)
    if rr:
        print(f"p={p}: person x-center {((rr[0]+rr[1])/2/1776*100):.1f}%W y {rr[2]}-{rr[3]} center {((rr[2]+rr[3])/2/491*100):.1f}%H visible-h {(rr[3]-rr[2])/491*100:.0f}%")
