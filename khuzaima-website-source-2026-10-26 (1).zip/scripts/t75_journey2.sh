#!/usr/bin/env bash
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"

shot() { # $1 = y, $2 = name
  $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1
  sleep 1.8
  $AB screenshot "$OUT/$2.png" >/dev/null 2>&1
  echo "shot $2 @ y=$1"
}

shot 3348  j03-manifesto
shot 3843  j04-craft
shot 4421  j05-brands
shot 5009  j06-work-start
shot 6800  j07-work-card2
shot 8592  j08-work-card3
shot 10385 j09-work-card4
shot 11679 j10-how-statement
shot 12510 j11-how-1142
shot 15021 j12-services
shot 18017 j13-process
shot 18680 j14-privacy
shot 19536 j15-finalcta
shot 19812 j16-footer
