#!/usr/bin/env python3
"""Robust ours-vs-reference nav weight comparison.

The reference screenshot carries a dark vertical bar at its right edge and is
captured at a different scale (likely dpr 2). Strategy:
  1. In the reference, drop columns that are near-solid dark (the bar), then
     take the text-only bounding box.
  2. Scale the reference text so its width matches ours (identical font file
     + identical longest line "Discover our solutions." => width is a true
     scale proxy).
  3. Re-measure stroke runs and ink at matched scale.
  4. Emit composites: ours|ref (matched scale) and before|after (ours).
"""
from PIL import Image
import numpy as np
from collections import Counter

def text_bbox_excluding_bar(img: Image):
    a = np.array(img)
    d = a < 128
    h, w = d.shape
    col_dark_frac = d.mean(axis=0)
    # columns that are near-solid dark = the bar
    bar_cols = col_dark_frac > 0.7
    keep = d.copy()
    keep[:, bar_cols] = False
    rows = np.where(keep.any(axis=1))[0]
    cols = np.where(keep.any(axis=0))[0]
    return img.crop((cols.min(), rows.min(), cols.max() + 1, rows.max() + 1)), bool(bar_cols.any())

def stroke_stats(img: Image, label: str):
    a = np.array(img)
    d = a < 128
    ink = d.sum()
    # ink per text height (rows occupied) — comparable across images once widths match
    rows = np.where(d.any(axis=1))[0]
    height = rows.max() - rows.min() + 1 if len(rows) else 1
    runs = []
    for line in d:
        c = 0
        for v in line:
            if v:
                c += 1
            elif c:
                runs.append(c)
                c = 0
        if c:
            runs.append(c)
    runs = [r for r in runs if 1 <= r <= 12]
    modal = Counter(runs).most_common(4)
    print(f"{label}: size={img.size} ink={ink} textH={height} ink/textH={ink/height:.1f} strokes={modal}")
    return {"ink": ink, "h": height, "modal": modal, "img": img}

ours = Image.open("/home/z/my-project/qa/after-nav.png").convert("L").crop((1268, 455, 1268 + 295, 455 + 240))
before = Image.open("/home/z/my-project/qa/before-nav.png").convert("L").crop((1268, 455, 1268 + 295, 455 + 240))
ref_full = Image.open("/home/z/my-project/upload/pasted_image_1792477162472.png").convert("L")
ref, had_bar = text_bbox_excluding_bar(ref_full)
print(f"reference had dark bar: {had_bar}")

so = stroke_stats(ours, "OURS (after) ")
sb = stroke_stats(before, "OURS (before)")
sr = stroke_stats(ref, "REFERENCE  ")

# scale reference so widths match ours (same font file, same longest line)
scale = ours.width / ref.width
ref_scaled = ref.resize((int(round(ref.width * scale)), int(round(ref.height * scale))), Image.LANCZOS)
srs = stroke_stats(ref_scaled, "REF@samescale")

# composite: ours | ref at matched scale
pad = 30
h = max(ours.height, ref_scaled.height)
comp = Image.new("RGB", (ours.width + ref_scaled.width + pad * 3, h + pad * 2), "white")
comp.paste(ours, (pad, pad))
comp.paste(ref_scaled, (pad * 2 + ours.width, pad))
comp.save("/home/z/my-project/qa/compare-nav.png")
print("saved qa/compare-nav.png (left=ours@25px, right=reference matched scale)")

# composite: before | after
h2 = max(before.height, ours.height)
comp2 = Image.new("RGB", (before.width + ours.width + pad * 3, h2 + pad * 2), "white")
comp2.paste(before, (pad, pad))
comp2.paste(ours, (pad * 2 + before.width, pad))
comp2.save("/home/z/my-project/qa/compare-before-after.png")
print("saved qa/compare-before-after.png (left=before, right=after)")
