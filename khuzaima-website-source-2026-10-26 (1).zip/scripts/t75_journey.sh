#!/usr/bin/env bash
# Task 75 — diagnose: full-page journey screenshots
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"

$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3

# 1. hero top (9am)
$AB screenshot "$OUT/j01-hero-top.png" >/dev/null 2>&1

# use the ?t= dev aid for hero stages
for T in "13:00" "20:00" "23:42"; do
  $AB open "http://localhost:3000/?t=$T" >/dev/null 2>&1
  $AB wait --load networkidle >/dev/null 2>&1
  sleep 3
  SAFE=${T/:/}
  $AB screenshot "$OUT/j02-hero-$SAFE.png" >/dev/null 2>&1
done

# document geometry + section offsets
$AB eval "
(() => {
  const ids = {};
  document.querySelectorAll('section, footer').forEach(s => {
    const k = s.id || s.tagName.toLowerCase();
    ids[k] = Math.round(s.getBoundingClientRect().top + scrollY);
  });
  return JSON.stringify({docH: document.documentElement.scrollHeight, sections: ids});
})()
"
