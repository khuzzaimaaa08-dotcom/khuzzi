#!/usr/bin/env bash
# Task 75 — QA battery 1: desktop geometry + journey
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3

echo "=== 1. page geometry ==="
$AB eval "
(() => {
  const nd = document.getElementById('never-done');
  const sec = nd.querySelector('.never-done');
  const title = nd.querySelector('.never-done-title');
  const sub = nd.querySelector('.never-done-sub');
  const cs = getComputedStyle(title);
  const secCs = getComputedStyle(nd);
  const t = title.getBoundingClientRect();
  const s = sub.getBoundingClientRect();
  const sections = {};
  document.querySelectorAll('section, footer').forEach(x => { sections[x.id || x.tagName.toLowerCase()] = Math.round(x.getBoundingClientRect().top + scrollY); });
  return JSON.stringify({
    docH: document.documentElement.scrollHeight,
    sections,
    ndSecH: nd.offsetHeight,
    bg: secCs.backgroundColor,
    titleFont: cs.fontWeight + ' ' + cs.fontSize + '/' + cs.lineHeight + '/' + cs.letterSpacing,
    titleLeft: +t.left.toFixed(1),
    subLeft: +s.left.toFixed(1),
    overflowX: document.documentElement.scrollWidth - innerWidth,
    chatdemoGone: !document.querySelector('.chatdemo-screen, .chatdemo-stack, #how, #demo-title')
  });
})()
"

echo "=== 2. scroll to statement (junction + composition) ==="
$AB eval "window.scrollTo(0, document.getElementById('never-done').getBoundingClientRect().top + scrollY)" >/dev/null 2>&1
sleep 2
$AB eval "
(() => {
  const title = document.querySelector('.never-done-title');
  const t = title.getBoundingClientRect();
  const sub = document.querySelector('.never-done-sub').getBoundingClientRect();
  return JSON.stringify({titleTopInView: +t.top.toFixed(1), capTopPctVh: +((t.top + 14) / innerHeight * 100).toFixed(1), subTop: +sub.top.toFixed(1), gap: +(sub.top - t.bottom).toFixed(1)});
})()
"
$AB screenshot "$OUT/f01-statement-open.png" >/dev/null 2>&1

echo "=== 3. reveal states ==="
$AB eval "window.scrollTo(0, document.getElementById('never-done').getBoundingClientRect().top + scrollY - 600)" >/dev/null 2>&1
sleep 1.2
$AB screenshot "$OUT/f02-reveal-pre.png" >/dev/null 2>&1
$AB eval "window.scrollTo(0, document.getElementById('never-done').getBoundingClientRect().top + scrollY - 250)" >/dev/null 2>&1
sleep 1.2
$AB screenshot "$OUT/f03-reveal-mid.png" >/dev/null 2>&1
$AB eval "window.scrollTo(0, document.getElementById('never-done').getBoundingClientRect().top + scrollY + 100)" >/dev/null 2>&1
sleep 2
$AB screenshot "$OUT/f04-reveal-post.png" >/dev/null 2>&1
$AB eval "
(() => {
  const spans = document.querySelectorAll('.never-done-title .reveal-line > span');
  return JSON.stringify([...spans].map(s => getComputedStyle(s).transform));
})()
"

echo "=== 4. Services seam ==="
$AB eval "window.scrollTo(0, document.getElementById('services').getBoundingClientRect().top + scrollY - 40)" >/dev/null 2>&1
sleep 2
$AB screenshot "$OUT/f05-services-seam.png" >/dev/null 2>&1
$AB eval "
(() => {
  const svc = document.getElementById('services');
  const cs = getComputedStyle(svc);
  return JSON.stringify({servicesBg: cs.backgroundColor, ndBottom: document.getElementById('never-done').getBoundingClientRect().bottom});
})()
"

echo "=== 5. console errors ==="
$AB errors 2>/dev/null | head -10
