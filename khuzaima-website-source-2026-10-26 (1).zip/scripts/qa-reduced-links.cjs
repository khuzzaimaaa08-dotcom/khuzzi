const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: "reduce" });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("http://localhost:3000", { waitUntil: "networkidle" });
  await page.evaluate(() => document.fonts.ready);
  await page.locator("#craft").scrollIntoViewIfNeeded();
  await page.waitForTimeout(500);
  const res = await page.evaluate(() => {
    const link = document.querySelectorAll(".craft-link")[1];
    const chars = [...link.querySelectorAll(".craft-link-char")];
    const charTransition = getComputedStyle(chars[0]).transitionProperty;
    return {
      linkCount: document.querySelectorAll(".craft-link").length,
      charTransitionProperty: charTransition,
      staticDark: getComputedStyle(link).color,
    };
  });
  // hover under reduced motion — chars must NOT move
  const link = page.locator(".craft-link").nth(1);
  await link.hover();
  await page.waitForTimeout(800);
  const after = await page.evaluate(() => {
    const chars = [...document.querySelectorAll(".craft-link")[1].querySelectorAll(".craft-link-char")];
    return chars.every((c) => getComputedStyle(c).transform === "none");
  });
  console.log(JSON.stringify({ ...res, charsStaticUnderHover: after, pageErrors: errors }, null, 1));
  await browser.close();
})().catch((e) => { console.error("FAILED:", e.message); process.exit(1); });
