#!/usr/bin/env python3
"""Pixel-measure the NBCU reference card attachment (1898x581).

Detects: card bbox (vs image), corner radius, title/description glyph boxes,
line breaks, phone bboxes, showreel bbox + border + pill, bg colors.
"""
from PIL import Image
import numpy as np

im = Image.open("/home/z/my-project/upload/pasted_image_1792667125776.png").convert("RGB")
a = np.asarray(im).astype(int)
H, W = a.shape[:2]
print(f"image {W}x{H}")

# --- 1. Card bbox: scan for the blue card vs surrounding background ---
# sample corners
for name, (y, x) in {"tl": (2, 2), "tr": (2, W - 3), "bl": (H - 3, 2), "br": (H - 3, W - 3), "mid-top": (2, W // 2)}.items():
    print(f"corner {name}: rgb{tuple(a[y, x])}")

# blue-ness mask: card is vivid blue (B substantially > R, B > 100)
blue = (a[:, :, 2] > 120) & (a[:, :, 2] > a[:, :, 0] + 30) & (a[:, :, 1] < a[:, :, 2])
ys, xs = np.where(blue)
print(f"blue pixel count {blue.sum()}, x range {xs.min()}-{xs.max()}, y range {ys.min()}-{ys.max()}")

# row/col profiles to find card edges (rows/cols that are >60% blue)
rowfrac = blue.mean(axis=1)
colfrac = blue.mean(axis=0)
rows = np.where(rowfrac > 0.6)[0]
cols = np.where(colfrac > 0.6)[0]
if len(rows) and len(cols):
    top, bot = rows.min(), rows.max()
    left, right = cols.min(), cols.max()
    print(f"CARD bbox: x {left}-{right} (w={right-left+1}), y {top}-{bot} (h={bot-top+1})")
    cw, ch = right - left + 1, bot - top + 1
    print(f"card aspect {cw/ch:.3f}:1")

    # --- 2. corner radius: on row top+1..30, find first blue col from left ---
    r_est = []
    for yy in range(top, top + 40):
        row = np.where(blue[yy, left:left + 60])[0]
        if len(row):
            r_est.append((yy - top, row.min()))
    print("corner profile (dy, dx-to-first-blue):", r_est[:20])

    # --- 3. bg color samples inside card ---
    for name, (yy, xx) in {
        "bg-left-mid": (top + ch // 2, left + cw // 20),
        "bg-top-center": (top + 8, (left + right) // 2),
        "bg-center": (top + ch // 2, (left + right) // 2),
        "bg-right-mid": (top + ch // 2, right - cw // 20),
        "bg-bottom-center": (bot - 8, (left + right) // 2),
    }.items():
        print(f"  {name}: rgb{tuple(a[yy, xx])}")

    # --- 4. title "NBCU." white glyphs in upper-left ---
    # white-ish mask inside card region above 40% height, left 0-30% width
    zone = a[top : top + int(ch * 0.45), left : left + int(cw * 0.35)]
    zw = (zone[:, :, 0] > 225) & (zone[:, :, 1] > 225) & (zone[:, :, 2] > 235)
    ys2, xs2 = np.where(zw)
    if len(ys2):
        print(f"WHITE text zone (upper-left): x {xs2.min()}-{xs2.max()} y {ys2.min()}-{ys2.max()}  (in card: x {left+xs2.min()}-{left+xs2.max()}, y {top+ys2.min()}-{top+ys2.max()})")
        print(f"  -> left margin {(xs2.min())/cw*100:.1f}% cardW, top {(top+ys2.min()-top)/ch*100:.1f}% cardH, glyph h {ys2.max()-ys2.min()}px = {(ys2.max()-ys2.min())/ch*100:.1f}% cardH")

    # --- 5. description lines: pale blue text (lighter than bg, not white) ---
    # pale: R 140-230, G 160-240, B 220-255, and R < B
    pale = (a[:, :, 0] > 120) & (a[:, :, 0] < 235) & (a[:, :, 2] > 200) & (a[:, :, 2] > a[:, :, 0] + 25) & (a[:, :, 1] > a[:, :, 0] - 10)
    # restrict to left 55% of card, below title
    zy1 = top + int(ch * 0.28)
    zy2 = bot - int(ch * 0.05)
    sub = pale[zy1:zy2, left : left + int(cw * 0.60)]
    ys3, xs3 = np.where(sub)
    if len(ys3):
        print(f"PALE text zone: x {xs3.min()}-{xs3.max()} y {ys3.min()}-{ys3.max()} (abs y {zy1+ys3.min()}-{zy1+ys3.max()})")
        # line segmentation: row density
        dens = sub.mean(axis=1)
        lines = []
        inl = False
        for i, d in enumerate(dens):
            if d > 0.01 and not inl:
                st = i; inl = True
            elif d <= 0.01 and inl:
                lines.append((st, i)); inl = False
        if inl: lines.append((len(dens) - 1, len(dens)))
        print(f"  {len(lines)} pale lines:")
        for st, en in lines:
            lsub = sub[st:en]
            lxs = np.where(lsub.any(axis=0))[0]
            gh = en - st
            print(f"    y {zy1+st}-{zy1+en} (h={gh}px, {(zy1+st-top)/ch*100:.1f}% cardH) x {lxs.min()}-{lxs.max()} w={lxs.max()-lxs.min()}px")
        # sample a pale text pixel color
        print(f"  pale sample rgb{tuple(a[zy1+ys3[0], left+xs3[0]])}")

    # --- 6. phones: dark rectangles (screen areas) in right 55% ---
    dark = (a[:, :, 0] < 60) & (a[:, :, 1] < 60) & (a[:, :, 2] < 70)
    rightslice = dark[:, left + int(cw * 0.40) : right - int(cw * 0.02)]
    ys4, xs4 = np.where(rightslice)
    if len(ys4):
        print(f"DARK (phone screens) in right zone: y {ys4.min()}-{ys4.max()} x {left+int(cw*0.40)+xs4.min()}-{left+int(cw*0.40)+xs4.max()}")

    # --- 7. showreel thumbnail: black block with white border bottom-right ---
    # white border: strong white pixels in bottom-right quadrant
    br = a[bot - int(ch * 0.5) : bot, left + int(cw * 0.60) : right]
    brw = (br[:, :, 0] > 235) & (br[:, :, 1] > 235) & (br[:, :, 2] > 235)
    ys5, xs5 = np.where(brw)
    if len(ys5):
        print(f"WHITE (showreel border?) bottom-right: y {bot-int(ch*0.5)+ys5.min()}-{bot-int(ch*0.5)+ys5.max()} x {left+int(cw*0.60)+xs5.min()}-{left+int(cw*0.60)+xs5.max()}")
        # histogram of white rows to see the border box
        rd = brw.mean(axis=1)
        rr = np.where(rd > 0.05)[0]
        cd = brw.mean(axis=0)
        cc = np.where(cd > 0.05)[0]
        if len(rr) and len(cc):
            sy_top, sy_bot = bot - int(ch * 0.5) + rr.min(), bot - int(ch * 0.5) + rr.max()
            sx_left, sx_right = left + int(cw * 0.60) + cc.min(), left + int(cw * 0.60) + cc.max()
            print(f"  showreel bbox est: x {sx_left}-{sx_right} (w={sx_right-sx_left}) y {sy_top}-{sy_bot} (h={sy_bot-sy_top})")
            print(f"  -> right margin {(right-sx_right)/cw*100:.1f}% cardW, bottom margin {(bot-sy_bot)/ch*100:.1f}% cardH, w {100*(sx_right-sx_left)/cw:.1f}% cardW, h {100*(sy_bot-sy_top)/ch:.1f}% cardH, aspect {(sx_right-sx_left)/(sy_bot-sy_top):.2f}")
            # black inside sample
            print(f"  inside-black sample rgb{tuple(a[(sy_top+sy_bot)//2, (sx_left+sx_right)//2])}")

    # --- 8. pill inside showreel: glassy dark pill ---
    # scan the showreel interior for a row with a wide run of mid-dark pixels differing from pure black
print("done")
