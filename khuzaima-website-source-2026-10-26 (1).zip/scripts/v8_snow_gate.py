#!/usr/bin/env python3
"""v8 snow gate: 2-frame diff -> moving flake clusters; also 21:30 must be static."""
from PIL import Image, ImageChops
import numpy as np
import sys

def moving_clusters(a_path, b_path, label, thr=26):
    a = np.asarray(Image.open(a_path).convert("L"), dtype=np.int16)
    b = np.asarray(Image.open(b_path).convert("L"), dtype=np.int16)
    d = np.abs(b - a)
    mask = d > thr
    # exclude the clock/text column (x > 66%) and bottom landscape band (y > 78%)
    H, W = mask.shape
    mask[:, int(W * 0.66):] = False
    mask[int(H * 0.80):, :] = False
    # simple cluster count via dilate-free labeling
    from scipy import ndimage
    lab, n = ndimage.label(mask)
    sizes = ndimage.sum(mask, lab, range(1, n + 1))
    flakes = int((sizes >= 2).sum())  # clusters of >=2 px
    # mean vertical movement direction of changed pixels
    moved = mask.sum()
    print(f"{label}: changed_px={moved} clusters>=2px={flakes}")
    return flakes, moved

if __name__ == "__main__":
    pairs = sys.argv[1:]
    for i in range(0, len(pairs), 3):
        moving_clusters(pairs[i], pairs[i+1], pairs[i+2])
