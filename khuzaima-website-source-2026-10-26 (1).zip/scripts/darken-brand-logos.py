#!/usr/bin/env python3
"""Darken the client-wall logos (Task 21).

The Task-20 treatment mapped source luminance to *proportional* alpha
(opacity = (0.82 - lum) / 0.82), so mid-tone letterforms landed at ~45-70%
opacity and read as faded gray on the warm-white cards. This pass recovers
true coverage from that alpha channel:

  - interior/tonal alpha (>= ~140)  -> fully opaque
  - anti-aliased edge alpha         -> smooth ramp preserved (smoothstep)
  - faint background haze (< ~25)   -> dropped

Ink is re-tinted to the requested dark charcoal #242424 at 100% opacity.
Geometry is untouched — same pixels, same sizes, same aspect ratios.

Originals are backed up to scripts/brand-logos-backup-v1/ first.

Task 22: Shan and Jazz still read lighter than the wall (their script and
badge marks carry more sub-solid coverage), so they get a per-brand override —
re-inked to the site's near-black #0D0B0A with a slightly steeper edge ramp.
The other six keep the #242424 charcoal treatment unchanged.
"""
from PIL import Image
import numpy as np
import os, shutil, math

BRANDS = "/home/z/my-project/public/brands"
BACKUP = "/home/z/my-project/scripts/brand-logos-backup-v1"
os.makedirs(BACKUP, exist_ok=True)

DEFAULT_INK = np.array([36, 36, 36], dtype=np.uint8)  # #242424 dark charcoal

# smoothstep edges: alpha below LO vanishes, above HI is solid ink
DEFAULT_LO, DEFAULT_HI = 25.0, 140.0

# Task 22: the two marks whose coverage profile left them reading lighter.
OVERRIDES = {
    "shan": {"ink": np.array([13, 11, 10], dtype=np.uint8), "lo": 25.0, "hi": 118.0},
    "jazz": {"ink": np.array([13, 11, 10], dtype=np.uint8), "lo": 25.0, "hi": 118.0},
}

def smoothstep(x, lo=DEFAULT_LO, hi=DEFAULT_HI):
    t = np.clip((x - lo) / (hi - lo), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)

CARD = np.array([250, 248, 244], dtype=np.float32)  # #FAF8F4

def rendered_lum(alpha, ink=DEFAULT_INK):
    """Luminance of ink-over-card blend (0-255 scale) for reporting."""
    v = alpha.astype(np.float32) / 255.0
    rgb = ink.astype(np.float32)[None, :] * v[:, None] + CARD[None, :] * (1 - v[:, None])
    return 0.2126 * rgb[:, 0] + 0.7152 * rgb[:, 1] + 0.0722 * rgb[:, 2]

files = sorted(f for f in os.listdir(BRANDS) if f.endswith(".png"))
report = []
for f in files:
    src = os.path.join(BRANDS, f)
    bak = os.path.join(BACKUP, f)
    if not os.path.exists(bak):
        shutil.copy2(src, bak)  # keep pristine Task-20 version

    name = f[:-4]
    cfg = OVERRIDES.get(name, {})
    ink = cfg.get("ink", DEFAULT_INK)

    img = Image.open(bak).convert("RGBA")
    a = np.array(img)
    old_alpha = a[:, :, 3]
    a1 = smoothstep(old_alpha.astype(np.float32), cfg.get("lo", DEFAULT_LO), cfg.get("hi", DEFAULT_HI)) * 255.0
    # Per-logo auto-gain: logos whose densest source tone mapped below ~140
    # (e.g. HBL's teal interior -> alpha 117) never reach solid ink with the
    # global curve alone; stretch so each mark's own peak is fully opaque.
    peak = a1.max()
    if peak > 40 and peak < 250.0:
        a1 = np.clip(a1 * (255.0 / peak), 0.0, 255.0)
    new_alpha = a1.astype(np.uint8)

    out = np.zeros_like(a)
    out[:, :, 0] = ink[0]
    out[:, :, 1] = ink[1]
    out[:, :, 2] = ink[2]
    out[:, :, 3] = new_alpha
    Image.fromarray(out, "RGBA").save(src)

    m_old = old_alpha > 8
    m_new = new_alpha > 8
    lum_old = rendered_lum(old_alpha[m_old], ink) if m_old.any() else np.array([0])
    lum_new = rendered_lum(new_alpha[m_new], ink) if m_new.any() else np.array([0])
    solid = (new_alpha[m_new] >= 250).mean() * 100 if m_new.any() else 0
    report.append(
        f"{f:14s} ink-px {m_new.sum():7d} (was {m_old.sum():7d})  "
        f"rendered lum {lum_old.mean():5.1f} -> {lum_new.mean():5.1f}  "
        f"solid>=250a: {solid:4.1f}%"
    )

print("\n".join(report))

# Preview strip: before | after on the card color, for eyeball/VLM check
names = [f[:-4] for f in files]
cell_w, cell_h, pad = 360, 240, 16
strip = Image.new("RGB", (cell_w * 2 + pad * 3, (cell_h + pad) * 2 + pad), (234, 231, 225))
for i, name in enumerate(names):
    col, row = i % 4, i // 4
    for slot, folder in ((0, BACKUP), (1, BRANDS)):
        card = Image.new("RGB", (cell_w, cell_h), (250, 248, 244))
        lg = Image.open(os.path.join(folder, name + ".png")).convert("RGBA")
        scale = min((cell_w * 0.72) / lg.width, (cell_h * 0.6) / lg.height)
        lg = lg.resize((max(1, round(lg.width * scale)), max(1, round(lg.height * scale))), Image.LANCZOS)
        card.paste(lg, ((cell_w - lg.width) // 2, (cell_h - lg.height) // 2), lg)
        strip.paste(card, (pad + slot * (cell_w + pad) + col * 0, pad + row * (cell_h + pad)))
# arrange 2 rows x 4 cols; shift second column block properly
strip2 = Image.new("RGB", (cell_w * 2 + pad * 3, (cell_h + pad) * 2 + pad), (234, 231, 225))
for i, name in enumerate(names):
    row = i // 4
    for slot, folder in ((0, BACKUP), (1, BRANDS)):
        card = Image.new("RGB", (cell_w, cell_h), (250, 248, 244))
        lg = Image.open(os.path.join(folder, name + ".png")).convert("RGBA")
        scale = min((cell_w * 0.72) / lg.width, (cell_h * 0.6) / lg.height)
        lg = lg.resize((max(1, round(lg.width * scale)), max(1, round(lg.height * scale))), Image.LANCZOS)
        card.paste(lg, ((cell_w - lg.width) // 2, (cell_h - lg.height) // 2), lg)
        x = pad + slot * (cell_w + pad)
        y = pad + row * (cell_h + pad)
        strip2.paste(card, (x, y))
strip2.save("/home/z/my-project/qa/logo-darken-preview.png")
print("\npreview: qa/logo-darken-preview.png  (left col = before, right col = after, rows of 4)")
