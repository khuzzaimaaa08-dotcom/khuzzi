#!/usr/bin/env python3
"""WCAG contrast audit for navbar v2 adaptive theme.

Checks the two nav foreground colors (#F5F7FF dark-theme, #0A0F1E
light-theme) and the CTA pill pairs against every background the glass
navbar can sit over: the four hero time-of-day skies, each tagged section
color, and the /book summer page. oklch() tokens are converted to sRGB.
"""
import math


def oklch_to_srgb(L, C, H):
    """oklch -> linear-ish sRGB via OkLab (JS-style, then gamma)."""
    h = math.radians(H)
    a = C * math.cos(h)
    b = C * math.sin(h)
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l = l_ ** 3
    m = m_ ** 3
    s = s_ ** 3
    r = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    bb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    def gamma(x):
        x = max(0.0, min(1.0, x))
        return 1.055 * x ** (1 / 2.4) - 0.055 if x > 0.0031308 else 12.92 * x
    return (gamma(r), gamma(g), gamma(bb))


def hex_to_rgb(hx):
    hx = hx.lstrip("#")
    return tuple(int(hx[i:i + 2], 16) / 255 for i in (0, 2, 4))


def rel_lum(rgb):
    def chan(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (chan(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(fg, bg):
    l1, l2 = sorted((rel_lum(fg), rel_lum(bg)), reverse=True)
    return (l1 + 0.05) / (l2 + 0.05)


TOKENS = {
    "ink": oklch_to_srgb(0.17, 0.03, 268),
    "paper": oklch_to_srgb(0.975, 0.006, 270),
    "ultramarine": oklch_to_srgb(0.49, 0.27, 268),
    "tangerine": oklch_to_srgb(0.70, 0.19, 42),
    "lilac": oklch_to_srgb(0.79, 0.11, 295),
    "sun": oklch_to_srgb(0.88, 0.17, 92),
    "summer": oklch_to_srgb(0.98, 0.02, 85),
}
FG_DARK = hex_to_rgb("#F5F7FF")   # links/logo on dark backgrounds
FG_LIGHT = hex_to_rgb("#0A0F1E")  # links/logo on light backgrounds
PILL_DARK_FG = hex_to_rgb("#0A0F1E")  # text inside white pill
PILL_LIGHT_FG = hex_to_rgb("#FFFFFF")  # text inside black pill

print("token      hex          sRGB-lum   #F5F7FF  #0A0F1E")
for name, rgb in TOKENS.items():
    hx = "#%02X%02X%02X" % tuple(round(c * 255) for c in rgb)
    r1 = ratio(FG_DARK, rgb)
    r2 = ratio(FG_LIGHT, rgb)
    print(f"{name:<10} {hx}  {rel_lum(rgb):.4f}    {r1:6.2f}  {r2:6.2f}")

print()
print("CTA pill internal contrast:")
print("  white pill  #0A0F1E on #FFFFFF :", round(ratio(PILL_DARK_FG, hex_to_rgb("#FFFFFF")), 2))
print("  black pill  #FFFFFF on #0A0F1E :", round(ratio(PILL_LIGHT_FG, hex_to_rgb("#0A0F1E")), 2))
