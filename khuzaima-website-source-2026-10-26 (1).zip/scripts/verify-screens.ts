import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const shots = [
  ['verify-home-hero.png', 'Desktop hero at top of page (morning state, 9:00 am). Expect: bold headline "Every inquiry answered, even at 11 pm.", clock showing 9:00 am, tangerine/orange sky background, header pill with "Khuzaima Labs" and "Book a free call" button.'],
  ['verify-home-night.png', 'Desktop hero scrolled deep into the page (night state). Expect: dark ultramarine night sky, clock showing ~10:04 pm, stars, possibly tree silhouette with owls, light text on dark background.'],
  ['verify-contact.png', 'Desktop contact page. Expect: lilac background, "Let\'s connect." heading, professional portrait photo of a man on white background, form fields (First Name, Last Name, Work Email, Company, Job Title), region radios, Send message button, dark circular close button top-right.'],
  ['verify-home-mobile.png', 'Mobile (390px) homepage hero. Expect: readable layout, header pill with logo and Book a free call button, headline, sky background, no horizontal overflow issues.'],
];

async function main() {
  const zai = await ZAI.create();
  for (const [file, expectation] of shots) {
    const path = `/home/z/my-project/scripts/${file}`;
    if (!fs.existsSync(path)) { console.log(`\n=== ${file}: MISSING ===`); continue; }
    const b64 = fs.readFileSync(path).toString('base64');
    try {
      const res = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: 'You are a meticulous QA reviewer for a marketing website. Answer concisely.' },
          {
            role: 'user',
            content: [
              { type: 'text', text: `Review this website screenshot. Expected: ${expectation}\n\n1) Does the screenshot match the expectation? 2) List any visual problems: blank areas, broken images, unstyled text (Times/serif fallback), overlapping elements, error messages, or layout breakage. Be specific and brief.` },
              { type: 'image_url', image_url: { url: `data:image/png;base64,${b64}` } },
            ],
          },
        ],
      });
      console.log(`\n===== ${file} =====`);
      console.log(res.choices[0]?.message?.content || '(no response)');
    } catch (e) {
      console.log(`\n===== ${file}: ERROR ===== ${e.message}`);
    }
  }
}

main().catch(e => { console.error(e); process.exit(1); });
