#!/usr/bin/env bash
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"
shot() { $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1; sleep 1.8; $AB screenshot "$OUT/$2.png" >/dev/null 2>&1; echo "shot $2"; }
shot 900   m01-hero-mid
shot 2000  m02-hero-late
shot 2900  m03-hero-night
shot 3376  m04-manifesto
shot 3690  m05-craft
shot 4467  m06-brands
shot 5175  m07-work-start
shot 6100  m08-work-mid1
shot 7000  m09-work-mid2
shot 7505  m10-how-statement
shot 8200  m11-how-mid
shot 8700  m12-how-settle
shot 10857 m13-services
shot 13549 m14-process
shot 15162 m15-finalcta
