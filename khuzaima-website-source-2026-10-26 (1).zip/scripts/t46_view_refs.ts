import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const shots = [
  ['pasted_image_1792681443670.png', 'Reference screenshot 1 of the "Never one and done." typography section (from hugeinc.com, 1.5x zoom).'],
  ['pasted_image_1792681457951.png', 'Reference screenshot 2 of the "Never one and done." typography section.'],
  ['pasted_image_1792681482683.png', 'Reference screenshot 3 of the "Never one and done." typography section.'],
  ['pasted_image_1792681496274.png', 'Reference screenshot 4 of the "Never one and done." typography section.'],
];

async function main() {
  const zai = await ZAI.create();
  for (const [file, label] of shots) {
    const path = `/home/z/my-project/upload/${file}`;
    if (!fs.existsSync(path)) { console.log(`\n=== ${file}: MISSING ===`); continue; }
    const b64 = fs.readFileSync(path).toString('base64');
    try {
      const res = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: 'You are a meticulous UI designer describing website screenshots for a developer who must replicate them. Be concise but precise.' },
          {
            role: 'user',
            content: [
              { type: 'text', text: `${label}\n\nDescribe: 1) All visible text content verbatim. 2) The layout/composition: where each text block sits, what is above/below it, any cards, images, or other UI elements visible. 3) Background color, text color, alignment. 4) Anything that appears cut off at the viewport edges (indicating surrounding content above/below).` },
              { type: 'image_url', image_url: { url: `data:image/png;base64,${b64}` } },
            ],
          },
        ],
      });
      console.log(`\n===== ${file} =====`);
      console.log(res.choices[0]?.message?.content || '(no response)');
    } catch (e) {
      console.log(`\n===== ${file}: ERROR ===== ${e.message}`);
    }
  }
}

main().catch(e => { console.error(e); process.exit(1); });
