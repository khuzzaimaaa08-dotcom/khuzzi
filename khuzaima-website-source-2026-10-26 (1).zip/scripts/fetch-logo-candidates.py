#!/usr/bin/env python3
"""Download all image-search candidates + build a numbered contact sheet per brand."""
import json, re, os, urllib.request
from PIL import Image
import numpy as np

os.chdir("/tmp/pkbrands")
brands = ["hbl2", "meezan", "jazz", "khaadi", "lama", "sapphire", "alfalah"]
UA = {"User-Agent": "Mozilla/5.0"}

manifest = {}
for b in brands:
    raw = open(f"{b}-raw.json").read()
    d = json.loads(re.search(r"\{.*\}", raw, re.S).group(0))
    files = []
    for i, r in enumerate(d["results"]):
        url = r["original_url"]
        ext = ".svg" if url.endswith(".svg") else ".png"
        fn = f"cand-{b}-{i}{ext}"
        try:
            req = urllib.request.Request(url, headers=UA)
            data = urllib.request.urlopen(req, timeout=30).read()
            open(fn, "wb").write(data)
            files.append(fn)
        except Exception as e:
            print(b, i, "DL FAIL", e)
    manifest[b] = files
    print(b, "->", len(files), "downloaded")

# contact sheet per brand: 4 cols
for b, files in manifest.items():
    thumbs = []
    for i, fn in enumerate(files):
        try:
            if fn.endswith(".svg"):
                # rasterize svg via cairosvg if available, else skip
                try:
                    import cairosvg, io
                    png = cairosvg.svg2png(url=fn, output_width=300)
                    img = Image.open(io.BytesIO(png)).convert("RGBA")
                except ImportError:
                    img = None
            else:
                img = Image.open(fn).convert("RGBA")
            if img is None: continue
            img.thumbnail((260, 160))
            canvas = Image.new("RGBA", (280, 200), (255, 255, 255, 255))
            canvas.paste(img, ((280-img.width)//2, (200-img.height)//2), img)
            thumbs.append((i, canvas))
        except Exception as e:
            print(b, fn, "IMG FAIL", e)
    if not thumbs: continue
    cols = 4
    rows = (len(thumbs)+cols-1)//cols
    sheet = Image.new("RGB", (cols*280, rows*220), "white")
    from PIL import ImageDraw
    dr = ImageDraw.Draw(sheet)
    for k, (i, t) in enumerate(thumbs):
        x, y = (k%cols)*280, (k//cols)*220
        sheet.paste(t.convert("RGB"), (x, y))
        dr.rectangle([x, y, x+280, y+200], outline="#cccccc")
        dr.text((x+8, y+204), f"#{i}", fill="red")
    sheet.save(f"sheet-{b}.png")
    print("sheet saved:", b, len(thumbs), "candidates")

json.dump(manifest, open("manifest.json", "w"), indent=1)
