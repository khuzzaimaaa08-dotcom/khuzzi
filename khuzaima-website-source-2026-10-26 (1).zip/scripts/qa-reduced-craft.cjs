/* QA: craft statement under prefers-reduced-motion — words must render
   statically near-black (#0D0B0A), no grey start, no scroll tween. */
const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    reducedMotion: "reduce",
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
  await page.goto("http://localhost:3000", { waitUntil: "networkidle" });
  await page.evaluate(() => document.fonts.ready);

  const craft = page.locator("#craft");
  await craft.scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);

  const sample = () =>
    page.evaluate(() =>
      [...document.querySelectorAll(".craft-word")].map((w) => ({
        text: w.textContent,
        color: getComputedStyle(w).color,
      })),
    );

  const before = await sample();
  await page.evaluate(() => {
    const s = document.querySelector("#craft");
    window.scrollTo(0, s.getBoundingClientRect().top + scrollY - innerHeight * 0.3);
  });
  await page.waitForTimeout(900);
  const after = await sample();

  const parse = (c) => {
    const m = c.match(/[\d.]+/g);
    return m ? m.slice(0, 3).map(Number) : null;
  };
  const isNearBlack = (c) => {
    const [r, g, b] = parse(c);
    return r < 30 && g < 30 && b < 30;
  };

  const ok = (arr) => arr.every((w) => isNearBlack(w.color));
  const unchanged = JSON.stringify(before) === JSON.stringify(after);

  console.log(
    JSON.stringify(
      {
        wordCount: after.length,
        lineSpanCount: await page.locator(".craft-line").count(),
        allNearBlackBefore: ok(before),
        allNearBlackAfter: ok(after),
        colorsStaticThroughScroll: unchanged,
        sampleColor: after[0] && after[0].color,
        pageErrors: errors,
      },
      null,
      1,
    ),
  );
  await browser.close();
})().catch((e) => {
  console.error("FAILED:", e.message);
  process.exit(1);
});
