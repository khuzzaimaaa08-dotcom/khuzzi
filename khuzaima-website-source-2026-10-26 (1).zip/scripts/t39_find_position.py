#!/usr/bin/env python3
"""Find the object-position the reference uses for the desktop asset,
by cover-cropping into the 3.59:1 card and comparing with the screenshot."""
from PIL import Image
import numpy as np

asset = Image.open("/tmp/coin-desktop.png").convert("RGB")
ref = Image.open("/home/z/my-project/upload/pasted_image_1792669449481.png").convert("RGB")

# reference card: x 74-1849, y 88-578 -> 1776x491
rw, rh = 1776, 491
card = ref.crop((74, 88, 74 + rw, 88 + rh))

# locate the person in the REFERENCE card (darkest blob region)
a = np.asarray(card).astype(int)
dark = (a[:,:,0] < 120) & (a[:,:,1] < 115) & (a[:,:,2] < 110)
ys, xs = np.where(dark)
print(f"ref person dark-pixel bbox: x {xs.min()}-{xs.max()} ({xs.min()/rw*100:.0f}-{xs.max()/rw*100:.0f}%W), center {((xs.min()+xs.max())/2/rw*100):.1f}%W")

# locate person in the ASSET
b = np.asarray(asset).astype(int)
d2 = (b[:,:,0] < 120) & (b[:,:,1] < 115) & (b[:,:,2] < 110)
ys2, xs2 = np.where(d2)
aw, ah = asset.size
print(f"asset person bbox: x {xs2.min()}-{xs2.max()} ({xs2.min()/aw*100:.0f}-{xs2.max()/aw*100:.0f}%W), center {((xs2.min()+xs2.max())/2/aw*100):.1f}%W; y {ys2.min()}-{ys2.max()} center {((ys2.min()+ys2.max())/2/ah*100):.1f}%H")

# cover math: scale to width 1776 -> 1776 x (738*1776/1360)=963.7; crop height 491.
# vertical position p (0=top,1=bottom): crop_top = (963.7-491)*p
sh = 738 * 1776 / 1360
for p in [0.0, 0.25, 0.5, 0.75, 1.0]:
    top = (sh - rh) * p
    crop = asset.resize((1776, round(sh)), Image.LANCZOS).crop((0, round(top), 1776, round(top + rh)))
    # person center in crop
    c = np.asarray(crop).astype(int)
    d3 = (c[:,:,0] < 120) & (c[:,:,1] < 115) & (c[:,:,2] < 110)
    yy, xx = np.where(d3)
    if len(xx):
        print(f"p={p}: person center x {((xx.min()+xx.max())/2/rw*100):.1f}%W, y-span {yy.min()}-{yy.max()} (of {rh})")
    crop.save(f"/home/z/my-project/qa/work-t38/coin-crop-p{int(p*100)}.png")

# also: what vertical span does the reference person occupy?
print(f"ref person y-span {ys.min()}-{ys.max()} (of {rh}) = {ys.min()/rh*100:.0f}%-{ys.max()/rh*100:.0f}%H")
card.save("/home/z/my-project/qa/work-t38/ref-coin-card.png")
