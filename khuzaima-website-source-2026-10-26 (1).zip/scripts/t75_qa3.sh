#!/usr/bin/env bash
# Task 75 — QA battery 3: reduced motion + final sweep
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"

echo "=== 1. reduced motion: static render ==="
$AB open "about:blank" >/dev/null 2>&1
$AB eval "null" >/dev/null 2>&1
$AB set viewport 1792 837 >/dev/null 2>&1
# emulate reduced motion via CDP-free approach: Next.js respects CSS media; use playwright emulation through agent-browser set media
$AB set media reduced-motion >/dev/null 2>&1 || true
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "
(() => {
  const nd = document.getElementById('never-done');
  window.__r = Math.round(nd.getBoundingClientRect().top + scrollY);
  const t = nd.querySelector('.never-done-title');
  return JSON.stringify({matches: matchMedia('(prefers-reduced-motion: reduce)').matches, secH: nd.offsetHeight, titleText: t.textContent});
})()
"
$AB eval "window.scrollTo(0, window.__r)" >/dev/null 2>&1; sleep 1.5
$AB screenshot "$OUT/f10-reduced-motion.png" >/dev/null 2>&1
$AB set media no-preference >/dev/null 2>&1 || true

echo "=== 2. final journey tail (process/privacy/cta) ==="
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 2
$AB eval "window.scrollTo(0, 15300)" >/dev/null 2>&1; sleep 2
$AB screenshot "$OUT/f11-process.png" >/dev/null 2>&1
$AB eval "window.scrollTo(0, 17200)" >/dev/null 2>&1; sleep 2
$AB screenshot "$OUT/f12-finalcta.png" >/dev/null 2>&1
$AB eval "window.scrollTo(0, document.documentElement.scrollHeight)" >/dev/null 2>&1; sleep 2
$AB screenshot "$OUT/f13-footer.png" >/dev/null 2>&1

echo "=== 3. final state ==="
$AB eval "
(() => {
  const nd = document.getElementById('never-done');
  return JSON.stringify({
    docH: document.documentElement.scrollHeight,
    ndHeight: nd.offsetHeight,
    howGone: !document.getElementById('how'),
    chatGone: !document.querySelector('.chatdemo-screen'),
    overflowX: document.documentElement.scrollWidth - innerWidth
  });
})()
"
echo "=== 4. errors ==="
$AB errors 2>/dev/null | head -6
