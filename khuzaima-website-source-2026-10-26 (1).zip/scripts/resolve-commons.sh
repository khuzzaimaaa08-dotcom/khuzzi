#!/usr/bin/env bash
# Resolve thumb URLs via imageinfo API, one request per 40s.
set -u
cd /tmp/pkbrands
UA="BrandGrid/1.0 (asset research)"

resolve() { # $1 = File:Name URL-encoded
  curl -sL --max-time 25 -A "$UA" "https://commons.wikimedia.org/w/api.php?action=query&titles=$1&prop=imageinfo&iiprop=url&format=json&iiurlwidth=900" | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
    for p in d.get('query',{}).get('pages',{}).values():
        ii=p.get('imageinfo',[{}])[0]
        print(p.get('title'),'|',ii.get('thumburl','NONE'))
except Exception:
    print('RATE-LIMITED | NONE')
"
}

resolve "File:Meezan%20Bank%20Limited%20logo%20(2026).svg"
sleep 40
resolve "File:Sapphire%20Logo.png"
sleep 40
resolve "File:Sapphire%20Textile%20Mills%20logo%20(2024).png"
sleep 40
resolve "File:Engro%20Corporation%20logo%20(2025).svg"
sleep 40
resolve "File:Khaadi-2022.jpg"
sleep 40
resolve "File:Khaadi%202018.jpg"
echo RESOLVE-DONE
