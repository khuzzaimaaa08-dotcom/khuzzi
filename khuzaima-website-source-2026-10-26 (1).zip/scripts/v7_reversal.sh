#!/bin/bash
# 1) mobile navbar pill reappears on scroll-up; 2) scroll reversal state test
set -e
cd /home/z/my-project
S="agent-browser --session winter"

# --- navbar pill: mobile, after jump scroll up slightly to reveal ---
$S set viewport 390 844 > /dev/null
$S open "http://localhost:3000/?t=20:25" > /dev/null
$S wait 2400 > /dev/null
$S scroll up 200 > /dev/null
$S wait 900 > /dev/null
$S screenshot scripts/shots/v7/m-2025-navbar.png > /dev/null
$S eval 'JSON.stringify({pillVisible: (document.querySelector("header")?.getBoundingClientRect().y ?? -1) >= 0})' | tail -1
$S set viewport 1920 1080 > /dev/null

# --- reversal: go deep (9:15 pm), scroll UP to ~8:30, compare vs fresh 8:30 ---
probe='(() => {
  const root = document.querySelector("[data-winter]");
  const clock = document.querySelectorAll("[data-hero-ex] span")[1]?.textContent;
  const rib = [...root.children[0].children].map(n => (+n.style.opacity).toFixed(3)).join(",");
  const hb = root.querySelector(".hill-back"); const hf = root.querySelector(".hill-front");
  const cab = root.querySelector(".cabin-box");
  const win = [...cab.querySelectorAll("rect")].find(q => q.getAttribute("fill") === "var(--sun)");
  const pine = (i) => { const n = [...root.querySelectorAll(".pine-lean")][i]?.parentElement; return n ? `${(+n.style.opacity).toFixed(2)}@${(n.style.transform.match(/-?[\d.]+%/)||["?"])[0]}` : "n/a"; };
  return JSON.stringify({clock, rib, hb: (+hb.style.opacity).toFixed(3), hf: (+hf.style.opacity).toFixed(3), cab: (+cab.style.opacity).toFixed(2), win: (+win.style.opacity).toFixed(2), p7: pine(7), p10: pine(10)});
})()'

echo "--- A: fresh load at 8:30 pm ---"
$S open "http://localhost:3000/?t=20:30" > /dev/null
$S wait 2600 > /dev/null
A=$($S eval "$probe" | tail -1)
echo "$A"

echo "--- B: load at 9:15 pm, then scroll UP to 8:30 ---"
$S open "http://localhost:3000/?t=21:15" > /dev/null
$S wait 2600 > /dev/null
# target scroll for 8:30 = offsetTop + (h - vh) * p(20:30); scroll up from 9:15 to it
$S eval '(() => {
  const el = document.getElementById("top");
  const p = (20*60+30 - 540) / (23*60+42 - 540);
  const y = el.offsetTop + (el.offsetHeight - innerHeight) * p;
  window.scrollTo({top: y});
  return "scrolled to " + Math.round(y);
})()' > /dev/null
$S wait 2800 > /dev/null
B=$($S eval "$probe" | tail -1)
echo "$B"
echo "--- fast flick up + back ---"
$S scroll up 900 > /dev/null; $S wait 600 > /dev/null
$S scroll down 900 > /dev/null; $S wait 2200 > /dev/null
C=$($S eval "$probe" | tail -1)
echo "$C"
