/* Standalone spruce silhouette test: renders buildSpruce candidates large on
 * ultramarine so the geometry can be VLM-reviewed before porting into the hero. */
import { writeFileSync } from "node:fs";

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
type Pt = [number, number];
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

type Style = { tiers: number; maxHalf: number; taper: number; caps: number; trunk: boolean };
function buildSpruce(seed: number, style: Style) {
  const rng = mulberry32(8300 + seed * 131);
  const nT = Math.max(3, style.tiers);
  const baseY = 190 + rng() * 12;
  const apexY = 7;
  const uOf = (i: number) => (nT <= 1 ? 1 : i / (nT - 1));
  const P = (x: number, y: number) => `${x.toFixed(1)} ${y.toFixed(1)}`;
  const tip = Array.from({ length: nT }, (_, i) => {
    const u = uOf(i);
    const short = i > 0 && i < nT - 1 && rng() < 0.28 ? 0.6 + rng() * 0.24 : 1;
    const w = style.maxHalf * (1 - 0.86 * u ** style.taper) * (0.82 + rng() * 0.3) * (i === nT - 1 ? 0.55 : short);
    const fl = 0.78 + rng() * 0.34, fr = 0.78 + rng() * 0.34; // strong left/right asymmetry
    const yj = (rng() - 0.5) * 12; // irregular vertical tier spacing
    const y = clamp(lerp(baseY, apexY + 13, u) + yj, apexY + 8, baseY - 6) - lerp(17, 5, u);
    return { y, xl: 50 - w * fl, xr: 50 + w * fr };
  });
  tip[0] = { ...tip[0], y: baseY - 4 };
  const notch = Array.from({ length: nT - 1 }, (_, i) => {
    const up = tip[i + 1];
    const f = 0.3 + rng() * 0.12; // deep notch → pronounced tier steps
    const base = lerp(tip[i].y, up.y, 0.58);
    return {
      y: clamp(base - 2 - rng() * 7, up.y + 0.5, tip[i].y - 2),
      xl: 50 + (up.xl - 50) * f,
      xr: 50 + (up.xr - 50) * f,
    };
  });
  const sweep = (a: Pt, b: Pt, droop: number) =>
    `C${P(lerp(a[0], b[0], 0.28), a[1] - droop * 0.62)} ${P(lerp(a[0], b[0], 0.8), lerp(a[1], b[1], 0.5) - droop * 0.3)} ${P(b[0], b[1])}`;
  const scallop = (a: Pt, b: Pt, s: number) => {
    if (rng() < 0.4) {
      const m: Pt = [lerp(a[0], b[0], 0.52) + s * 2, lerp(a[1], b[1], 0.5) - 2.5 - rng() * 2.5];
      return `Q${P(lerp(a[0], m[0], 0.5) + s * 2.5, lerp(a[1], m[1], 0.5) - 3 - rng() * 2.5)} ${P(m[0], m[1])}L${P(b[0], b[1])}`;
    }
    const m1: Pt = [lerp(a[0], b[0], 0.34) + s * 2, lerp(a[1], b[1], 0.4) - 2.8 - rng() * 2.6];
    const m2: Pt = [lerp(a[0], b[0], 0.7) + s * 1.6, lerp(a[1], b[1], 0.74) - 1.8 - rng() * 2.2];
    const q1: Pt = [lerp(a[0], m1[0], 0.5) + s * 2.8, lerp(a[1], m1[1], 0.5) - 3.2 - rng() * 2.4];
    const q2: Pt = [lerp(m1[0], m2[0], 0.5) + s * 2.2, lerp(m1[1], m2[1], 0.5) - 2.8 - rng() * 2.2];
    return `Q${P(q1[0], q1[1])} ${P(m1[0], m1[1])}Q${P(q2[0], q2[1])} ${P(m2[0], m2[1])}L${P(b[0], b[1])}`;
  };
  const apex: Pt = [50 + (rng() - 0.5) * 4, apexY];
  const droopOf = (i: number) => lerp(19, 6, uOf(i)) * (0.85 + rng() * 0.3);
  const side = (s: 1 | -1) => {
    const X = (i: number) => (s > 0 ? tip[i].xr : tip[i].xl);
    const N = (i: number) => (s > 0 ? notch[i].xr : notch[i].xl);
    let d = "";
    if (s > 0) {
      d += sweep([50 + style.maxHalf * 0.16, baseY], [X(0), tip[0].y], droopOf(0));
      for (let i = 0; i < nT - 1; i++) {
        d += scallop([X(i), tip[i].y], [N(i), notch[i].y], s);
        d += sweep([N(i), notch[i].y], [X(i + 1), tip[i + 1].y], droopOf(i + 1));
      }
      d += `L${P(apex[0], apex[1])}`;
    } else {
      d += sweep(apex, [X(nT - 1), tip[nT - 1].y], droopOf(nT - 1) * 0.7);
      for (let i = nT - 1; i > 0; i--) {
        d += scallop([X(i), tip[i].y], [N(i - 1), notch[i - 1].y], s);
        d += sweep([N(i - 1), notch[i - 1].y], [X(i - 1), tip[i - 1].y], droopOf(i - 1));
      }
      d += `L${P(50 - style.maxHalf * 0.16, baseY)}`;
    }
    return d;
  };
  const crown = `M${P(50 + style.maxHalf * 0.16, baseY)}${side(1)}${side(-1)}Z`;
  const cap = (s: 1 | -1, i: number) => {
    if (i < 1 || i > nT - 1) return "";
    const bx = s > 0 ? tip[i].xr : tip[i].xl;
    const a: Pt = [50 + (bx - 50) * (0.3 + 0.12), notch[i - 1].y];
    const b: Pt = [bx, tip[i].y];
    const lift = 3.5 + rng() * 3;
    return `M${P(a[0], a[1])}${sweep(a, b, lerp(19, 6, uOf(i)))}` +
      `C${P(lerp(b[0], a[0], 0.3), b[1] - lift - 1.5)} ${P(lerp(b[0], a[0], 0.7), lerp(b[1], a[1], 0.5) - lift)} ${P(a[0], a[1] - lift * 0.5)}Z`;
  };
  const caps: string[] = [];
  if (style.caps > 0) caps.push(cap(1, nT - 1), cap(-1, nT - 1));
  if (style.caps > 1 && nT >= 4) caps.push(cap(rng() > 0.5 ? 1 : -1, nT - 3));
  return { crown, caps: caps.filter(Boolean), trunk: style.trunk };
}

const cases: { seed: number; style: Style; w: number; note: string }[] = [
  { seed: 0, style: { tiers: 6, maxHalf: 42, taper: 1.1, caps: 2, trunk: true }, w: 260, note: "near A" },
  { seed: 1, style: { tiers: 7, maxHalf: 38, taper: 0.9, caps: 2, trunk: true }, w: 260, note: "near B (slim)" },
  { seed: 2, style: { tiers: 5, maxHalf: 46, taper: 1.25, caps: 2, trunk: true }, w: 260, note: "near C (broad)" },
  { seed: 3, style: { tiers: 5, maxHalf: 34, taper: 1.0, caps: 1, trunk: true }, w: 170, note: "mid A" },
  { seed: 4, style: { tiers: 6, maxHalf: 30, taper: 0.85, caps: 1, trunk: false }, w: 170, note: "mid B" },
  { seed: 5, style: { tiers: 4, maxHalf: 30, taper: 1.1, caps: 0, trunk: false }, w: 110, note: "far A" },
  { seed: 6, style: { tiers: 3, maxHalf: 34, taper: 1.2, caps: 0, trunk: false }, w: 110, note: "far B" },
  { seed: 7, style: { tiers: 5, maxHalf: 26, taper: 0.95, caps: 0, trunk: false }, w: 110, note: "far C" },
];

const tree = (c: { seed: number; style: Style; w: number; note: string }) => {
  const art = buildSpruce(c.seed, c.style);
  const h = c.w * 2.4;
  return `<div style="text-align:center">
    <svg width="${c.w}" height="${h}" viewBox="0 0 100 240">
      ${art.trunk ? `<path d="M46.6 198h6.8v28h-6.8Z" fill="#1d1650" fill-opacity="0.9"/>` : ""}
      <path d="${art.crown}" fill="#12233a" fill-opacity="0.95"/>
      ${art.caps.map((d) => `<path d="${d}" fill="#eef0ff" fill-opacity="0.85"/>`).join("")}
    </svg>
    <div style="color:#aab;font:11px monospace">${c.note}</div>
  </div>`;
};

const html = `<!doctype html><html><head><style>body{background:#3b2f8f;margin:0;padding:24px;display:flex;flex-wrap:wrap;gap:28px;align-items:flex-end}</style></head>
<body>${cases.map(tree).join("")}</body></html>`;
writeFileSync("/home/z/my-project/scripts/shots/spruces.html", html);
console.log("written");
