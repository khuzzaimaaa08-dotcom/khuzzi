#!/usr/bin/env python3
"""Task 40 — remove the 2 case-study cards after the "Our work." heading.

globals.css surgery:
  1. Delete lines 351-930 inclusive (the whole card system: static stack,
     card frames, NBCU/Coin skins, pinned horizontal mode, phone mockups,
     showreel tile). Kept: .our-work section padding, .our-work
     .container-site, .our-work-heading (lines 291-349) + theme comment
     from 931 on.
  2. Rewrite the section comment block to describe the heading-only divider.
  3. Reword the padding-bottom comment ("below the card" -> "below the heading").

Idempotence: abort if the card markers are already gone.
"""

from pathlib import Path

CSS = Path("/home/z/my-project/src/app/globals.css")
text = CSS.read_text()
lines = text.split("\n")

# ── sanity: verify the expected block boundaries before cutting ──────────
assert lines[350].startswith("/* ── Case-study cards"), f"line 351 unexpected: {lines[350]!r}"
assert lines[927] == "}", f"line 928 unexpected: {lines[927]!r}"
assert lines[928] == "" and lines[929] == "", "lines 929-930 should be blank"
assert lines[930].startswith("/* Scroll-driven light-to-dark theme"), f"line 931 unexpected: {lines[930]!r}"

# ── 1. delete the card system: lines 351-930 (1-indexed) ─────────────────
#      keeps line 350 (blank separator) directly before the theme comment.
del lines[350:930]

# ── 2. replace the section comment block ─────────────────────────────────
old_comment = """/* "Our work." — the giant statement heading plus the single NBCU
   case-study card it introduces (OurWork.tsx, Task 38 rebuild).

   The heading keeps the reference's exact desktop metrics — matter
   136.576px / 600 / 122.918px line / -6.8288px tracking — and its role as
   the scroll-scrubbed theme boundary (ThemeTransition.tsx keys off
   #our-work-title's position: the canvas is fully #0D0B0A by the time the
   card arrives). The section is a plain flowing block — no track, no pin,
   no carousel — so every spacing rule below is ordinary flow layout:
   nav-aware arrival padding, a vh-proportioned heading→card gap, the
   94vw / 3.59:1 card, and a generous exit ramp into ChatDemo.

   Card geometry is pixel-measured off the reference (card 1778×495):
   title cap at 26.5% of card height, left edge at 2.9% of card width,
   title and description both 4.67cqw at 0.9 line-height and -0.05em
   tracking, description wrapping to three lines and ending ~91% of card
   height, showreel tile flush right spanning 26.7cqw × 60cqh from
   33.5cqh. Tablet and mobile adapt the composition instead of forcing it:
   tablet pairs the artwork with a text column inside a 1.9:1 frame,
   mobile stacks them. */"""

new_comment = """/* "Our work." — the giant statement heading, alone (OurWork.tsx, Task 40).

   The case-study cards and the horizontal gallery are gone: the section
   is a pure dark divider — the oversized heading on the #0D0B0A canvas,
   nav-aware arrival padding above it, and a generous exit ramp into the
   ChatDemo section below.

   The heading keeps the reference's exact desktop metrics — matter
   136.576px / 600 / 122.918px line / -6.8288px tracking — and its role as
   the scroll-scrubbed theme boundary (ThemeTransition.tsx keys off
   #our-work-title's position: the canvas is fully #0D0B0A once the
   heading settles). */"""

text = "\n".join(lines)
assert old_comment in text, "section comment block not found verbatim"
text = text.replace(old_comment, new_comment, 1)

# ── 3. reword the padding-bottom comment ─────────────────────────────────
old_pb = "  /* Air below the card before ChatDemo arrives (reference: 120–140px). */"
new_pb = "  /* Air below the heading before ChatDemo arrives. */"
assert old_pb in text, "padding-bottom comment not found"
text = text.replace(old_pb, new_pb, 1)

CSS.write_text(text)

# ── report ────────────────────────────────────────────────────────────────
out = CSS.read_text()
for marker in (
    ".work-card", ".work-track", ".work-stage", ".work-viewport",
    ".work-scroll", ".work-item", ".skin-nbcu", ".skin-coin",
    ".showreel", ".wph", ".art-nbcu", ".art-coin", "--card-w", "--work-gap",
):
    if marker in out:
        raise SystemExit(f"FAIL: {marker!r} still present in globals.css")
print("globals.css: card system removed; heading rules preserved.")
print(f"new length: {len(out.splitlines())} lines (was {len(lines) + 580})")
print("kept:", ".our-work", ".our-work .container-site", ".our-work-heading")
