#!/usr/bin/env python3
"""Refined line-structure analysis of the reference image."""
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792417586109.png").convert("RGB")
W, H = img.size
px = img.load()

def is_dark(p): r, g, b = p; return r < 90 and g < 90 and b < 90
def is_pink(p): r, g, b = p; return r > 180 and g < 130 and 90 < b < 220 and (r - g) > 80

# Per-row counts below the black bar (bar = rows 0..49)
print("row-band analysis (rows 50..703):")
counts = []
for y in range(50, H):
    d = sum(1 for x in range(W) if is_dark(px[x, y]))
    p = sum(1 for x in range(W) if is_pink(px[x, y]))
    counts.append((y, d, p))

# Find bands where any text signal exists (dark>=5 or pink>=5)
bands = []
cur = None
for y, d, p in counts:
    active = d >= 5 or p >= 5
    if active and cur is None:
        cur = [y, y, 0, 0]
    elif active:
        cur[1] = y
    elif cur is not None:
        bands.append(cur); cur = None
if cur: bands.append(cur)

# merge bands separated by < 12 rows
merged = []
for b in bands:
    if merged and b[0] - merged[-1][1] < 12:
        merged[-1][1] = b[1]
    else:
        merged.append(b)

for i, (y0, y1, _, _) in enumerate(merged):
    # dark x-extent and pink x-extent within band
    dxs = [x for y in range(y0, y1 + 1) for x in range(W) if is_dark(px[x, y])]
    pxs = [x for y in range(y0, y1 + 1) for x in range(W) if is_pink(px[x, y])]
    h = y1 - y0 + 1
    dinfo = f"dark x [{min(dxs)},{max(dxs)}]" if dxs else "no dark"
    pinfo = f"pink x [{min(pxs)},{max(pxs)}]" if pxs else "no pink"
    print(f"  band {i+1}: y {y0}-{y1} (h={h})  {dinfo}  {pinfo}")

# Check for dark pixels in the pink band to the LEFT of pink start (same line has black text?)
print("\npink band left-side dark check:")
if merged:
    # use the band containing pink (y 418-599)
    y0, y1 = 418, 599
    dxs = [x for y in range(y0, y1 + 1) for x in range(W) if is_dark(px[x, y])]
    if dxs:
        print(f"  dark in pink band: x [{min(dxs)},{max(dxs)}], count={len(dxs)}")
        print(f"  pink starts at x=886 -> black text {'PRECEDES pink on same line' if min(dxs) < 886 else 'does not precede'}")
    else:
        print("  no dark pixels in pink band -> pink word is ALONE on its line")
