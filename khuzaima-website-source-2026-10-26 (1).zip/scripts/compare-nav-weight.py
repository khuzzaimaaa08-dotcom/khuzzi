#!/usr/bin/env python3
"""Crop ours vs reference nav text, normalize, measure stroke weight objectively.

Compares the nav column of our live site (after fix) against the user's
reference screenshot (Huge site). Both contain the same six labels; we crop
each image's text block, scale the reference to the same text height as ours,
then measure per-image: ink coverage (dark pixel ratio inside the text bbox)
and the modal horizontal stroke run-length — both normalized by cap height so
they're directly comparable despite size differences. Finally emits a
side-by-side composite for eyeballing.
"""
from PIL import Image
import numpy as np
from collections import Counter

OURS = "/home/z/my-project/qa/after-nav.png"
REF = "/home/z/my-project/upload/pasted_image_1792477162472.png"

# --- crop ours: nav coords from browser (x1273 y462 w279 h222 @1920x1080), pad a little
ours = Image.open(OURS).convert("L")
ours_crop = ours.crop((1268, 455, 1268 + 295, 455 + 240))

# --- crop reference: locate its text block automatically
ref = Image.open(REF).convert("L")
arr = np.array(ref)
dark = arr < 128
rows = np.where(dark.any(axis=1))[0]
cols = np.where(dark.any(axis=0))[0]
ref_crop = ref.crop((cols.min(), rows.min(), cols.max() + 1, rows.max() + 1))

def ink_stats(img: Image):
    a = np.array(img)
    d = a < 128
    total = d.size
    ink = int(d.sum())
    # cap height ≈ tallest dark column extent (rows of the text block)
    row_ext = np.where(d.any(axis=1))[0]
    cap = (row_ext.max() - row_ext.min() + 1) if len(row_ext) else 1
    # modal horizontal run length of dark pixels (stroke width estimate)
    runs = []
    for line in d:
        c = 0
        for v in line:
            if v:
                c += 1
            elif c:
                runs.append(c)
                c = 0
        if c:
            runs.append(c)
    # keep runs 2..25 px (avoid 1px antialias noise and letter gaps)
    runs = [r for r in runs if 2 <= r <= 30]
    modal = Counter(runs).most_common(3) if runs else []
    return {
        "size": img.size,
        "ink_ratio": round(ink / total, 4),
        "cap_px": int(cap),
        "ink_ratio_per_cap": round((ink / total) * cap, 3),
        "modal_stroke_px": modal,
    }

so = ink_stats(ours_crop)
sr = ink_stats(ref_crop)
print("OURS :", so)
print("REF  :", sr)

# --- normalize reference to our cap height, re-measure stroke in same scale
scale = so["cap_px"] / sr["cap_px"]
ref_scaled = ref_crop.resize(
    (int(ref_crop.width * scale), int(ref_crop.height * scale)), Image.LANCZOS
)
ss = ink_stats(ref_scaled)
print("REF@ours-scale:", {k: ss[k] for k in ("size", "ink_ratio_per_cap", "modal_stroke_px")})

# --- side-by-side composite (white gutter)
pad = 40
h = max(ours_crop.height, ref_scaled.height)
comp = Image.new("L", (ours_crop.width + ref_scaled.width + pad * 3, h + pad * 2), 255)
comp.paste(ours_crop, (pad, pad))
comp.paste(ref_scaled, (pad * 2 + ours_crop.width, pad))
comp.convert("RGB").save("/home/z/my-project/qa/compare-nav.png")
print("saved /home/z/my-project/qa/compare-nav.png  (left=ours, right=reference)")
