#!/usr/bin/env python3
"""Pass 3: ASCII structure maps of the reference card regions."""
from PIL import Image
import numpy as np

im = Image.open("/home/z/my-project/upload/pasted_image_1792667125776.png").convert("RGB")
a = np.asarray(im).astype(int)
CX0, CY0, CW, CH = 56, 63, 1778, 495

def ascii_map(x0, x1, y0, y1, cell=12, label=""):
    print(f"=== {label} x{x0}-{x1} y{y0}-{y1} cell={cell} ===")
    hdr = "     " + "".join(str((x0 + i * cell) // 100 % 10) for i in range((x1 - x0) // cell))
    print(hdr)
    for yy in range(y0, y1, cell):
        row = ""
        for xx in range(x0, x1, cell):
            c = a[yy, xx]
            r, g, b = c
            if r > 225 and g > 235 and b > 240: ch = "W"  # white
            elif r > 160 and g < 150 and b > 100 and b < 220: ch = "P"  # pink
            elif r < 60 and g < 60 and b < 75: ch = "#"  # black/dark
            elif b > 110 and b > r + 25: ch = "." if (r + g) // 2 > 120 else " "  # blue light/dark
            elif r > 140 and b > 200: ch = "t"  # pale text
            else: ch = "-"
            row += ch
        print(f"{yy:4d} {row}")

# bottom-right: showreel zone
ascii_map(950, 1840, 290, 560, 12, "BOTTOM-RIGHT (showreel + back phone)")
# phones zone
ascii_map(500, 1350, 60, 560, 16, "PHONES ZONE")
# description zone
ascii_map(60, 900, 180, 560, 12, "TEXT ZONE (title + description)")
