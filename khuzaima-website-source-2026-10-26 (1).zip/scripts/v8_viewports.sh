#!/bin/bash
# v8 viewport checks at 21:00 (peak scene)
set -e
cd /home/z/my-project
S="agent-browser --session winter"
for vp in "1440 900" "1366 768" "1280 720" "390 844"; do
  set -- $vp
  $S set viewport $1 $2 > /dev/null 2>&1
  $S open "http://localhost:3000/?t=21:00" > /dev/null 2>&1
  $S wait 2800 > /dev/null 2>&1
  file="scripts/shots/v8/vp-$1x$2.png"
  $S screenshot "$file" > /dev/null 2>&1
  state=$($S eval "JSON.stringify({fx: window.__winterFx ? {a: +__winterFx.state.aurora.toFixed(2), s: +__winterFx.state.snow.toFixed(2), run: __winterFx.isRunning()} : 'X', hscroll: document.documentElement.scrollWidth > document.documentElement.clientWidth, canvases: document.querySelectorAll('[data-winter] canvas').length, auroraW: document.querySelector('.aurora-box canvas').width, navbar: !!document.querySelector('nav, header')})" 2>/dev/null | tail -1)
  echo "$1x$2 -> $state"
done
$S set viewport 1920 1080 > /dev/null 2>&1
