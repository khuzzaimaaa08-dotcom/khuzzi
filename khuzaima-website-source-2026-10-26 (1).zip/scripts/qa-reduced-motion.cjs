/* eslint-disable @typescript-eslint/no-require-imports */
/* Reduced-motion verification: launch Chromium with prefers-reduced-motion: reduce
   and assert the Manifesto section renders fully visible, static, flat, in flow. */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    reducedMotion: "reduce",
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("http://localhost:3000/", { waitUntil: "networkidle" });
  await page.waitForTimeout(1500);

  const state = await page.evaluate(() => {
    const m = document.querySelector("#manifesto");
    const hero = document.querySelector("#top");
    const cs = getComputedStyle(m);
    return {
      matchReduced: matchMedia("(prefers-reduced-motion: reduce)").matches,
      mt: cs.marginTop,
      mb: cs.marginBottom,
      radius: cs.borderRadius,
      position: cs.position,
      zIndex: cs.zIndex,
      heroH: hero.offsetHeight,
      flush: Math.abs(m.getBoundingClientRect().top - (hero.getBoundingClientRect().top + hero.offsetHeight)) < 1,
      lines: [...m.querySelectorAll(".reveal-line > span")].map((s) => getComputedStyle(s).transform),
      text: m.querySelector("h2").textContent,
      sw: document.documentElement.scrollWidth,
      vw: innerWidth,
    };
  });

  // Scroll through the whole page to ensure nothing breaks with reduced motion
  await page.evaluate(async () => {
    for (let y = 0; y <= document.documentElement.scrollHeight; y += 600) {
      window.scrollTo(0, y);
      await new Promise((r) => setTimeout(r, 40));
    }
  });
  await page.waitForTimeout(600);
  const postErrors = await page.evaluate(() => ({
    heroClock: document.querySelector("#top span")?.textContent,
    chatdemoH2: document.querySelector("#how h2")?.textContent?.slice(0, 30),
  }));
  await page.screenshot({ path: "/home/z/my-project/scripts/qa-manifesto-reduced.png" });

  console.log(JSON.stringify({ state, postErrors, pageErrors: errors }, null, 2));
  await browser.close();
})();
