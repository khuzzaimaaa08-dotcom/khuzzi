#!/usr/bin/env python3
"""Precise re-measurement of the navbar reference screenshot (1904x136 crop).

Goals:
1. Find the bar's true bottom edge (rows where uniform near-black ends and
   hero content begins) -> real bar height within the crop.
2. Dense horizontal luminance/chroma profile of the glow at several rows.
3. Pink wordmark bounding box + x-offset; white link pixel runs; CTA pill box.
4. Base background color (median of darkest rows at far left/right).
"""
from PIL import Image
import numpy as np

im = Image.open("/home/z/my-project/qa/ref-navbar-1.png").convert("RGB")
a = np.asarray(im).astype(int)
H, W, _ = a.shape
print(f"image {W}x{H}")

# --- 1. per-row stats: how "black and uniform" is each row? ---
# left margin (0..40px) and right margin (W-40..W) medians per row
rows = []
for y in range(H):
    left = a[y, 0:40]
    right = a[y, W-40:W]
    lr = np.median(left, axis=0)
    rr = np.median(right, axis=0)
    rows.append((y, lr, rr))

print("\nrow | left-median RGB | right-median RGB")
for y in range(0, H, 4):
    _, lr, rr = rows[y]
    print(f"{y:3d} | {tuple(int(v) for v in lr)} | {tuple(int(v) for v in rr)}")
print("last rows:")
for y in range(H-6, H):
    _, lr, rr = rows[y]
    print(f"{y:3d} | {tuple(int(v) for v in lr)} | {tuple(int(v) for v in rr)}")

# --- 2. glow horizontal profile (max over R channel minus base) ---
def profile(y):
    row = a[y]
    # chroma-ish: R channel (glow is pink: high R, mid G, low B)
    return (row[:, 0] - (row[:, 2] * 0.5)).astype(int)  # R dominance

print("\nGlow profile (R-dominance) every 32px at several rows:")
for y in [10, 30, 68, 100, 126]:
    p = profile(y)
    print(f"y={y:3d}: ", " ".join(f"{int(p[x]):3d}" for x in range(0, W, 128)))

# dense: find peaks/saddle
mid = profile(H // 2)
print("\nDense samples y=center every 40px:")
print(" ".join(f"{mid[x]:3d}" for x in range(0, W, 40)))

# --- 3. wordmark: pink pixels (R>180, G<120, B<160) ---
r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
pink = (r > 180) & (g < 120) & (b < 180)
ys, xs = np.where(pink)
if len(xs):
    print(f"\nPINK pixels: x {xs.min()}..{xs.max()}  y {ys.min()}..{ys.max()}  count={len(xs)}")
else:
    print("\nno pink pixels found?!")

# --- white-ish pixels (links + CTA): ---
white = (r > 200) & (g > 200) & (b > 200)
# column histogram of white pixels
colw = white.sum(axis=0)
# find runs of columns with white content
runs = []
in_run = False
for x in range(W):
    if colw[x] > 0 and not in_run:
        start = x; in_run = True
    elif colw[x] == 0 and in_run:
        runs.append((start, x - 1)); in_run = False
if in_run:
    runs.append((start, W - 1))
print("\nWhite-content column runs (x0..x1, width):")
for s, e in runs:
    if e - s >= 1:
        print(f"  {s}..{e}  w={e-s+1}")

# CTA: largest white run in right third; check its y-extent
if runs:
    cta = max((rn for rn in runs if rn[0] > W * 0.7), key=lambda rn: rn[1] - rn[0], default=None)
    if cta:
        s, e = cta
        mask = white[:, s:e + 1]
        ys2 = np.where(mask.any(axis=1))[0]
        print(f"\nCTA candidate: x {s}..{e} (w={e-s+1})  y {ys2.min()}..{ys2.max()} (h={ys2.max()-ys2.min()+1})")

# --- 4. base bg: median color of corners ---
tl = a[0:8, 0:8].reshape(-1, 3)
bl = a[H-8:H, 0:40].reshape(-1, 3)
print("\nbase bg top-left:", tuple(int(v) for v in np.median(tl, axis=0)))
print("base bg bottom-left:", tuple(int(v) for v in np.median(bl, axis=0)))
