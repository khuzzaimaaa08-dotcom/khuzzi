#!/bin/bash
# DOM-level verification of exact clock states
set -e
cd /home/z/my-project
S="agent-browser --session winter"

probe='(() => {
  const root = document.querySelector("[data-winter]");
  const clock = document.querySelectorAll("[data-hero-ex] span")[1]?.textContent;
  const ap = document.querySelectorAll("[data-hero-ex] span")[2]?.textContent;
  const ribbons = [...root.children[0].children].map(n => (+n.style.opacity).toFixed(3));
  const hill = (sel) => { const n = root.querySelector(sel); return n ? `${(+n.style.opacity).toFixed(3)}@${n.style.transform.replace(/[^0-9.%-]/g,"").slice(0,14)}` : "n/a"; };
  const pine = (i) => { const n = [...root.querySelectorAll(".pine-lean")][i]?.parentElement; return n ? `${(+n.style.opacity).toFixed(2)}@${(n.style.transform.match(/-?[\d.]+%/)||["?"])[0]}` : "n/a"; };
  const cab = root.querySelector(".cabin-box");
  const win = [...root.querySelectorAll(".cabin-box rect")].find(r => r.getAttribute("fill") === "var(--sun)");
  return JSON.stringify({
    clock: clock + ap, winter: root.dataset.winter,
    ribbons: ribbons.join(","),
    hillBack: hill(".hill-back"), hillFront: hill(".hill-front"),
    pineFar0: pine(0), pineMid3: pine(4), pineNear0: pine(7),
    cabin: cab ? `${(+cab.style.opacity).toFixed(2)}@${(cab.style.transform.match(/-?[\d.]+%/)||["?"])[0]}` : "n/a",
    window: win ? (+win.style.opacity).toFixed(2) : "n/a"
  });
})()'

for t in 19:57 20:00 20:25 21:20 21:30; do
  $S open "http://localhost:3000/?t=${t}" > /dev/null
  $S wait 2600 > /dev/null
  echo -n "$t  "
  $S eval "$probe" | tail -1
done
