#!/usr/bin/env python3
"""Round 2: isolate wordmark vs glow, measure text cap heights, calibrate scale."""
from PIL import Image
import numpy as np

img = Image.open("/home/z/my-project/upload/pasted_image_1792513631375.png").convert("RGB")
a = np.array(img).astype(np.int32)
H, W = a.shape[:2]
r, g, b = a[:,:,0], a[:,:,1], a[:,:,2]

pink = (r > 150) & (g < 120) & (b > 60) & (b < 200)
white = (r > 225) & (g > 225) & (b > 225)

# --- wordmark: pink confined to left zone (glow starts ~x480) ---
wm = pink.copy(); wm[:, 300:] = False
ys, xs = np.where(wm)
print(f"WORDMARK (x<300): {len(xs)}px bbox x[{xs.min()},{xs.max()}] y[{ys.min()},{ys.max()}]  -> ink h={ys.max()-ys.min()+1} w={xs.max()-xs.min()+1}")
# column ink profile (letter gaps)
cols = wm.sum(axis=0)
gaps, run, start = [], [], None
for x in range(300):
    if cols[x] > 0: 
        if start is None: start = x
        run.append(x)
    else:
        if start is not None: gaps.append((start, x-1)); start=None
if start is not None: gaps.append((start, 299))
print("  letter runs:", [(s,e) for s,e in gaps if e-s>2])

# --- glow: pink/magenta zone x 480-1400 ---
gz = pink.copy(); gz[:, :480] = False; gz[:, 1400:] = False
ys2, xs2 = np.where(gz)
print(f"GLOW: bbox x[{xs2.min()},{xs2.max()}] y[{ys2.min()},{ys2.max()}]")
# glow intensity profile horizontally at several rows
for y in [20, 50, 68, 90, 120]:
    prof = [f"{a[y,x][0]},{a[y,x][1]},{a[y,x][2]}" for x in range(480, 1401, 115)]
    print(f"  y={y:3d}: " + " | ".join(prof))

# --- Work cluster vertical extent (white, x 492-546) ---
cl = white[:, 492:547]
ys3 = np.where(cl.any(axis=1))[0]
print(f"\n'Work' white ink: y[{ys3.min()},{ys3.max()}] cap-height={ys3.max()-ys3.min()+1}px")

# clusters 2-6 vertical extents
for (s,e),name in [((619,709),'Solutions'),((781,870),'Approach'),((954,1055),'Company'),((1131,1180),'Ideas'),((1250,1331),'Careers')]:
    c = white[:, s:e+1]
    yy = np.where(c.any(axis=1))[0]
    print(f"'{name}': y[{yy.min()},{yy.max()}] h={yy.max()-yy.min()+1}")

# --- button: white pill x[1660,1833] y[33,98]; inner dark text ---
btn = a[33:99, 1660:1834]
br, bg_, bb = btn[:,:,0], btn[:,:,1], btn[:,:,2]
whitepill = (br > 225) & (bg_ > 225) & (bb > 225)
darktext = (br < 120) & (bg_ < 120) & (bb < 120) & ~whitepill
ys4, xs4 = np.where(darktext)
print(f"\nBUTTON text: bbox x[{xs4.min()},{xs4.max()}] y[{ys4.min()},{ys4.max()}] ink h={ys4.max()-ys4.min()+1} (rel to pill)")

# pill tight bbox
ys5, xs5 = np.where(whitepill)
print(f"BUTTON pill: x[{xs5.min()},{xs5.max()}] y[{ys5.min()},{ys5.max()}] w={xs5.max()-xs5.min()+1} h={ys5.max()-ys5.min()+1}")

# wordmark color at densest point
if len(xs):
    from collections import Counter
    dense_x = Counter(xs).most_common(1)[0][0]
    col_px = a[wm[:, dense_x], dense_x]
    print(f"\nwordmark color at densest column x={dense_x}: rgb({col_px[:,0].mean():.0f},{col_px[:,1].mean():.0f},{col_px[:,2].mean():.0f})")

# background just left/right of glow
print(f"\nbg x=400 y=68: {a[68,400]}   x=1500 y=68: {a[68,1500]}   corners: {a[5,5]} {a[130,5]}")
