#!/usr/bin/env bash
# Patient Commons fetcher: one request per 45s to avoid 429s.
set -u
cd /tmp/pkbrands
UA="BrandGrid/1.0 (one-time asset fetch)"

fetch() { # $1 = File:Name (URL-encoded), $2 = output
  curl -sL --max-time 30 -A "$UA" "https://commons.wikimedia.org/wiki/Special:FilePath/$1" -o "$2"
  if file "$2" | grep -qiE "HTML|ASCII text"; then
    echo "FAIL(html) $2"; rm -f "$2"; return 1
  else
    echo "OK $2 ($(stat -c%s "$2") bytes)"; return 0
  fi
}

search() { # $1 = query
  curl -sL --max-time 20 -A "$UA" "https://commons.wikimedia.org/w/api.php?action=query&list=search&srsearch=$1&srnamespace=6&format=json&srlimit=8" | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
    hits=[r['title'] for r in d.get('query',{}).get('search',[])]
    print('SEARCH ' + '$1' + ' -> ' + ('; '.join(hits) if hits else 'EMPTY'))
except Exception:
    print('SEARCH ' + '$1' + ' -> RATE-LIMITED')
"
}

sleep 45
search "khaadi"
sleep 45
search "Jazz Pakistan logo"
sleep 45
fetch "Meezan%20Bank%20Limited%20logo%20(2026).svg" meezan-commons.svg
sleep 45
fetch "Sapphire%20Logo.png" sapphire-commons.png
sleep 45
fetch "Sapphire%20Textile%20Mills%20logo%20(2024).png" sapphire-textile.png
sleep 45
fetch "Engro%20Corporation%20logo%20(2025).svg" engro-commons.svg
sleep 45
fetch "Shan-Logo-PNG.png" shan-commons.png
echo "BATCH-DONE"
