#!/usr/bin/env python3
"""Task 42 pass 6 — final precision pass: glyph interiors, line bands,
pill bounds (tight), phone bboxes (light UI vs dark UI)."""
import json
from collections import Counter
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()
CARD = (25, 64, 1805, 558)
cl, ct, cr, cb = CARD
cw, ch = cr - cl, cb - ct
TILE = (1332, 232, 1806, 528)

# ── 1. per-row pale-blue counts in text zone, EVERY row, y 200..480 ──────
print("ROW  count   (pale-blue, x 60..850)")
for y in range(ct + 195, ct + 480):
    n = 0
    for x in range(cl + 35, cl + 825):
        r, g, b = px[x, y]
        if b > 195 and 130 < r < 235 and 150 < g < 245 and b - r > 28 and b - g > 10:
            n += 1
    if n > 12:
        print(f"{y-ct:4d}  {n:5d}  {'#' * min(60, n // 8)}")

# ── 2. glyph interior color: largest pale-blue blob rows of L1 ───────────
# find the row with max count, then sample the longest horizontal run
def longest_run(y):
    best = (0, 0); run = 0; start = 0
    for x in range(cl + 35, cl + 825):
        r, g, b = px[x, y]
        ok = b > 195 and 130 < r < 235 and 150 < g < 245 and b - r > 28 and b - g > 10
        if ok:
            if run == 0: start = x
            run += 1
            if run > best[0]: best = (run, start)
        else:
            run = 0
    return best

print("\nL1 longest runs (row, len, start_x, mid_colors):")
for y in range(ct + 250, ct + 290, 4):
    ln, st = longest_run(y)
    if ln > 8:
        mids = [px[st + ln // 2 + d, y] for d in (-3, 0, 3)]
        print(f"  y={y-ct} len={ln} start={st-cl} colors={mids}")

# ── 3. pill bounds: tight scan for plum-ish translucent over black ───────
tx0, ty0, tx1, ty1 = TILE
tw, th = tx1 - tx0, ty1 - ty0
def pillish(x, y):
    r, g, b = px[x, y]
    # plum/mauve translucent: r 90-190, g 70-160, b 90-190, r>=g, not white, not pink
    return 85 < r < 200 and 65 < g < 170 and 85 < b < 200 and r >= g - 5 and not (r > 225 and g > 230) and (r - g < 60)
rows = {}
for y in range(ty0 + 20, ty1 - 20):
    n = sum(1 for x in range(tx0 + 10, tx1 - 10) if pillish(x, y))
    if n > 60:
        rows[y] = n
if rows:
    ys = sorted(rows)
    a, b = ys[0], ys[-1]
    xs = [x for y in range(a, b + 1) for x in range(tx0 + 10, tx1 - 10) if pillish(x, y)]
    print(f"\nPILL tight: y {a-ty0}..{b-ty0} (h={(b-a+1)}/{th} = {round((b-a+1)/th*100,1)}%)  "
          f"x {min(xs)-tx0}..{max(xs)-tx0} (w={max(xs)-min(xs)}/{tw} = {round((max(xs)-min(xs))/tw*100,1)}%)")
    cx = (min(xs) + max(xs)) // 2
    print(f"  pill center offset from tile center: x={cx - (tx0+tx1)//2}, y={(a+b)//2 - (ty0+ty1)//2}")
    print("  pill surface samples:", [px[cx - 100, (a+b)//2], px[cx, (a+b)//2], px[cx + 100, (a+b)//2]])

# ── 4. phone bboxes ───────────────────────────────────────────────────────
# back phone: bright/light pixels (white-ish UI), x > 50% cardW, excluding tile x-range? back phone is LEFT of tile
light_cols = {}
for x in range(cl + int(cw * 0.45), tx0):
    n = 0
    for y in range(ct, cb):
        r, g, b = px[x, y]
        if r > 215 and g > 222 and b > 228:
            n += 1
    if n > 15:
        light_cols[x] = n
# front phone: near-black columns, x > 50% cardW, EXCLUDING the tile region
dark_cols = {}
for x in range(cl + int(cw * 0.45), cr):
    if tx0 - 8 <= x <= tx1 + 8:
        continue
    n = 0
    for y in range(ct, cb):
        r, g, b = px[x, y]
        if r < 42 and g < 42 and b < 42:
            n += 1
    if n > 15:
        dark_cols[x] = n

def bbox_of(cols):
    if not cols:
        return None
    xs = sorted(cols)
    groups = []
    s = p = xs[0]
    for x in xs[1:]:
        if x - p > 30:
            groups.append((s, p)); s = x
        p = x
    groups.append((s, p))
    return groups

lg = bbox_of(light_cols)
dg = bbox_of(dark_cols)
print("\nLIGHT (back phone) col groups:", lg)
print("DARK (front phone, excl tile) col groups:", dg)
if lg:
    for (a2, b2) in lg:
        if b2 - a2 < 60: continue
        ys = [y for y in range(ct, cb) if any(
            px[x, y][0] > 215 and px[x, y][1] > 222 and px[x, y][2] > 228
            for x in range(a2, b2, 4))]
        if ys:
            print(f"  light group x {a2-cl}..{b2-cl} in-card%: {round((a2-cl)/cw*100,1)}-{round((b2-cl)/cw*100,1)}"
                  f"  y {min(ys)-ct}..{max(ys)-ct} in-card%: {round((min(ys)-ct)/ch*100,1)}-{round((max(ys)-ct)/ch*100,1)}")
if dg:
    for (a2, b2) in dg:
        if b2 - a2 < 60: continue
        ys = [y for y in range(ct, cb) if any(
            all(v < 42 for v in px[x, y]) for x in range(a2, b2, 4))]
        if ys:
            print(f"  dark group x {a2-cl}..{b2-cl} in-card%: {round((a2-cl)/cw*100,1)}-{round((b2-cl)/cw*100,1)}"
                  f"  y {min(ys)-ct}..{max(ys)-ct} in-card%: {round((min(ys)-ct)/ch*100,1)}-{round((max(ys)-ct)/ch*100,1)}")

# tile x-range dark columns (front phone may extend UNDER the tile)
tile_dark = {}
for x in range(tx0, tx1):
    n = sum(1 for y in range(ty0, min(cb, ty0 + 40)) if all(v < 42 for v in px[x, y]))
    if n > 20:
        tile_dark[x] = n
print("dark cols within tile top band (n>20):", len(tile_dark), "-> tile black confirmed" if len(tile_dark) > 100 else "")
