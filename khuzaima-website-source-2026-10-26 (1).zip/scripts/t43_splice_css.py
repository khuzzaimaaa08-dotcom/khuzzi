#!/usr/bin/env python3
"""Task 43 - globals.css surgery: replace the Task 42 NBCU card + showreel
system with the pinned horizontal slider CSS, and append the case-study
stub page styles at the end of the file.

Region replaced (1-indexed, inclusive): the "Our work." section comment
through the last .showreel-pill rule, i.e. everything between the brand
showcase block above and the theme-transition block below.
"""
from pathlib import Path

CSS = Path("/home/z/my-project/src/app/globals.css")
NEW = Path("/home/z/my-project/scripts/t43_our_work.css")

lines = CSS.read_text(encoding="utf-8").splitlines(keepends=True)

# ---- locate the region ------------------------------------------------
start = None
end = None
for i, line in enumerate(lines):
    if line.startswith('/* "Our work." — the giant statement heading plus the NBCU case-study'):
        start = i  # 0-indexed
    if line.startswith(".showreel-pill .sr-expand"):
        end = i
assert start is not None, "start comment not found"
assert end is not None, ".showreel-pill .sr-expand not found"
assert start < end, f"unexpected order: {start} >= {end}"

# boundary sanity: the line after the region is blank, then the theme
# block comment; the line before the region is blank (end of brand block)
after = lines[end + 1]
assert after.strip() == "" or after.startswith("/* Scroll-driven"), (
    f"unexpected line after region: {after!r}"
)
assert lines[end + 2].startswith("/* Scroll-driven light-to-dark theme"), (
    f"theme comment not where expected: {lines[end + 2]!r}"
)
before = lines[start - 1]
assert before.strip() == "", f"expected blank line before region, got {before!r}"

new_block = NEW.read_text(encoding="utf-8")
if not new_block.endswith("\n"):
    new_block += "\n"

replaced = lines[:start] + [new_block] + lines[end + 1:]

# ---- append the case-study stub styles at EOF --------------------------
CASE_CSS = """
/* Case-study stub pages (/case-study/[slug]) — TODO(content): replace
   with real case-study layouts. Minimal site-styled placeholder: matter
   headline on the paper canvas, the one-line outcome, a note, and a way
   back to the slider. */
.case-study-page {
  min-height: 100svh;
  display: flex;
  align-items: center;
  background: var(--paper);
  color: var(--ink);
  padding: calc(var(--nav-h) + 32px) 0 64px;
}
.case-study-page h1 {
  font-family: matter, "matter Fallback", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  font-size: clamp(2.5rem, 8vw, 6rem);
  font-weight: 600;
  letter-spacing: -0.05em;
  line-height: 0.9;
  margin: 24px 0 0;
}
.case-study-lede {
  font-size: clamp(1.05rem, 2vw, 1.35rem);
  font-weight: 500;
  max-width: 44ch;
  margin: 20px 0 0;
}
.case-study-soon {
  margin: 48px 0 0;
  font-size: 0.95rem;
  color: var(--muted-foreground);
}
.case-back {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  font-size: 0.95rem;
  text-decoration: none;
  color: var(--ink);
}
.case-back:hover {
  text-decoration: underline;
}
"""
text = "".join(replaced)
assert ".case-study-page" not in text, "case-study styles already present"
if not text.endswith("\n"):
    text += "\n"
text += CASE_CSS

CSS.write_text(text, encoding="utf-8")
print(f"replaced lines {start + 1}-{end + 1} (of {len(lines)}) with the new block")
print(f"appended case-study styles; file is now {len(text.splitlines())} lines")

# ---- verify no orphaned Task 42 selectors remain -----------------------
orphans = [
    ".work-card-media", ".work-card-body", ".work-card-title ", ".work-card-tag",
    ".work-card-cta", ".wph", ".art-nbcu", ".showreel", ".nbcu-",
]
for sel in orphans:
    assert sel not in text, f"orphaned selector remains: {sel}"
print("no orphaned Task 42 selectors")
