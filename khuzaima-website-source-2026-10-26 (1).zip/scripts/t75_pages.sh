#!/usr/bin/env bash
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000/book >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB screenshot "$OUT/p01-book-top.png" >/dev/null 2>&1
$AB eval "window.scrollTo(0, 900)" >/dev/null 2>&1; sleep 1.5
$AB screenshot "$OUT/p02-book-mid.png" >/dev/null 2>&1
$AB eval "window.scrollTo(0, 1900)" >/dev/null 2>&1; sleep 1.5
$AB screenshot "$OUT/p03-book-faq.png" >/dev/null 2>&1
$AB open http://localhost:3000/contact >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB screenshot "$OUT/p04-contact.png" >/dev/null 2>&1
echo done
