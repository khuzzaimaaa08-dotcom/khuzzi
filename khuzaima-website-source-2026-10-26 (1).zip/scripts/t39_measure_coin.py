#!/usr/bin/env python3
"""Measure the CoinTracker reference card screenshot."""
from PIL import Image
import numpy as np

im = Image.open("/home/z/my-project/upload/pasted_image_1792669449481.png").convert("RGB")
a = np.asarray(im).astype(int)
H, W = a.shape[:2]
print(f"image {W}x{H}")

# corners
for name, (y, x) in {"tl": (3, 3), "tr": (3, W-4), "bl": (H-4, 3), "br": (H-4, W-4)}.items():
    print(f"corner {name}: rgb{tuple(a[y,x])}")

# card bbox: near-white/warm surface vs outer bg
# outer bg likely near-black (#0D0B0A); card is light
light = (a[:,:,0] > 200) & (a[:,:,1] > 195) & (a[:,:,2] > 185)
ys, xs = np.where(light)
print(f"light pixels: {len(ys)}")
rowfrac = light.mean(axis=1); colfrac = light.mean(axis=0)
rows = np.where(rowfrac > 0.5)[0]; cols = np.where(colfrac > 0.5)[0]
if len(rows) and len(cols):
    top, bot, left, right = rows.min(), rows.max(), cols.min(), cols.max()
    cw, ch = right-left+1, bot-top+1
    print(f"CARD bbox: x {left}-{right} (w={cw}) y {top}-{bot} (h={ch}) aspect {cw/ch:.3f}")

    # dark title text "CoinTracker."
    dark = (a[:,:,0] < 90) & (a[:,:,1] < 85) & (a[:,:,2] < 80)
    zone = dark[top:top+int(ch*0.75), left:left+int(cw*0.75)]
    ys2, xs2 = np.where(zone)
    if len(ys2):
        print(f"DARK title zone: x {left+xs2.min()}-{left+xs2.max()} y {top+ys2.min()}-{top+ys2.max()}")
        print(f"  -> left {(xs2.min())/cw*100:.1f}%W, top {(top+ys2.min()-top)/ch*100:.1f}%H, glyph h {ys2.max()-ys2.min()}px = {(ys2.max()-ys2.min())/ch*100:.1f}%H")
        print(f"  title color sample: rgb{tuple(a[top+ys2[len(ys2)//2], left+xs2[len(xs2)//2]])}")

    # gray description
    gray = (a[:,:,0] > 90) & (a[:,:,0] < 190) & (np.abs(a[:,:,0]-a[:,:,1]) < 22) & (np.abs(a[:,:,1]-a[:,:,2]) < 26)
    zy1 = top + int(ch*0.3); zy2 = bot - int(ch*0.02)
    sub = gray[zy1:zy2, left:left+int(cw*0.7)]
    ys3, xs3 = np.where(sub)
    if len(ys3):
        print(f"GRAY desc zone: y {zy1+ys3.min()}-{zy1+ys3.max()} x {left+xs3.min()}-{left+xs3.max()}")
        print(f"  desc color: rgb{tuple(a[zy1+ys3[0], left+xs3[0]])}")
        # line bands
        dens = sub.mean(axis=1)
        lines, inl = [], False
        for i, d in enumerate(dens):
            if d > 0.015 and not inl: st = i; inl = True
            elif d <= 0.015 and inl: lines.append((st, i)); inl = False
        if inl: lines.append((len(dens), 0))
        for st, en in lines:
            if en-st < 6: continue
            lxs = np.where(sub[st:en].any(axis=0))[0]
            print(f"    line y {zy1+st}-{zy1+en} (h={en-st}) x {left+lxs.min()}-{left+lxs.max()}")

    # showreel: black tile with pink H (bottom-right)
    pink = (a[:,:,0] > 150) & (a[:,:,1] < 140) & (a[:,:,2] > 90) & (a[:,:,2] < 215)
    sub = pink[top:bot, left+int(cw*0.5):right]
    ys4, xs4 = np.where(sub)
    if len(ys4):
        sr_left = left+int(cw*0.5)+xs4.min(); sr_right = left+int(cw*0.5)+xs4.max()
        sr_top = top+ys4.min(); sr_bot = top+ys4.max()
        print(f"SHOWREEL (pink zone): x {sr_left}-{sr_right} (w={sr_right-sr_left}) y {sr_top}-{sr_bot} (h={sr_bot-sr_top})")
        print(f"  -> w {100*(sr_right-sr_left)/cw:.1f}%W h {100*(sr_bot-sr_top)/ch:.1f}%H top {100*(sr_top-top)/ch:.1f}%H right-gap {100*(right-sr_right)/cw:.1f}%W bottom-gap {100*(bot-sr_bot)/ch:.1f}%H")

    # bg samples
    for nm, (fy, fx) in {"bg-center": (0.5, 0.42), "bg-topleft": (0.2, 0.1), "bg-topright": (0.2, 0.9), "bg-bottomleft": (0.9, 0.1)}.items():
        print(f"  {nm}: rgb{tuple(a[int(top+fy*ch), int(left+fx*cw)])}")
print("done")
