"""Full-res crops + pixel stats to verify the 8:25 PM winter scene without VLM downscale artifacts."""
from PIL import Image
import sys

path = sys.argv[1] if len(sys.argv) > 1 else "scripts/shots/v7/d-2025.png"
im = Image.open(path).convert("RGB")
W, H = im.size
print(f"frame: {W}x{H}")

# 1) Aurora zone crop (x 25-80%, y 8-42%) - the ribbon body
aur = im.crop((int(W*0.25), int(H*0.08), int(W*0.80), int(H*0.42)))
aur.save("scripts/shots/v7/crop-aurora.png")
print(f"aurora crop: {aur.size}")

# 2) Cabin zone (x 54-70%, y 84-100%) full res
cab = im.crop((int(W*0.54), int(H*0.84), int(W*0.70), int(H*1.0)))
cab = cab.resize((cab.width*3, cab.height*3), Image.LANCZOS)  # 3x zoom for VLM
cab.save("scripts/shots/v7/crop-cabin.png")
print(f"cabin crop 3x: {cab.size}")

# 3) Snow detection: count bright pixels (near-white, above landscape zone y<70%)
import numpy as np
a = np.asarray(im).astype(int)
sky = a[:int(H*0.70)]
# snow dots: pixels lighter than the ultramarine bg but small/isolated
lum = sky.sum(axis=2)
bright = (lum > 420) & (lum < 720)  # paper-ish dots, not full white text
ys, xs = np.where(bright)
print(f"bright-ish pixels in sky zone: {len(xs)}")
# cluster into dots (connected-ish via grid binning)
from collections import defaultdict
bins = defaultdict(int)
for x, y in zip(xs, ys):
    bins[(x//6, y//6)] += 1
dots = [k for k, v in bins.items() if 1 <= v <= 9]  # 2-6px flakes span 1-4 bins
print(f"flake-like dot clusters (~2-6px): {len(dots)}")

# 4) Aurora vertical-structure analysis: in the ribbon band, measure column luminance
# ribbon body approx y 12-30% -> check for gaps (barcode) vs continuous body
band = a[int(H*0.13):int(H*0.30), int(W*0.30):int(W*0.62)]
colg = band.sum(axis=2).mean(axis=0)  # mean per column
colg = np.convolve(colg, np.ones(3)/3, mode="same")
mn, mx = colg.min(), colg.max()
# count deep valleys (barcode gaps): columns much darker than local average
avg = colg.mean()
valleys = ((colg < avg - (mx-mn)*0.45).sum())
print(f"ribbon band: col-lum min {mn:.0f} max {mx:.0f} mean {avg:.0f}, deep-gap columns: {valleys}/{len(colg)} ({100*valleys/len(colg):.0f}%)")

# 5) Hem glow check: bottom edge of ribbon should be brighter than body
hem = a[int(H*0.26):int(H*0.33), int(W*0.32):int(H*0) or int(W*0.58)]
body = a[int(H*0.14):int(H*0.22), int(W*0.32):int(W*0.58)]
print(f"hem-zone mean lum {hem.sum(axis=2).mean():.0f} vs upper-body {body.sum(axis=2).mean():.0f}")

# 6) Pine height: find dark navy pixels in right 40% near bottom, measure tallest column run
right = a[:, int(W*0.60):]
dark = (right.sum(axis=2) < 210)  # dark navy silhouette
darkh = dark.shape[0]
colruns = []
for cx in range(0, right.shape[1], 8):
    col = dark[:, cx]
    if col.any():
        top = int(np.argmax(col))
        colruns.append(darkh - top)
if colruns:
    print(f"tallest dark silhouette run in right 40%: {max(colruns)}px = {100*max(colruns)/H:.1f}% of viewport height")
