#!/usr/bin/env python3
"""Task 42 pass 8 — zoomed ASCII of the front phone's left edge region to
read the frame angle directly; also the phones' separation zone."""
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()
CARD = (25, 64, 1805, 558)
cl, ct, cr, cb = CARD
cw, ch = cr - cl, cb - ct

def sym(x, y):
    r, g, b = px[x, y]
    if r > 225 and g > 232 and b > 238: return "W"   # white
    if r > 185 and g < 140 and r - g > 80: return "K"  # pink
    if r < 45 and g < 45 and b < 50: return "k"       # near black
    if r < 30 and g < 55 and 25 < b < 100 and b > r + 10: return "n"  # navy screen/vignette
    if b > 110 and b - r > 55 and g < 175: return "."  # card blue
    if r > 200 and g > 190 and b > 160: return "c"    # cream/light UI
    return "?"

# zoom: x 920-1120 (200px), y 64-558, cell 4x6
print("LEFT EDGE ZOOM x 920-1120 (each col=2px, each row=7px):")
print("     " + "".join(str((920 + i * 2) // 100 % 10) for i in range(100)))
for j, y in enumerate(range(ct, cb, 7)):
    row = ""
    for i, x in enumerate(range(920, 1120, 2)):
        row += sym(x, y)
    print(f"{y-ct:4d} {row}")

print()
print("SEPARATION ZOOM x 1120-1340 (each col=2px, each row=7px):")
print("     " + "".join(str((1120 + i * 2) // 100 % 10) for i in range(110)))
for y in range(ct, cb, 7):
    row = ""
    for x in range(1120, 1340, 2):
        row += sym(x, y)
    print(f"{y-ct:4d} {row}")
