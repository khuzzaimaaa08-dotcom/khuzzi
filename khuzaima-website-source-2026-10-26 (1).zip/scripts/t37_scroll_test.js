// Scroll-driven slide verification at 1800x850:
// - advance to each card's active position, measure slot geometry
// - verify monotonic entry, exact slot landing, reversibility, pin release
(async () => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const wrap = document.querySelector(".work-scroll");
  const stage = document.querySelector(".work-stage");
  const track = document.querySelector(".work-track");
  const items = [...track.children];
  const cards = items.map((li) => li.querySelector(".work-card"));

  // Wait for GSAP init
  await sleep(600);
  const wrapTop = wrap.getBoundingClientRect().top + window.scrollY;
  const wrapH = wrap.getBoundingClientRect().height;
  const dist = wrapH - innerHeight; // scroll distance while pinned
  const slot0 = cards[0].getBoundingClientRect();
  const out = { viewport: `${innerWidth}x${innerHeight}`, distance: Math.round(dist), stages: [] };

  const measure = (label) => {
    const stageR = stage.getBoundingClientRect();
    const rec = cards.map((c) => {
      const b = c.getBoundingClientRect();
      return {
        x: +b.x.toFixed(1),
        visible: b.x > -b.width && b.x < innerWidth,
        slotDelta: +(b.x - slot0.x).toFixed(1),
      };
    });
    out.stages.push({
      label,
      scrollY: Math.round(window.scrollY),
      pinned: stageR.top === 0 ? "yes" : `no(top=${stageR.top.toFixed(0)})`,
      cards: rec,
      trackX: +(new DOMMatrixReadOnly(getComputedStyle(track).transform).m41 || 0).toFixed(1),
    });
  };

  // helper: smooth-ish scroll to absolute Y then wait for scrub catch-up
  const goTo = async (y) => {
    window.scrollTo(0, y);
    await sleep(1100); // scrub 0.8 needs ~1s to settle after jumps
  };

  await goTo(wrapTop); measure("progress 0 — first card active");
  // advance = distance / 3 between card slots
  const adv = dist / 3;
  await goTo(wrapTop + adv * 0.5); measure("progress ~0.5 — card 2 entering");
  await goTo(wrapTop + adv); measure("progress 1/3 — card 2 active");
  await goTo(wrapTop + adv * 2); measure("progress 2/3 — card 3 active");
  await goTo(wrapTop + adv * 3); measure("progress 3/3 — card 4 active (last)");
  await goTo(wrapTop + dist + 400); measure("past end — pin released");
  await goTo(wrapTop + adv); measure("reverse back — card 2 active again");
  await goTo(wrapTop); measure("reverse to start — card 1 active again");

  // errors collected during the run
  out.overflowX = document.documentElement.scrollWidth - innerWidth;
  return JSON.stringify(out, null, 1);
})()
