#!/bin/bash
# v8 checkpoint sweep at 1920x1080 — screenshots + fx state dumps
set -e
cd /home/z/my-project
S="agent-browser --session winter"
$S set viewport 1920 1080 > /dev/null 2>&1
for t in 19:58 20:00 20:25 20:45 21:00 21:15 21:25 21:30; do
  file="scripts/shots/v8/d-${t/:/}.png"
  $S open "http://localhost:3000/?t=${t}" > /dev/null 2>&1
  $S wait 2800 > /dev/null 2>&1
  $S screenshot "$file" > /dev/null 2>&1
  state=$($S eval "JSON.stringify({fx: window.__winterFx ? {a: +__winterFx.state.aurora.toFixed(3), s: +__winterFx.state.snow.toFixed(3), run: __winterFx.isRunning(), f: __winterFx.stats.frames, dt: +__winterFx.stats.avgDt.toFixed(1)} : 'MISSING', w: document.querySelector('[data-winter]')?.dataset.winter, box: getComputedStyle(document.querySelector('.aurora-box')).visibility, snowFar: getComputedStyle(document.querySelectorAll('[data-winter] canvas')[1]).visibility, snowNear: getComputedStyle(document.querySelectorAll('[data-winter] canvas')[2]).visibility, clock: document.querySelector('[data-hero-ex] span')?.textContent})" 2>/dev/null | tail -1)
  echo "$t -> $state"
done
