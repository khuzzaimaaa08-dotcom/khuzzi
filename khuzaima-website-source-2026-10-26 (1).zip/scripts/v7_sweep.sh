#!/bin/bash
# v7 checkpoint sweep at 1920x1080
set -e
cd /home/z/my-project
S="agent-browser --session winter"
for t in 19:57 20:00 20:10 21:00 21:10 21:20 21:30 21:45 22:30; do
  file="scripts/shots/v7/d-${t/:/}.png"
  $S open "http://localhost:3000/?t=${t}" > /dev/null
  $S wait 2600 > /dev/null
  $S screenshot "$file" > /dev/null
  state=$($S eval "JSON.stringify({winter: document.querySelector('[data-winter]')?.dataset.winter, clock: document.querySelector('[data-hero-ex] span')?.textContent})" 2>/dev/null | tail -1)
  echo "$t -> $file  $state"
done
