#!/usr/bin/env python3
"""Glow tuning loop: compare rendered glow profile against the reference target.

Usage: python3 tune-nav-glow.py <screenshot.png> [--bar 120]
Measures the horizontal R-dominance profile at several rows and the vertical
profile at lobe/saddle x positions, then prints a comparison against the
reference's normalized curve (peaks 139@28%, saddle 55@50%, 129@80%, span
0..100% of glow width).
"""
import sys
from PIL import Image
import numpy as np

shot = sys.argv[1]
a = np.asarray(Image.open(shot).convert("RGB")).astype(int)
r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]

# bar extent
darkfrac = ((r < 40) & (g < 40) & (b < 40)).mean(axis=1)
bar_rows = [y for y in range(300) if y < a.shape[0] and darkfrac[y] > 0.5]
top, bot = bar_rows[0], bar_rows[-1]
barH = bot - top + 1
W = a.shape[1]
print(f"bar: {top}..{bot} h={barH}")

# find glow span: R-dominance at mid-bar, threshold 8
mid = (top + bot) // 2
prof_mid = (r[mid] - b[mid] * 0.5).astype(int)
xs_on = [x for x in range(W) if prof_mid[x] > 8]
# restrict to central band (exclude logo/CTA zones: within 25%..75% of W)
xs_on = [x for x in xs_on if 0.25 * W < x < 0.75 * W]
span_l, span_r = min(xs_on), max(xs_on)
span = span_r - span_l
center = (span_l + span_r) / 2
print(f"visible span: {span_l}..{span_r} w={span} center={center:.0f} ({span/W*100:.1f}% of viewport)")

# reference target curve (normalized to peak=139 -> shown as-is) at % of span
REF = {0:0, 7:35, 12:58, 18:81, 23:95, 28:100, 34:91, 39:72, 45:48, 50:40,
       55:61, 63:65, 69:76, 74:86, 80:93, 85:90, 90:68, 96:29, 100:0}

print(f"\n{'%pos':>5} {'ref':>4} {'ours':>4}   (R-dominance, mid-bar row {mid})")
for pct in sorted(REF):
    x = int(span_l + pct / 100 * span)
    if 0 <= x < W:
        print(f"{pct:5d} {REF[pct]:4d} {prof_mid[x]:4d}")

# vertical profiles at lobe/saddle positions
print("\nvertical (top->bottom of bar, every 12px):")
for pct, name in [(28, "left lobe"), (50, "saddle"), (80, "right lobe")]:
    x = int(span_l + pct / 100 * span)
    col = (r[:, x] - b[:, x] * 0.5).astype(int)
    vals = [col[y] for y in range(top, bot + 1, max(1, barH // 10))]
    print(f"  {name:10s} x={x}: " + " ".join(f"{v:3d}" for v in vals))

# peak absolute color
peak_x = int(span_l + 0.28 * span)
print("\npeak colors:", {f"y={y}": tuple(int(v) for v in a[y, peak_x]) for y in [mid, top + 12, bot - 12]})
