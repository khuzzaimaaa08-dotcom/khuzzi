#!/usr/bin/env bash
# Task 46 — responsive checks: geometry + overflow + screenshots at 3 viewports
set -u
OUT=/home/z/my-project/qa/work-t46
AB="agent-browser"

runvp() { # $1=w $2=h $3=tag
  $AB set viewport "$1" "$2" >/dev/null 2>&1
  $AB open http://localhost:3000 >/dev/null 2>&1
  $AB wait --load networkidle >/dev/null 2>&1
  sleep 3
  echo "=== $3 ($1x$2) ==="
  $AB eval "
(() => {
  const how = document.getElementById('how');
  const title = how.querySelector('.never-done-title');
  const sub = how.querySelector('.never-done-sub');
  const T = parseFloat(how.style.height.match(/calc\(([\d.]+)px/)?.[1] || '0');
  window.__top = Math.round(how.getBoundingClientRect().top + scrollY);
  window.__T = T;
  return JSON.stringify({
    pinStart: window.__top, T, sectionH: how.offsetHeight,
    stackH: how.querySelector('.chatdemo-stack').offsetHeight,
    titleFS: getComputedStyle(title).fontSize, titleLH: getComputedStyle(title).lineHeight,
    titleLeft: title.getBoundingClientRect().left.toFixed(1),
    subFS: getComputedStyle(sub).fontSize,
    docH: document.documentElement.scrollHeight,
    overflowX: document.documentElement.scrollWidth - innerWidth
  });
})()
"
  $AB eval "window.scrollTo(0, window.__top)" >/dev/null 2>&1
  sleep 1.6
  $AB screenshot "$OUT/$3-a-statement.png" >/dev/null 2>&1
  $AB eval "window.scrollTo(0, window.__top + window.__T)" >/dev/null 2>&1
  sleep 1.6
  $AB screenshot "$OUT/$3-b-settle.png" >/dev/null 2>&1
  $AB eval "
(() => {
  const head = document.getElementById('demo-title');
  const sub = document.querySelector('.never-done-sub');
  const stack = document.querySelector('.chatdemo-stack');
  return JSON.stringify({
    headTop: head.getBoundingClientRect().top.toFixed(1),
    subTop: sub.getBoundingClientRect().top.toFixed(1),
    subBottom: sub.getBoundingClientRect().bottom.toFixed(1),
    headVis: head.getBoundingClientRect().top > 0 && head.getBoundingClientRect().bottom < innerHeight,
    ty: getComputedStyle(stack).transform
  });
})()
"
  echo "shots: $3-a-statement.png / $3-b-settle.png"
}

runvp 1366 768  r1-1366x768
runvp 768 1024  r2-768x1024
runvp 390 844   r3-390x844
echo done
