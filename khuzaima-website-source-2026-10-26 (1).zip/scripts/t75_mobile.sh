#!/usr/bin/env bash
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"
$AB set viewport 390 844 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "
(() => {
  const ids = {};
  document.querySelectorAll('section, footer').forEach(s => { ids[s.id || s.tagName.toLowerCase()] = Math.round(s.getBoundingClientRect().top + scrollY); });
  return JSON.stringify({docH: document.documentElement.scrollHeight, sections: ids});
})()
"
