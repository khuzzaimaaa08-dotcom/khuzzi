#!/usr/bin/env bash
# Task 46 — capture the current OurWork → ChatDemo transition at 1792x837
set -u
OUT=/home/z/my-project/qa/work-t46
mkdir -p "$OUT"
AB="agent-browser"

$AB open http://localhost:3000 >/dev/null 2>&1
$AB set viewport 1792 837 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 2

# Find key elements' document positions to drive scrolling precisely
$AB eval "
(() => {
  const work = document.getElementById('work');
  const how = document.getElementById('how');
  const wt = work.getBoundingClientRect().top + scrollY;
  const ht = how.getBoundingClientRect().top + scrollY;
  return JSON.stringify({workTop: Math.round(wt), howTop: Math.round(ht), howH: how.offsetHeight, docH: document.documentElement.scrollHeight});
})()
"
