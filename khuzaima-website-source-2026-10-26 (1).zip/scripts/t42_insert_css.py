#!/usr/bin/env python3
"""Task 42 — insert the NBCU card + floating showreel CSS into globals.css.

Inserts a new block between the .our-work-heading rules (line 360 '}')
and the theme comment (line 362), and updates the section header comment.
All values measured off upload/pasted_image_1792673315484.png (1837x580
crop of the 1907x753 reference; card 1780x494 = 3.60:1).
"""

from pathlib import Path

CSS = Path("/home/z/my-project/src/app/globals.css")
text = CSS.read_text()

# ── 1. update the section header comment ─────────────────────────────────
old_comment = """/* "Our work." — the giant statement heading, alone (OurWork.tsx, Task 40).

   The case-study cards and the horizontal gallery are gone: the section
   is a pure dark divider — the oversized heading on the #0D0B0A canvas,
   a tall blank dissolve runway above it (the theme-transition theater:
   the runway is section padding, so it fades white → #0D0B0A in step
   with the heading's scroll-scrubbed crossing), and a generous exit ramp
   into the ChatDemo section below.

   The heading keeps the reference's exact desktop metrics — matter
   136.576px / 600 / 122.918px line / -6.8288px tracking — and its role as
   the scroll-scrubbed theme boundary (ThemeTransition.tsx keys off
   #our-work-title's position: the canvas is fully #0D0B0A once the
   heading settles). */"""

new_comment = """/* "Our work." — the giant statement heading plus the NBCU case-study
   card and the floating showreel preview (OurWork.tsx, Task 42).

   The section opens with the theme-transition runway (Task 41: blank
   canvas padding that fades white → #0D0B0A in step with the heading's
   scroll-scrubbed crossing), then the reference-exact heading, then the
   case-study card, then a generous exit ramp into ChatDemo.

   The heading keeps the reference's exact desktop metrics — matter
   136.576px / 600 / 122.918px line / -6.8288px tracking — and its role as
   the scroll-scrubbed theme boundary (ThemeTransition.tsx keys off
   #our-work-title's position: the canvas is fully #0D0B0A once the
   heading settles).

   Card geometry is pixel-measured off the reference (card 1780×494,
   3.60:1): 3vw gutters, title cap at 26.5% of card height with its left
   edge at 2.9% of card width, title and headline both 4.67cqw at 0.9
   line-height and -0.05em tracking, the headline wrapping to the three
   reference lines and ending ~91% of card height, headline fill #92BAF2
   (measured glyph interior). The showreel preview is NOT part of the
   card: it is a fixed-position viewport element at the lower-right
   (474×296 at the reference, 4px white frame, ~22px radius, black media
   with the pink 3D-H pattern, frosted plum pill), faded in while the
   section is on screen. */"""

assert old_comment in text, "section header comment not found"
text = text.replace(old_comment, new_comment, 1)

# ── 2. insert the card + showreel system after the heading rules ─────────
anchor = """@media (min-width: 1024px) {
  .our-work-heading {
    font-size: 136.576px;
    line-height: 122.918px;
    letter-spacing: -6.8288px;
    width: 757.771px;
  }
}
"""
assert text.count(anchor) == 1, "heading media anchor not unique"

block = """
/* ── The NBCU case-study card ───────────────────────────────────────── */

/* Heading-bottom → card-top gap, vh-proportioned (~105px at the 753px
   reference viewport — the reference's ~115px heading-to-card clear
   space) plus the card's 3vw page gutters. */
.work-stage {
  margin-top: clamp(36px, 9vw, 64px);
  padding-inline: 3vw;
}
@media (min-width: 768px) {
  .work-stage { margin-top: clamp(56px, 10vh, 96px); }
}
@media (min-width: 1024px) {
  .work-stage { margin-top: clamp(72px, 14vh, 176px); }
}

.work-card {
  position: relative;
  display: block;
  width: 100%;
  /* ~13px at the reference card width, matching the reference corners. */
  border-radius: clamp(12px, 0.72vw, 14px);
  overflow: clip;
  isolation: isolate;
  text-decoration: none;
  /* Cobalt canvas: bright #2878E8 base with the soft center-left
     highlight and the deep-navy vignette behind the phones on the
     right (all measured off the reference). Flat surface — no border,
     no drop shadow, no glass. */
  background:
    radial-gradient(88% 125% at 88% 55%, rgb(4 40 94 / 0.92), transparent 62%),
    radial-gradient(72% 95% at 28% 38%, rgb(110 165 255 / 0.32), transparent 60%),
    linear-gradient(160deg, #2f7eec 0%, #2878e8 46%, #1f63da 100%);
}

/* Artwork layer. Base (mobile): the 4:3 media zone above the text. */
.work-card-media {
  position: relative;
  aspect-ratio: 4 / 3;
  container-type: size;
  overflow: clip;
  display: block;
}
.work-card-media .art {
  position: absolute;
  inset: 0;
  z-index: 1;
  transition: transform 0.6s cubic-bezier(0.2, 0.6, 0.2, 1);
}
/* Gold confetti (measured): amber specks scattered through the band
   between the headline and the phones (~46–74% of card width), denser
   near the phones. The mask keeps the left text zone clean. */
.work-card-media::before {
  content: "";
  position: absolute;
  inset: 0;
  z-index: 0;
  background-image:
    radial-gradient(circle, rgb(255 216 112 / 0.95) 0 1.5px, transparent 2.4px),
    radial-gradient(circle, rgb(240 200 92 / 0.8) 0 1.2px, transparent 2px),
    radial-gradient(circle, rgb(255 232 156 / 0.9) 0 2px, transparent 3.2px),
    radial-gradient(circle, rgb(222 172 60 / 0.7) 0 1px, transparent 1.8px);
  background-size: 3cqw 2.6cqh, 2.5cqw 2.1cqh, 4.8cqw 4.2cqh, 3.7cqw 5cqh;
  background-position: 0 0, 1.25cqw 1.05cqh, 2.4cqw 0.8cqh, 0.9cqw 2.6cqh;
  -webkit-mask-image: linear-gradient(to right, transparent 0 34%, rgb(0 0 0 / 0.9) 46% 74%, transparent 88%);
  mask-image: linear-gradient(to right, transparent 0 34%, rgb(0 0 0 / 0.9) 46% 74%, transparent 88%);
  pointer-events: none;
}

/* Text block: base (mobile/tablet) is in-flow below / beside the media. */
.work-card-body {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: clamp(20px, 5vw, 30px);
}
.work-card-title {
  font-family: matter, "matter Fallback", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  font-size: clamp(1.8rem, 8vw, 2.5rem);
  font-weight: 600;
  line-height: 0.95;
  letter-spacing: -0.03em;
  color: #ffffff;
  margin: 0;
}
.work-card-tag {
  font-size: clamp(1rem, 4.4vw, 1.3rem);
  font-weight: 600;
  line-height: 1.18;
  letter-spacing: -0.012em;
  /* Pale blue measured off the reference glyph interiors (#92BAF2). */
  color: #92baf2;
  max-width: 34ch;
  margin: 10px 0 0;
}
/* CTA chip: eyebrow position (above the title, same left edge), revealed
   on hover/focus on pointer devices, always visible on touch. Out of
   flow on desktop so the title's reference position never shifts. */
.work-card-cta {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  width: max-content;
  margin-bottom: clamp(12px, 2.6vw, 18px);
  padding: 9px 16px;
  border-radius: 999px;
  background: rgb(255 255 255 / 0.16);
  color: #ffffff;
  font-size: 13.5px;
  font-weight: 600;
  letter-spacing: 0.01em;
  opacity: 0;
  transform: translateY(8px);
  transition:
    opacity 0.4s ease,
    transform 0.45s cubic-bezier(0.2, 0.6, 0.2, 1);
}
.work-card-cta svg { width: 13px; height: 13px; }

/* Hover / keyboard affordances — scoped to this card only. */
.work-card:hover .work-card-cta,
.work-card:focus-visible .work-card-cta { opacity: 1; transform: none; }
.work-card:hover .work-card-media .art,
.work-card:focus-visible .work-card-media .art { transform: scale(1.03); }
@media (hover: none), (pointer: coarse) {
  .work-card-cta { opacity: 1; transform: none; }
}
.work-card:focus-visible {
  outline: 3px solid var(--sun);
  outline-offset: 3px;
}
@media (prefers-reduced-motion: reduce) {
  .work-card-media .art { transition: none; }
  .work-card-cta { transition: opacity 0.2s ease; transform: none; }
  .work-card-cta svg { transition: none; }
}

/* Tablet (768–1023): artwork beside the text inside a 1.9:1 frame —
   media RIGHT (mirrored from the old layout) so the floating showreel
   preview at the lower-right overlaps artwork, never the text. */
@media (min-width: 768px) {
  .work-card { display: flex; flex-direction: row-reverse; align-items: stretch; aspect-ratio: 1.9 / 1; }
  .work-card-media { width: 54%; aspect-ratio: auto; }
  .work-card-body {
    width: 46%;
    align-self: center;
    padding: clamp(24px, 3.6vw, 44px);
  }
  .work-card-title { font-size: clamp(1.9rem, 3.4vw, 2.7rem); }
  .work-card-tag { font-size: clamp(1.05rem, 1.8vw, 1.4rem); line-height: 1.14; }
}

/* Desktop (≥1024): the reference panorama. The card becomes its own
   size container, so every interior metric below is a fraction of the
   rendered card — the composition scales with the viewport. */
@media (min-width: 1024px) {
  .work-card {
    aspect-ratio: 3.6 / 1;
    container-type: size;
  }
  .work-card-media {
    position: absolute;
    inset: 0;
    width: auto;
    aspect-ratio: auto;
  }
  .work-card-body {
    position: absolute;
    top: 7cqh;
    left: 2.9cqw;
    width: 43cqw;
    padding: 0;
    z-index: 2;
  }
  .work-card-cta { position: absolute; top: 0; left: 0; margin: 0; }
  .work-card-title {
    font-size: 4.67cqw;
    line-height: 0.9;
    letter-spacing: -0.05em;
    margin-top: 19.2cqh;
  }
  .work-card-tag {
    font-size: 4.67cqw;
    line-height: 0.9;
    letter-spacing: -0.05em;
    margin: 0.28em 0 0;
    max-width: none;
  }
}

/* ── Phone mockups ──────────────────────────────────────────────────────
   Each phone is its own size container, so every interior unit below is
   a fraction of the PHONE: the UI composition stays intact at any card
   size, and the phones simply read larger as the card grows. */

.wph {
  position: absolute;
  aspect-ratio: 9 / 19.2;
  container-type: size;
  border-radius: 5.8cqh;
  padding: 2.8cqh 1.9cqh 2.4cqh;
  display: flex;
  flex-direction: column;
  gap: 1.7cqh;
  overflow: clip;
  box-shadow: 0 3.3cqh 7.8cqh rgb(4 8 20 / 0.4);
  font-size: 2.3cqh;
  line-height: 1.3;
}
.wph-dark {
  background: linear-gradient(175deg, #101b33, #0a1226 70%);
  color: #eef2fb;
  box-shadow: 0 3.3cqh 7.8cqh rgb(2 6 18 / 0.45), inset 0 0 0 0.5cqh rgb(255 255 255 / 0.14);
}
.wph-light {
  background: #ffffff;
  color: #1b1a17;
  box-shadow: 0 3.3cqh 7.8cqh rgb(40 35 20 / 0.28), inset 0 0 0 0.5cqh rgb(20 18 12 / 0.1);
}

/* NBCU placement (fractions of the card media zone): the dark schedule
   phone in front, large enough that the card clips its top and bottom
   edges (measured: full-height span, center ≈58% card width); the light
   AI-chat phone behind it, tilted the other way, peeking out to the
   right where the floating showreel tile passes over it. */
.art-nbcu .nbcu-back {
  left: 65cqw;
  top: 48cqh;
  height: 94cqh;
  transform: translate(-50%, -50%) rotate(-13deg);
  z-index: 1;
}
.art-nbcu .nbcu-front {
  left: 58cqw;
  top: 50cqh;
  height: 106cqh;
  transform: translate(-50%, -50%) rotate(6deg);
  z-index: 2;
}

/* Front (dark) phone interior. */
.wph-status {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 0 0 0.5cqh;
  font-size: 1.9cqh;
  font-weight: 600;
  color: rgb(238 242 251 / 0.92);
}
.wph-island {
  width: 26cqw;
  height: 3cqh;
  border-radius: 999px;
  background: #05070d;
  box-shadow: inset 0 0 0 0.22cqh rgb(255 255 255 / 0.08);
}
.wph-sig { display: inline-flex; gap: 0.8cqh; }
.wph-sig i {
  width: 1.15cqh;
  height: 1.15cqh;
  border-radius: 50%;
  background: rgb(238 242 251 / 0.92);
}
.wph-apphead {
  display: flex;
  align-items: center;
  gap: 1.3cqh;
}
.wph-apphead b {
  flex: 1;
  font-size: 2.3cqh;
  font-weight: 800;
  letter-spacing: 0.03em;
}
.wph-oli {
  width: 4.9cqh;
  height: 4.9cqh;
  border-radius: 50%;
  background: linear-gradient(150deg, #ffd34d, #e8a020);
  color: #4a2c00;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 1.9cqh;
  font-weight: 800;
  letter-spacing: 0.02em;
  flex: none;
}
.wph-x { width: 2.5cqh; height: 2.5cqh; color: rgb(238 242 251 / 0.7); flex: none; }
/* Medal standings — dark navy grid under the app header. */
.wph-standings {
  margin: 0;
  padding: 1.6cqh 1.8cqh;
  border-radius: 2.2cqh;
  background: rgb(9 16 36 / 0.88);
  box-shadow: inset 0 0 0 0.28cqh rgb(120 160 255 / 0.18);
  display: flex;
  flex-direction: column;
  gap: 1cqh;
  list-style: none;
}
.wph-standings li {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 2cqh;
}
.wph-standings li + li { border-top: 0.17cqh solid rgb(255 255 255 / 0.08); padding-top: 1cqh; }
.wph-standings b { font-weight: 700; letter-spacing: 0.05em; }
.wph-standings span { display: inline-flex; align-items: center; gap: 1.2cqh; }
.wph-standings i {
  width: 1.28cqh;
  height: 1.28cqh;
  border-radius: 50%;
  display: inline-block;
  margin-right: 0.5cqh;
  vertical-align: baseline;
}
.wph-standings .m-g { background: #ffd34d; }
.wph-standings .m-s { background: #c9d4e4; }
.wph-standings .m-b { background: #d99a6c; }
.wph-intro {
  margin: 0;
  font-size: 2cqh;
  color: rgb(238 242 251 / 0.85);
}
.wph-promo {
  margin-top: 0.9cqh;
  padding: 2.2cqh 2cqh;
  border-radius: 2.4cqh;
  background: linear-gradient(165deg, #1b2c55, #101b33 75%);
  box-shadow: inset 0 0 0 0.33cqh rgb(120 160 255 / 0.25);
  display: flex;
  flex-direction: column;
  gap: 1.1cqh;
}
.wph-live {
  display: flex;
  align-items: center;
  gap: 1cqh;
  margin: 0;
  color: #ff5d6b;
  font-weight: 700;
  font-size: 1.9cqh;
  letter-spacing: 0.04em;
}
.wph-live i {
  width: 1.2cqh;
  height: 1.2cqh;
  border-radius: 50%;
  background: #ff5d6b;
}
.wph-promo-title {
  margin: 0;
  font-weight: 800;
  font-size: 4cqh;
  letter-spacing: 0.06em;
}
.wph-promo-copy {
  margin: 0;
  color: rgb(238 242 251 / 0.72);
  font-size: 2cqh;
}
.wph-peacock {
  margin-top: 0.5cqh;
  width: max-content;
  padding: 1.2cqh 2.7cqh;
  border-radius: 999px;
  background: #ffffff;
  color: #101b33;
  font-weight: 700;
  font-size: 2.4cqh;
}
.wph-footer {
  margin: auto 0 0;
  display: flex;
  align-items: center;
  gap: 1.3cqh;
  font-size: 2cqh;
  color: rgb(238 242 251 / 0.62);
}
.wph-vote { display: inline-flex; gap: 0.9cqh; }
.wph-vote i {
  width: 2.7cqh;
  height: 2.1cqh;
  border-radius: 0.7cqh;
  border: 0.22cqh solid rgb(238 242 251 / 0.45);
}

/* Back (light) phone interior. */
.wph-head { margin: 0 0 0.45cqh; font-weight: 800; font-size: 2.9cqh; }
.wph-avatar {
  width: 2.9cqh;
  height: 2.9cqh;
  border-radius: 50%;
  background: linear-gradient(135deg, #ffb4a6, #e56b6f);
  flex: none;
  display: inline-block;
  vertical-align: -0.55cqh;
}
.wph-bubble {
  padding: 1.7cqh 2cqh;
  border-radius: 2cqh 2cqh 2cqh 0.55cqh;
  background: #f1f0ec;
  color: #1b1a17;
  font-size: 2.1cqh;
}
.wph-ask {
  margin: 0.45cqh 0 0;
  color: #6f695d;
  font-size: 1.9cqh;
}
.wph-chips {
  display: flex;
  flex-direction: column;
  gap: 1.1cqh;
  margin: 0;
  padding: 0;
  list-style: none;
}
.wph-chips li {
  padding: 1.2cqh 1.8cqh;
  border-radius: 999px;
  background: #e9e7e1;
  color: #44403a;
  font-size: 2cqh;
  white-space: nowrap;
}
.wph-input {
  margin: auto 0 0;
  padding: 1.3cqh 2cqh;
  border-radius: 999px;
  background: #f4f3ef;
  color: #8a857c;
  font-size: 2cqh;
  white-space: nowrap;
}

/* ── Floating showreel preview (viewport-level, NOT part of the card) ── */

.showreel-float {
  position: fixed;
  right: 3.6vw;
  bottom: clamp(36px, 6.9vh, 60px);
  z-index: 40; /* floats over page content, under the navbar (z 50) */
  width: min(24.9vw, 520px);
  aspect-ratio: 474 / 296;
  container-type: size;
  pointer-events: none;
  opacity: 0;
  transform: translateY(14px) scale(0.985);
  transition:
    opacity 0.45s ease,
    transform 0.5s cubic-bezier(0.2, 0.6, 0.2, 1);
}
.showreel-float[data-visible="on"] { opacity: 1; transform: none; }
@media (max-width: 767px) {
  .showreel-float { display: none; }
}
@media (prefers-reduced-motion: reduce) {
  .showreel-float { transform: none; transition: opacity 0.2s ease; }
}
.showreel-frame {
  position: absolute;
  inset: 0;
  border-radius: 4.6cqw; /* ~22px at the reference tile width */
  background: #171717;
  /* Thick white frame (4px at the reference), no gap to the media. */
  border: 0.85cqw solid #ffffff;
  box-shadow: 0 2.6cqh 6cqh rgb(0 0 0 / 0.38);
  overflow: clip;
}
.showreel-hs {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}
.showreel-pill {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 3cqw;
  width: 56cqw;
  height: 29cqh;
  border-radius: 999px;
  /* Frosted plum glass over the H pattern (measured surface ≈ #7D5462). */
  background: rgb(232 199 222 / 0.32);
  -webkit-backdrop-filter: blur(6px);
  backdrop-filter: blur(6px);
  box-shadow: inset 0 0 0 0.22cqw rgb(255 255 255 / 0.18);
  color: #ffffff;
  font-family: matter, "matter Fallback", ui-sans-serif, system-ui, sans-serif;
  font-size: 8.2cqh;
  font-weight: 600;
  letter-spacing: -0.01em;
  white-space: nowrap;
}
.showreel-pill .sr-play { width: 3.7cqw; height: 4.4cqh; flex: none; }
.showreel-pill .sr-expand { width: 4.3cqw; height: 4.3cqw; flex: none; }
"""

text = text.replace(anchor, anchor + block, 1)
CSS.write_text(text)
print("inserted; new length:", len(text.splitlines()), "lines")
