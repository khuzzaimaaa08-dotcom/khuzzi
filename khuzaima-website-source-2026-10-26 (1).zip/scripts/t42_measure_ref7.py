#!/usr/bin/env python3
"""Task 42 pass 7 — front phone precise bbox via its dark-navy screen color;
also characterize gold particles at full resolution."""
import json
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()
CARD = (25, 64, 1805, 558)
cl, ct, cr, cb = CARD
cw, ch = cr - cl, cb - ct
TILE = (1332, 232, 1806, 528)

# sample screen colors at known interior points of the front phone
probes = [(1050, 150), (1100, 300), (1000, 400), (1150, 480), (980, 200)]
print("front phone screen samples:", [px[x, y] for x, y in probes])

# classify: dark navy screen = r 8-40, g 12-45, b 30-80, b > r
def is_screen(x, y):
    r, g, b = px[x, y]
    return 6 <= r <= 42 and 10 <= g <= 48 and 28 <= b <= 85 and b > r + 12

cols = {}
for x in range(cl + int(cw * 0.4), cr):
    n = 0
    for y in range(ct, cb):
        if is_screen(x, y):
            n += 1
    if n > 30:
        cols[x] = n
xs = sorted(cols)
groups = []
if xs:
    s = p = xs[0]
    for x in xs[1:]:
        if x - p > 18:
            groups.append((s, p)); s = x
        p = x
    groups.append((s, p))
print("screen col groups:", groups)
for (a, b) in groups:
    if b - a < 40: continue
    ys = [y for y in range(ct, cb) if any(is_screen(x, y) for x in range(a, b, 3))]
    if ys:
        print(f"  group x {a}-{b} in-card {round((a-cl)/cw*100,1)}-{round((b-cl)/cw*100,1)}%  "
              f"y {min(ys)}-{max(ys)} in-card {round((min(ys)-ct)/ch*100,1)}-{round((max(ys)-ct)/ch*100,1)}%")

# ── gold particles at full res: connected-ish clusters in a sample zone ──
# zone: x 55-75% cardW, y 5-80% cardH — list individual speck bboxes
zone = (cl + int(cw*0.50), ct + int(ch*0.05), cl + int(cw*0.75), ct + int(ch*0.80))
specks = []
step = 2
for y in range(zone[1], zone[3], step):
    for x in range(zone[0], zone[2], step):
        r, g, b = px[x, y]
        if r > 165 and g > 120 and b < 150 and r - b > 50:
            specks.append((x, y))
# cluster specks within 6px
clusters = []
for (x, y) in specks:
    for c in clusters:
        if abs(x - c[0]) < 7 and abs(y - c[1]) < 7:
            c[0] = (c[0] * c[2] + x) / (c[2] + 1); c[1] = (c[1] * c[2] + y) / (c[2] + 1); c[2] += 1
            break
    else:
        clusters.append([x, y, 1])
big = [c for c in clusters if c[2] >= 2]
print(f"\ngold speck clusters (n={len(clusters)}, multi-px={len(big)}):")
print("  in-card positions%:", [(round((c[0]-cl)/cw*100,1), round((c[1]-ct)/ch*100,1), c[2]) for c in big[:24]])

# check a couple of specks' shapes (are they star-like 4-point glows?)
if big:
    cx, cy = int(big[0][0]), int(big[0][1])
    print("\nspeck shape dump around", cx, cy, ":")
    for y in range(cy - 5, cy + 6):
        row = ""
        for x in range(cx - 7, cx + 8):
            r, g, b = px[x, y]
            row += "#" if (r > 150 and g > 110 and b < 160 and r - b > 40) else "."
        print("   ", row)
