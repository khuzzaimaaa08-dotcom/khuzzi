#!/usr/bin/env python3
"""Replace the WINTER block (doc comment through snowAmount) in heroSceneTimeline.ts."""
import io, sys

PATH = "/home/z/my-project/src/components/site/heroSceneTimeline.ts"
NEW = "/home/z/my-project/scripts/winter_block.ts"

with io.open(PATH, encoding="utf-8") as f:
    src = f.read()
with io.open(NEW, encoding="utf-8") as f:
    block = f.read()

start_marker = "Winter aurora night, 8:00"
end_marker = "export const BALLOONS"

si = src.find(start_marker)
if si < 0:
    sys.exit("start marker not found")
# back up to the beginning of the doc comment line
si = src.rfind("/**", 0, si)
ei = src.find(end_marker)
if ei < 0:
    sys.exit("end marker not found")
# trim back to the start of the end-marker line (drop the leading blank line)
ei = src.rfind("\n", 0, ei)  # newline right before 'export const BALLOONS'
ei = src.rfind("\n", 0, ei) + 1  # start of that blank line

out = src[:si] + block + src[ei:]
with io.open(PATH, "w", encoding="utf-8") as f:
    f.write(out)
print("replaced", ei - si, "chars with", len(block), "chars")
