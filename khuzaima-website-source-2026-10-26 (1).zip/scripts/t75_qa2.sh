#!/usr/bin/env bash
# Task 75 — QA battery 2: anchors, reversal, mobile, tablet, reload
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"

echo "=== 1. anchor: /#work ==="
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open "http://localhost:3000/#work" >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "
(() => {
  const stage = document.querySelector('.work-stage');
  const r = stage.getBoundingClientRect();
  return JSON.stringify({y: Math.round(scrollY), stageTop: +r.top.toFixed(1), headingVisible: !!document.querySelector('#our-work-title')});
})()
"

echo "=== 2. anchor: /#never-done ==="
$AB open "http://localhost:3000/#never-done" >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "
(() => {
  const nd = document.getElementById('never-done');
  return JSON.stringify({y: Math.round(scrollY), ndTop: +nd.getBoundingClientRect().top.toFixed(1), titleBelowNav: document.querySelector('.never-done-title').getBoundingClientRect().top > 0});
})()
"

echo "=== 3. craft link 'See the work.' target ==="
$AB eval "
(() => {
  const a = [...document.querySelectorAll('.craft-link')][0];
  return JSON.stringify({href: a.getAttribute('href')});
})()
"

echo "=== 4. reversal: down through statement, back up ==="
$AB eval "window.scrollTo(0, 0)" >/dev/null 2>&1; sleep 1.5
$AB eval "window.scrollTo(0, 12200)" >/dev/null 2>&1; sleep 1.5
$AB eval "window.scrollTo(0, 0)" >/dev/null 2>&1; sleep 2
$AB eval "JSON.stringify({y: Math.round(scrollY), heroOk: document.getElementById('top').getBoundingClientRect().top === 0})"

echo "=== 5. mobile 390x844 ==="
$AB set viewport 390 844 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "
(() => {
  const nd = document.getElementById('never-done');
  const top = nd.getBoundingClientRect().top + scrollY;
  window.__m = Math.round(top);
  const t = nd.querySelector('.never-done-title');
  const cs = getComputedStyle(t);
  return JSON.stringify({ndTop: Math.round(top), secH: nd.offsetHeight, titleFont: cs.fontSize, overflowX: document.documentElement.scrollWidth - innerWidth, docH: document.documentElement.scrollHeight});
})()
"
$AB eval "window.scrollTo(0, window.__m - 100)" >/dev/null 2>&1; sleep 2
$AB screenshot "$OUT/f06-mobile-statement.png" >/dev/null 2>&1
$AB eval "window.scrollTo(0, window.__m + 500)" >/dev/null 2>&1; sleep 2
$AB screenshot "$OUT/f07-mobile-exit.png" >/dev/null 2>&1

echo "=== 6. tablet 768x1024 ==="
$AB set viewport 768 1024 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "
(() => {
  const nd = document.getElementById('never-done');
  const top = nd.getBoundingClientRect().top + scrollY;
  window.__t = Math.round(top);
  const t = nd.querySelector('.never-done-title');
  const cs = getComputedStyle(t);
  return JSON.stringify({ndTop: Math.round(top), secH: nd.offsetHeight, titleFont: cs.fontSize, gutter: getComputedStyle(nd.querySelector('.never-done')).paddingLeft, overflowX: document.documentElement.scrollWidth - innerWidth});
})()
"
$AB eval "window.scrollTo(0, window.__t)" >/dev/null 2>&1; sleep 2
$AB screenshot "$OUT/f08-tablet-statement.png" >/dev/null 2>&1

echo "=== 7. deep reload mid-statement (desktop) ==="
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 2
$AB eval "window.scrollTo(0, 11900)" >/dev/null 2>&1; sleep 1.5
$AB eval "location.reload()" >/dev/null 2>&1
sleep 5
$AB eval "
(() => {
  const t = document.querySelector('.never-done-title');
  const r = t.getBoundingClientRect();
  return JSON.stringify({y: Math.round(scrollY), titleTop: +r.top.toFixed(1), spans: [...document.querySelectorAll('.never-done-title .reveal-line > span')].map(s => getComputedStyle(s).transform)});
})()
"
$AB screenshot "$OUT/f09-deep-reload.png" >/dev/null 2>&1
echo "=== 8. console errors ==="
$AB errors 2>/dev/null | head -8
