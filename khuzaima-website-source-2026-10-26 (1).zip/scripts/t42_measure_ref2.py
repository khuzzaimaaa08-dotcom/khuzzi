#!/usr/bin/env python3
"""Task 42 pass 2 — detailed measurements: showreel tile (pink/black detection),
headline line structure + glyph color, phone vertical extents, heading crop check."""
import json
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()

CARD = (25, 64, 1805, 558)  # from pass 1
cl, ct, cr, cb = CARD
cw, ch = cr - cl, cb - ct
out = {"card": CARD, "card_size": [cw, ch]}

# ── showreel: pink pixels (hot pink H letters) ────────────────────────────
pink_px = []
for y in range(ct, H):
    for x in range(cl + cw // 3, W):
        r, g, b = px[x, y]
        if r > 190 and g < 130 and 80 < b < 200 and r - g > 90:
            pink_px.append((x, y))
out["pink_count"] = len(pink_px)
if pink_px:
    xs = [p[0] for p in pink_px]; ys = [p[1] for p in pink_px]
    out["pink_bbox"] = [min(xs), min(ys), max(xs), max(ys)]
    out["pink_bbox_pct_of_viewport"] = [
        round(min(xs) / W, 3), round(min(ys) / H, 3),
        round(max(xs) / W, 3), round(max(ys) / H, 3)]

# black tile containing the pink: expand from pink bbox to the black border
if pink_px:
    px0, py0, px1, py1 = min(xs), min(ys), max(xs), max(ys)
    # walk left from pink bbox until 3 consecutive non-black rows
    def is_blackish(x, y):
        r, g, b = px[x, y]
        return r < 38 and g < 38 and b < 38
    # scan the row at pink mid-height for black runs around pink
    ym = (py0 + py1) // 2
    # find left edge: from px0 walk left while black-ish or pink
    x = px0
    while x > cl:
        if is_blackish(x, ym) or (px[x, ym][0] > 190 and px[x, ym][1] < 130):
            x -= 1
        else:
            break
    sr_left_guess = x + 1
    # find right edge similarly from px1
    x = px1
    while x < W - 1:
        if is_blackish(x, ym) or (px[x, ym][0] > 190 and px[x, ym][1] < 130):
            x += 1
        else:
            break
    sr_right_guess = x - 1
    out["showreel_black_row_extent"] = [sr_left_guess, sr_right_guess]

    # vertical: column at pink mid-x
    xm = (px0 + px1) // 2
    y = py0
    while y > 0:
        if is_blackish(xm, y) or (px[xm, y][0] > 190 and px[xm, y][1] < 130):
            y -= 1
        else:
            break
    sr_top_guess = y + 1
    y = py1
    while y < H - 1:
        if is_blackish(xm, y) or (px[xm, y][0] > 190 and px[xm, y][1] < 130):
            y += 1
        else:
            break
    sr_bot_guess = y - 1
    out["showreel_black_col_extent"] = [sr_top_guess, sr_bot_guess]
    srw = sr_right_guess - sr_left_guess
    srh = sr_bot_guess - sr_top_guess
    out["showreel_size_est"] = [srw, srh]
    out["showreel_ratio_est"] = round(srw / srh, 3) if srh else None
    out["showreel_right_inset"] = W - 1 - sr_right_guess
    out["showreel_bottom_inset"] = H - 1 - sr_bot_guess
    out["showreel_right_inset_pct"] = round((W - 1 - sr_right_guess) / W * 100, 2)
    # overlap with card: is the tile inside card bounds?
    out["showreel_vs_card"] = {
        "starts_left_of_card_right": sr_left_guess < cr,
        "top_above_card_bottom": sr_top_guess < cb,
    }

# ── headline line structure (pale blue text, left half of card) ───────────
# collect rows where pale-blue glyph pixels exist
rows = {}
for y in range(ct, cb):
    cnt = 0
    for x in range(cl, cl + int(cw * 0.55)):
        r, g, b = px[x, y]
        if b > 195 and 140 < r < 225 and 165 < g < 235 and b - r > 35 and b - g > 15:
            cnt += 1
    if cnt > 6:
        rows[y] = cnt
ys = sorted(rows)
lines = []
if ys:
    s = p = ys[0]
    for y in ys[1:]:
        if y - p > 3:
            lines.append([s, p]); s = y
        p = y
    lines.append([s, p])
out["headline_lines"] = []
for i, (a, b) in enumerate(lines):
    # per-line x extent + dominant color
    xs2 = []
    colors = {}
    for y in range(a, b + 1):
        for x in range(cl, cl + int(cw * 0.55)):
            r, g, b2 = px[x, y]
            if b2 > 195 and 140 < r < 225 and 165 < g < 235 and b2 - r > 35 and b2 - g > 15:
                xs2.append(x)
                c = (r // 16 * 16, g // 16 * 16, b2 // 16 * 16)
                colors[c] = colors.get(c, 0) + 1
    dom = max(colors, key=colors.get) if colors else None
    out["headline_lines"].append({
        "n": i + 1, "y_in_card": [a - ct, b - ct], "h": b - a + 1,
        "x0_in_card": min(xs2) - cl if xs2 else None,
        "x1_in_card": max(xs2) - cl if xs2 else None,
        "dom_color": dom,
    })

# NBCU. label: white glyph rows
rows2 = {}
for y in range(ct, ct + int(ch * 0.6)):
    cnt = 0
    for x in range(cl, cl + int(cw * 0.35)):
        r, g, b = px[x, y]
        if r > 235 and g > 240 and b > 245:
            cnt += 1
    if cnt > 6:
        rows2[y] = cnt
ys2 = sorted(rows2)
if ys2:
    l2 = []
    s = p = ys2[0]
    for y in ys2[1:]:
        if y - p > 3:
            l2.append([s, p]); s = y
        p = y
    l2.append([s, p])
    out["nbcu_label_lines"] = [
        {"y_in_card": [a - ct, b - ct], "h": b - a + 1} for a, b in l2]

# ── phones: vertical extent at specific columns ────────────────────────────
def phone_extent_at(x_viewport):
    """topmost/Bottom-most non-blue row inside card at this column"""
    tops, bots = None, None
    for y in range(ct, cb):
        r, g, b = px[x_viewport, y]
        if not (b > 110 and b - r > 60 and g < 170):
            if tops is None:
                tops = y
            bots = y
    return (tops - ct if tops is not None else None,
            bots - cb if bots is not None else None)
# sample columns across the right 2/3
out["phone_v_extent"] = {}
for label, xv in [
    ("back_phone_mid", int(cl + cw * 0.39)),
    ("front_phone_left", int(cl + cw * 0.60)),
    ("front_phone_mid", int(cl + cw * 0.72)),
    ("front_phone_right", int(cl + cw * 0.90)),
]:
    t, b = phone_extent_at(xv)
    out["phone_v_extent"][label] = {"top_px_from_card_top": t, "bottom_overshoot": b}

# ── save crops for visual inspection ───────────────────────────────────────
img.crop((cl, ct, cr, cb)).save("/home/z/my-project/qa/work-t42/ref_card_only.png")
img.crop((0, 0, W, ct)).save("/home/z/my-project/qa/work-t42/ref_above_card.png")
img.crop((cl + int(cw * 0.3), ct, W, H)).save("/home/z/my-project/qa/work-t42/ref_right_half.png")

print(json.dumps(out, indent=1, default=str))
