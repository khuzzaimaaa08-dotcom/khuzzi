import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const shots = [
  'j01-hero-top.png', 'j02-hero-1300.png', 'j02-hero-2000.png', 'j02-hero-2342.png',
  'j06-work-start.png', 'j07-work-card2.png', 'j10-how-statement.png', 'j11-how-1142.png',
  'j12-services.png',
];

async function main() {
  const zai = await ZAI.create();
  for (const file of shots) {
    const path = `/home/z/my-project/qa/t75/${file}`;
    if (!fs.existsSync(path)) { console.log(`\n=== ${file}: MISSING ===`); continue; }
    const b64 = fs.readFileSync(path).toString('base64');
    try {
      const res = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: 'You transcribe website screenshots exactly.' },
          {
            role: 'user', content: [
              { type: 'text', text: `Transcribe ALL visible text in this screenshot verbatim, top to bottom, including small labels, timestamps, captions and any text inside graphics. Note anything that looks like placeholder/garbled/debug text.` },
              { type: 'image_url', image_url: { url: `data:image/png;base64,${b64}` } },
            ],
          },
        ],
      });
      console.log(`\n===== ${file} =====\n` + res.choices[0]?.message?.content);
    } catch (e) { console.log(`\n===== ${file} ===== ERROR: ${e.message}`); }
  }
}
main();
