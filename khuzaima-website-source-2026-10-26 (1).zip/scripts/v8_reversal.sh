#!/bin/bash
# v8 reversal test: fresh ?t=20:30 vs 21:15 -> scroll back to 20:30
set -e
cd /home/z/my-project
S="agent-browser --session winter"
PROBE='(() => { const win = [...document.querySelectorAll(".cabin-box rect")].find(r => r.getAttribute("fill") === "var(--sun)"); return JSON.stringify({a: +__winterFx.state.aurora.toFixed(3), s: +__winterFx.state.snow.toFixed(3), w: document.querySelector("[data-winter]").dataset.winter, boxV: document.querySelector(".aurora-box").style.visibility, boxT: document.querySelector(".aurora-box").style.transform, snowF: document.querySelectorAll("[data-winter] canvas")[1].style.visibility, snowN: document.querySelectorAll("[data-winter] canvas")[2].style.visibility, hillB: document.querySelector(".hill-back").style.transform, hillF: document.querySelector(".hill-front").style.transform, cabin: document.querySelector(".cabin-box").style.transform, win: win ? win.style.opacity : "x", pines: [...document.querySelectorAll("[data-winter] div.absolute.bottom-0")].map(n => n.style.opacity).join(",")}); })()'

$S open "http://localhost:3000/?t=20:30" > /dev/null 2>&1
$S wait 2600 > /dev/null 2>&1
$S eval "$PROBE" 2>&1 | tail -1 > /tmp/v8_fresh.json
echo "fresh: $(cat /tmp/v8_fresh.json)"

$S open "http://localhost:3000/?t=21:15" > /dev/null 2>&1
$S wait 2600 > /dev/null 2>&1
$S eval "const sec = document.getElementById('top'); const span = sec.offsetHeight - innerHeight; const p30 = (1230-540)/(23*60+42-540); window.scrollTo(0, sec.offsetTop + span*p30); 'back to 20:30 pos'" > /dev/null 2>&1
$S wait 2000 > /dev/null 2>&1
$S eval "$PROBE" 2>&1 | tail -1 > /tmp/v8_back.json
echo "back:  $(cat /tmp/v8_back.json)"

python3 - <<'EOF'
import json
a = json.load(open('/tmp/v8_fresh.json'))
b = json.load(open('/tmp/v8_back.json'))
diff = {k: (a[k], b[k]) for k in a if a[k] != b[k]}
print('REVERSAL: IDENTICAL' if not diff else 'REVERSAL DIFFS: ' + json.dumps(diff))
EOF
