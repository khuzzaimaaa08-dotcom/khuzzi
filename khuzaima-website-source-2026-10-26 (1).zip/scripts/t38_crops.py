#!/usr/bin/python3
from PIL import Image

im = Image.open("/home/z/my-project/upload/pasted_image_1792667125776.png").convert("RGB")
# full card
im.crop((36, 43, 1853, 577)).resize((1200, 340), Image.LANCZOS).save("/home/z/my-project/qa/work-t38/ref-full-card.png")
# showreel region (right edge)
im.crop((1380, 240, 1860, 570)).save("/home/z/my-project/qa/work-t38/ref-showreel.png")
# phones region
im.crop((850, 60, 1500, 570)).save("/home/z/my-project/qa/work-t38/ref-phones.png")
# text zone fine
im.crop((80, 180, 820, 540)).save("/home/z/my-project/qa/work-t38/ref-text.png")
# front phone zone (gold zone)
im.crop((900, 60, 1350, 570)).save("/home/z/my-project/qa/work-t38/ref-frontphone.png")
print("saved")
