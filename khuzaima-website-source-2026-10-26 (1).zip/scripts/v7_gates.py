"""Deterministic pixel gates for the v7 QA checkpoints (no VLM subjectivity)."""
from PIL import Image
import numpy as np

def load(p):
    return np.asarray(Image.open(f"scripts/shots/v7/{p}").convert("RGB")).astype(int)

def zone(im, x0, x1, y0, y1):
    H, W, _ = im.shape
    return im[int(H*y0):int(H*y1), int(W*x0):int(W*x1)]

# ribbon body zone (green lift = aurora mint/aqua presence)
RIB = (0.30, 0.62, 0.10, 0.30)
# bottom-right landscape zone
LAND = (0.60, 0.99, 0.86, 0.995)
# cabin window zone
CAB = (0.555, 0.68, 0.885, 0.985)

base = load("d-2145.png")  # winter=off, intentional calm — the "empty night" reference

def greenlift(im):
    z = zone(im, *RIB).astype(int)
    g = z[:, :, 1].astype(float) - (z[:, :, 0] + z[:, :, 2]) / 2
    return g.mean()

def landdiff(im):
    a = zone(im, *LAND).astype(float)
    b = zone(base, *LAND).astype(float)
    return np.abs(a - b).mean()

def warmpix(im):
    z = zone(im, *CAB).astype(int)
    r, g, b = z[:, :, 0], z[:, :, 1], z[:, :, 2]
    return int(((r > 150) & (g > 110) & (b < 120) & (r > b + 60)).sum())  # yellow window light

g_base = greenlift(base)
print(f"reference (21:45, empty): greenlift={g_base:.2f} landdiff=0 warm={warmpix(base)}")

for name, note in [
    ("d-1957.png", "7:57  glimmer, no landscape"),
    ("d-2000.png", "8:00  aurora>=40%, hills starting"),
    ("d-2010.png", "8:10  building, pines/cabin rising"),
    ("d-2025.png", "8:25  FULL scene"),
    ("d-2100.png", "9:00  full + sparkles"),
    ("d-2110.png", "9:10  hold (exit begins)"),
    ("d-2120.png", "9:20  ~half gone, light off"),
    ("d-2130.png", "9:30  ALL GONE"),
]:
    im = load(name)
    gl = greenlift(im) - g_base
    ld = landdiff(im)
    wp = warmpix(im)
    print(f"{name}  {note:34s} greenlift=+{gl:6.2f}  landdiff={ld:6.2f}  warmwin={wp}")

# aurora level ratios vs full (8:25)
full = greenlift(load("d-2025.png")) - g_base
for name, expect in [("d-2000.png", "~0.42"), ("d-2010.png", "~0.7"), ("d-2120.png", "~0.5"), ("d-2130.png", "0")]:
    gl = greenlift(load(name)) - g_base
    print(f"{name}: aurora level = {gl/full:.2f} of full (expected {expect})")
