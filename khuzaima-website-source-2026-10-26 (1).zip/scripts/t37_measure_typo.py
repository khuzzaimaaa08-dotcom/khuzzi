#!/usr/bin/env python3
"""Pixel-measure the reference card's text block + check top-right arrow chip."""
from PIL import Image

im = Image.open("/home/z/my-project/upload/pasted_image_1792664597584.png").convert("RGB")
W, H = im.size
px = im.load()
# Card bbox from before: x[58..1832] y[374..868], card 1774x494
CX0, CY0, CW, CH = 58, 374, 1774, 494

def scan_band(x0, x1, y0, y1, label):
    """find bbox of white-ish text pixels within region"""
    minx, miny, maxx, maxy = 10**9, 10**9, -1, -1
    for y in range(y0, y1):
        for x in range(x0, x1):
            r, g, b = px[x, y]
            if r > 225 and g > 225 and b > 225:
                minx, miny = min(minx, x), min(miny, y)
                maxx, maxy = max(maxx, x), max(maxy, y)
    if maxx < 0:
        print(f"  {label}: none")
        return
    print(f"  {label}: x[{minx}..{maxx}] y[{miny}..{maxy}]  "
          f"left={(minx-CX0)/CW*100:.1f}% of cardW  top={(miny-CY0)/CH*100:.1f}% of cardH  "
          f"h={(maxy-miny+1)/CH*100:.1f}% of cardH")

# Left 45% of card: title + description text
scan_band(CX0, CX0+800, CY0, CY0+CH, "left text block (all)")
# Title only: upper 40% of card
scan_band(CX0, CX0+800, CY0, CY0+200, "title zone")
# Top-right corner of card (arrow chip?) — right 15%, top 25%
scan_band(CX0+CW-270, CX0+CW, CY0, CY0+130, "top-right chip zone")
# Bottom-right corner (showreel tile) — right 30%, bottom 45%
scan_band(CX0+CW-540, CX0+CW, CY0+280, CY0+CH, "bottom-right text (Play showreel)")
