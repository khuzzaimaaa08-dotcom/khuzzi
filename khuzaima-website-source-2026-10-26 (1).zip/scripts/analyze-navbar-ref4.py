#!/usr/bin/env python3
"""Finer measurements: link y-extent/cap-height, glow vertical profile,
logo y-extent (x<300 only), and check ref-navbar-2 for extra context."""
from PIL import Image
import numpy as np

def load(p):
    im = Image.open(p).convert("RGB")
    return np.asarray(im).astype(int)

a = load("/home/z/my-project/qa/ref-navbar-1.png")
H, W, _ = a.shape
r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]

# link white pixels (exclude CTA x>1600, exclude logo x<300)
white = (r > 200) & (g > 200) & (b > 200)
links = white.copy()
links[:, :300] = False
links[:, 1600:] = False
ys, xs = np.where(links)
print(f"LINK white pixels y {ys.min()}..{ys.max()} (cap+descender height {ys.max()-ys.min()+1})")
# histogram of rows
rows_with = links.sum(axis=1)
core = [y for y in range(H) if rows_with[y] > 5]
print("rows with >5 link px:", core[:5], "...", core[-5:])
# vertical center of link ink
print("link ink vertical center:", (ys.min() + ys.max()) / 2)

# logo pink only (x<300)
pink = (r > 180) & (g < 120) & (b < 180)
pink[:, 300:] = False
ys2, xs2 = np.where(pink)
print(f"LOGO pink x {xs2.min()}..{xs2.max()} (w={xs2.max()-xs2.min()+1})  y {ys2.min()}..{ys2.max()} (h={ys2.max()-ys2.min()+1})")

# glow vertical profile at lobe peaks x=760..800 and x=1160, and saddle x=960
def dom(x):
    return r[:, x] - b[:, x] * 0.5
for x in [700, 760, 800, 900, 960, 1050, 1160, 1240]:
    col = dom(x).astype(int)
    print(f"x={x:4d}:", " ".join(f"{col[y]:3d}" for y in range(12, H, 8)))

# horizontal glow profile at the vertical band of links only (y 60..75) to avoid text
print("\nGlow profile sampled y=68 every 20px from 520 to 1360:")
row = (r[68] - b[68] * 0.5).astype(int)
print(" ".join(f"{row[x]:3d}" for x in range(520, 1361, 20)))

# --- second reference image ---
a2 = load("/home/z/my-project/qa/ref-navbar-2.png")
H2, W2, _ = a2.shape
print(f"\nref2: {W2}x{H2}")
r2 = a2[:, :, 0]
# top rows unique colors
for y in [0, 4, 8, 11, 12, 13, 16, 60, 120, 130, 135]:
    if y < H2:
        rowpix = a2[y]
        print(f"ref2 y={y}: left={tuple(rowpix[5])} mid={tuple(rowpix[W2//2])} right={tuple(rowpix[-5])}")
# diff between ref1 and ref2
same = np.array_equal(a, a2)
print("ref1 == ref2 pixel-identical:", same)
if not same:
    d = np.abs(a - a2).sum(axis=2)
    print("diff: max", d.max(), "mean", round(d.mean(), 3), "pixels>10:", int((d > 10).sum()))
