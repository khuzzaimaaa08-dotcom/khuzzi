#!/usr/bin/env bash
# Task 46 — final regression battery
set -u
OUT=/home/z/my-project/qa/work-t46
AB="agent-browser"

echo "=== 1. Desktop 1792x837 re-verify (post-lead) ==="
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "
(() => {
  const how = document.getElementById('how');
  const nd = how.querySelector('.never-done');
  const title = how.querySelector('.never-done-title');
  const T = parseFloat(how.style.height.match(/calc\(([\d.]+)px/)?.[1] || '0');
  window.__top = Math.round(how.getBoundingClientRect().top + scrollY);
  window.__T = T;
  const tr = title.getBoundingClientRect();
  return JSON.stringify({T, lead: nd.style.getPropertyValue('--nd-lead'), titleLeft: tr.left.toFixed(1), docH: document.documentElement.scrollHeight, overflowX: document.documentElement.scrollWidth - innerWidth});
})()
"
$AB eval "window.scrollTo(0, window.__top)" >/dev/null 2>&1; sleep 1.6
$AB screenshot "$OUT/f1-desktop-statement.png" >/dev/null 2>&1
$AB eval "
(() => {
  const t = document.querySelector('.never-done-title').getBoundingClientRect();
  return JSON.stringify({capTopApprox: (t.top + 14).toFixed(1), titleTop: t.top.toFixed(1)});
})()
"

echo "=== 2. OurWork card ratio (regression) ==="
$AB eval "window.scrollTo(0, 0)" >/dev/null 2>&1; sleep 1
$AB eval "
(() => {
  const card = document.querySelector('.work-card');
  const b = card.getBoundingClientRect();
  return JSON.stringify({w: +b.width.toFixed(1), h: +b.height.toFixed(1), ratio: +(b.width/b.height).toFixed(4)});
})()
"

echo "=== 3. Tab switch at settle ==="
$AB eval "window.scrollTo(0, window.__top + window.__T)" >/dev/null 2>&1; sleep 1.5
$AB eval "document.querySelectorAll('[role=tab]')[1].click(); 'clicked estate'" >/dev/null 2>&1
sleep 0.8
$AB eval "
(() => {
  const how = document.getElementById('how');
  const chatHost = [...how.querySelectorAll('figure div')].find(d => (d.className||'').includes('52svh'));
  const vis = chatHost ? [...chatHost.querySelectorAll('p')].filter(p => !p.hidden).length : -1;
  return JSON.stringify({estateVisMsgs: vis, title: document.querySelector('figure p.font-semibold')?.textContent});
})()
"
$AB eval "document.querySelectorAll('[role=tab]')[0].click(); 'back to clinic'" >/dev/null 2>&1; sleep 0.5

echo "=== 4. Deep reload mid-pin ==="
$AB eval "window.scrollTo(0, window.__top + 400)" >/dev/null 2>&1; sleep 1
$AB eval "location.reload()" >/dev/null 2>&1
sleep 5
$AB eval "
(() => {
  const stack = document.querySelector('.chatdemo-stack');
  const nd = document.querySelector('.never-done');
  return JSON.stringify({y: Math.round(scrollY), ty: getComputedStyle(stack).transform, motion: document.getElementById('how').dataset.motion, bg: getComputedStyle(document.getElementById('how')).backgroundColor});
})()
"
$AB screenshot "$OUT/f2-deep-reload-midpin.png" >/dev/null 2>&1

echo "=== 5. Console + page errors ==="
$AB console 2>&1 | rg -v "Fast Refresh|HMR|React DevTools|Download" | head -8
$AB errors 2>&1 | head -5
echo "(empty above = clean)"
