#!/usr/bin/env python3
"""Task 42 pass 4 — precise showreel tile bounds via its white border ring."""
import json
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()

def is_white(x, y):
    r, g, b = px[x, y]
    return r > 225 and g > 232 and b > 238

# scan region right of x=950 for rows containing a long white horizontal run
print("rows with white runs >250px (border top/bottom edges):")
hits = []
for y in range(100, 560):
    run = best = 0
    for x in range(950, W - 2):
        if is_white(x, y):
            run += 1
            best = max(best, run)
        else:
            run = 0
    if best > 250:
        hits.append((y, best))
# cluster
if hits:
    ys = [h[0] for h in hits]
    groups = []
    s = p = ys[0]
    for y in ys[1:]:
        if y - p > 4:
            groups.append((s, p)); s = y
        p = y
    groups.append((s, p))
    print(" white-run row groups:", groups)

# For the topmost group, find the run's x extent
def run_extent(y):
    best = (0, None)
    run = 0; start = None
    for x in range(950, W - 2):
        if is_white(x, y):
            if run == 0: start = x
            run += 1
            if run > best[0]: best = (run, start)
        else:
            run = 0
    return best[1], best[1] + best[0]

if hits:
    top_y = groups[0][0]
    bot_y = groups[-1][1]
    x0a, x1a = run_extent(top_y)
    x0b, x1b = run_extent(bot_y)
    print(f"top edge y={top_y} x=[{x0a},{x1a}] len={x1a-x0a}")
    print(f"bottom edge y={bot_y} x=[{x0b},{x1b}] len={x1b-x0b}")

    # vertical scan at the run's mid x for border thickness + tile height
    xm = (x0a + x1a) // 2
    # find white runs in that column between top and bottom
    vruns = []
    run = 0; start = None
    for y in range(top_y - 5, min(H, bot_y + 15)):
        if is_white(xm, y):
            if run == 0: start = y
            run += 1
        else:
            if run: vruns.append((start, run))
            run = 0
    if run: vruns.append((start, run))
    print(f"vertical white runs at x={xm}: {vruns}")

    # left/right edges: scan a row between top and bottom for long runs
    mid_y = (top_y + bot_y) // 2
    # the border sides: white runs at the far left/right of the tile
    hruns = []
    run = 0; start = None
    for x in range(950, W - 2):
        if is_white(x, mid_y):
            if run == 0: start = x
            run += 1
        else:
            if run > 3: hruns.append((start, run))
            run = 0
    if run > 3: hruns.append((start, run))
    print(f"horizontal white runs at y={mid_y}: {hruns}")

    # summary: tile outer box
    if vruns:
        # the two longest vertical runs = left/right... no, at mid-x they are top/bottom borders
        print("\nTILE OUTER BOX estimate:")
        tx0 = min(x0a, x0b); tx1 = max(x1a, x1b)
        print(f"  x: [{tx0}, {tx1}]  w={tx1-tx0}")
        print(f"  y: [{top_y}, {bot_y}]  h={bot_y-top_y}")
        CARD = (25, 64, 1805, 558)
        cl, ct, cr, cb = CARD
        cw, ch = cr - cl, cb - ct
        print(f"  in-card pct: x0={round((tx0-cl)/cw*100,1)}% x1={round((tx1-cl)/cw*100,1)}% "
              f"y0={round((top_y-ct)/ch*100,1)}% y1={round((bot_y-ct)/ch*100,1)}%")
        print(f"  viewport: right_inset={W-1-tx1}px ({round((W-1-tx1)/W*100,2)}%) bottom_inset={H-1-bot_y}px")
        print(f"  size: {tx1-tx0} x {bot_y-top_y}  ratio={round((tx1-tx0)/(bot_y-top_y),3)}")
