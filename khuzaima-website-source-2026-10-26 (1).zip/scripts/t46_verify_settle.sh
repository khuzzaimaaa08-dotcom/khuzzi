#!/usr/bin/env bash
# Task 46 — verify settle geometry + statement exit at key scroll positions
set -u
AB="agent-browser"

probe() { # $1 = scrollY, $2 = label
  $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1
  sleep 1.6
  echo "=== $2 (y=$1) ==="
  $AB eval "
(() => {
  const how = document.getElementById('how');
  const stack = how.querySelector('.chatdemo-stack');
  const sub = how.querySelector('.never-done-sub');
  const head = document.getElementById('demo-title');
  const grid = how.querySelector('.grid');
  const phone = how.querySelector('figure');
  const steps = how.querySelectorAll('ol li');
  const visMsgs = [...how.querySelectorAll('.grid p')].filter(p => !p.hidden).length;
  const r = el => { const b = el.getBoundingClientRect(); return {t:+b.top.toFixed(1), b:+b.bottom.toFixed(1)}; };
  return JSON.stringify({
    stackY: getComputedStyle(stack).transform,
    sub: r(sub), head: r(head), grid: r(grid), phone: r(phone),
    visMsgs, onSteps: [...steps].filter(s => s.className.includes('border-mint')).length,
    scrollY: Math.round(scrollY)
  });
})()
"
}

probe 11679 "pin-start (statement screen)"
probe 12100 "mid-translate"
probe 12511 "translate-complete (settle)"
probe 13100 "mid-reveals"
probe 14185 "pin-end (end state)"
