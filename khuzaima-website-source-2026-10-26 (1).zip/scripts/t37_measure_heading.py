#!/usr/bin/env python3
"""Precisely locate the giant 'Our work.' heading rows in the reference."""
from PIL import Image

im = Image.open("/home/z/my-project/upload/pasted_image_1792664597584.png").convert("RGB")
W, H = im.size
px = im.load()

# The heading is huge white type on the left; nav links are small.
# Count white pixels per row across left 55%; heading rows will have
# hundreds (glyph strokes), nav rows only dozens.
rows = []
for y in range(0, int(H * 0.55)):
    white = 0
    for x in range(0, int(W * 0.55)):
        r, g, b = px[x, y]
        if r > 215 and g > 215 and b > 215:
            white += 1
    rows.append((y, white))

# Print row ranges where white > 120 (heading-sized)
in_band = False
for y, w in rows:
    if w > 120 and not in_band:
        start = y; in_band = True
    elif w <= 120 and in_band:
        print(f"  white band: y {start}..{y-1}  ({start/H*100:.1f}%..{(y-1)/H*100:.1f}% of {H})")
        in_band = False
if in_band:
    print(f"  white band: y {start}..{len(rows)-1}")
print(f"  image {W}x{H}")
