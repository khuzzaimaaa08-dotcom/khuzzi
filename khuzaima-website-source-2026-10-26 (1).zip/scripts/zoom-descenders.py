#!/usr/bin/env python3
"""Zoom crops of descender-clipping words: ours (live screenshot) vs reference.

Crops the rows for "Check our approach." / "This is Huge." / "Want to join us?"
from our 1920x1080 after screenshot and from the reference image, upscales 4x
with LANCZOS, and stacks them for visual comparison. Also prints ink-row
analysis: does our ink run right up against (and stop at) the mask bottom?
"""
from PIL import Image
import numpy as np

ours = Image.open("/home/z/my-project/qa/after-nav.png").convert("L")
ref = Image.open("/home/z/my-project/upload/pasted_image_1792477162472.png").convert("L")

# nav coords from browser: x1273 y462 w279 h222 (dpr1). Row height 27 + 12 gap = 39.
# rows: 0 See the work / 1 Discover / 2 Check our approach / 3 Latest / 4 This is Huge / 5 Want to join us
NAV_X, NAV_Y, NAV_W = 1268, 455, 295

def crop_row(img, y, h, x=NAV_X, w=NAV_W):
    return img.crop((x, y, x + w, y + h))

# ours rows start at 462 (link top). row i top = 462 + i*39
targets = {2: "approach", 4: "Huge", 5: "join"}

def ink_rows(crop):
    a = np.array(crop)
    d = a < 128
    rows = np.where(d.any(axis=1))[0]
    return (int(rows.min()), int(rows.max())) if len(rows) else (None, None)

print("=== OURS (mask height 27px per row) ===")
for i, name in targets.items():
    y = 462 + i * 39
    c = crop_row(ours, y, 39)  # full row incl gap below
    top, bot = ink_rows(c)
    print(f"row {name}: ink rows {top}..{bot} of 39px row (mask ends at 27) -> "
          f"{'CLIPPED (ink touches 26-27 and stops)' if bot in (26, 27) else 'ink bottom ' + str(bot)}")
    c.resize((c.width * 4, c.height * 4), Image.LANCZOS).save(f"/home/z/my-project/qa/zoom-ours-{name}.png")

# reference: text bbox (excluding dark bar) then split 6 rows by whitespace bands
a = np.array(ref)
d = a < 128
col_frac = d.mean(axis=0)
d[:, col_frac > 0.7] = False
rows = np.where(d.any(axis=1))[0]
cols = np.where(d.any(axis=0))[0]
ref_t = ref.crop((cols.min(), rows.min(), cols.max() + 1, rows.max() + 1))
ra = np.array(ref_t)
rd = ra < 128
row_has = rd.any(axis=1)
# find text bands (contiguous runs of True with gaps)
bands, start = [], None
for y, v in enumerate(row_has):
    if v and start is None: start = y
    elif not v and start is not None: bands.append((start, y)); start = None
if start is not None: bands.append((start, len(row_has)))
print(f"\n=== REFERENCE: {len(bands)} text bands ===")
names = ["work", "solutions", "approach", "news", "Huge", "join"]
for (b0, b1), name in zip(bands, names):
    c = ref_t.crop((0, b0, ref_t.width, b1))
    h = b1 - b0
    print(f"band {name}: height {h}px")
    c.resize((c.width * 3, h * 3), Image.LANCZOS).save(f"/home/z/my-project/qa/zoom-ref-{name}.png")

# side-by-side: our approach row vs ref approach band (matched height scale)
our_ap = crop_row(ours, 462 + 2 * 39, 39)
ref_ap = ref_t.crop((0, bands[2][0], ref_t.width, bands[2][1]))
s = 39 / (bands[2][1] - bands[2][0])
ref_ap_s = ref_ap.resize((int(ref_ap.width * s), 39), Image.LANCZOS)
comp = Image.new("RGB", (our_ap.width + ref_ap_s.width + 60, 159), "white")
comp.paste(our_ap, (20, 20)); comp.paste(ref_ap_s, (our_ap.width + 40, 20))
comp.save("/home/z/my-project/qa/zoom-approach-ours-vs-ref.png")
print("\nsaved zoom crops: qa/zoom-ours-*.png qa/zoom-ref-*.png qa/zoom-approach-ours-vs-ref.png")
