#!/usr/bin/env python3
"""Process all 8 brand logos into uniform monochrome-ink PNGs for the wall.

Treatment: luminance-mapped monochrome — dark pixels become ink (#0D0B0A)
with alpha proportional to darkness, light pixels become transparent. This is
the standard agency client-wall treatment: preserves every logo's exact
letterforms/geometry while matching the reference's restrained
black-on-warm-white presentation.
"""
from PIL import Image, ImageOps
import numpy as np
import os, io, cairosvg

os.chdir("/tmp/pkbrands")
OUT = "/home/z/my-project/public/brands"
os.makedirs(OUT, exist_ok=True)
INK = np.array([13, 11, 10], dtype=np.float32)  # site ink #0D0B0A

def to_mono_ink(img: Image, name: str, invert: bool = False, trim: bool = True):
    """Map luminance -> ink-on-transparent. dark->opaque ink, light->transparent."""
    img = img.convert("RGBA")
    if trim:
        bbox = img.getbbox()
        if bbox:
            img = img.crop(bbox)
    a = np.array(img).astype(np.float32)
    rgb, alpha = a[:, :, :3], a[:, :, 3]
    lum = (0.2126 * rgb[:, :, 0] + 0.7152 * rgb[:, :, 1] + 0.0722 * rgb[:, :, 2]) / 255.0
    if invert:
        lum = 1.0 - lum
    # opacity = how dark the pixel is, scaled by original alpha
    opacity = np.clip((0.82 - lum) / 0.82, 0, 1) * (alpha / 255.0)
    out = np.zeros_like(a)
    out[:, :, 0], out[:, :, 1], out[:, :, 2] = INK
    out[:, :, 3] = opacity * 255
    res = Image.fromarray(out.astype(np.uint8), "RGBA")
    res.save(f"{OUT}/{name}.png")
    print(f"{name}: {res.size[0]}x{res.size[1]} ratio={res.size[0]/res.size[1]:.2f}")

# 1. HBL — SVG teal wordmark
png = cairosvg.svg2png(url="cand-hbl2-1.svg", output_width=1400)
to_mono_ink(Image.open(io.BytesIO(png)), "hbl")

# 2. Meezan — Commons horizontal lockup (already transparent bg)
to_mono_ink(Image.open("meezan-wiki.png"), "meezan")

# 3. Jazz — crop badge from OG image, then flood-remove light bg
og = Image.open("jazz-logo-official.png").convert("RGB")
a = np.array(og)
# red circle mask: strong red channel, low green
red = (a[:, :, 0] > 120) & (a[:, :, 1] < 110) & (a[:, :, 2] < 120)
rows = np.where(red.any(axis=1))[0]
cols = np.where(red.any(axis=0))[0]
x0, x1, y0, y1 = cols.min(), cols.max(), rows.min(), rows.max()
print("jazz badge bbox:", x0, x1, y0, y1)
# pad to include trailing dots that hug the circle
pad = 8
crop = og.crop((max(0, x0 - pad), max(0, y0 - pad), min(og.width, x1 + pad), min(og.height, y1 + pad)))
crop.save("jazz-crop.png")
to_mono_ink(crop, "jazz")

# 4. Khaadi — crop wordmark from Commons 2022 jpg
kh = Image.open("khaadi-2022.jpg")
khc = kh.crop((69 - 6, 259 - 6, 889 + 6, 418 + 6))
to_mono_ink(khc, "khaadi")

# 5. Sapphire — app-store wordmark (black on white)
to_mono_ink(Image.open("sapphire-hires.png"), "sapphire")

# 6. Shan — Commons transparent script
to_mono_ink(Image.open("shan-500.png"), "shan")

# 7. Systems — official SVG (navy + orange dot)
png = cairosvg.svg2png(url="systems-01.svg", output_width=1600)
to_mono_ink(Image.open(io.BytesIO(png)), "systems")

# 8. Bank Alfalah — check content first, then process
alf = Image.open("cand-alfalah-2.png").convert("RGBA")
to_mono_ink(alf, "alfalah")

print("\nAll saved to", OUT)
