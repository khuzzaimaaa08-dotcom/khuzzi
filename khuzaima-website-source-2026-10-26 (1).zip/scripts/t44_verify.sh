#!/bin/bash
# Task 44 — "Our work" card aspect-ratio fix: viewport sweep verification.
# Geometry is measured at PIN START (progress 0) via a native jump (Lenis
# rewinds it, which lands us exactly at the start of the pin — ideal).
# Mid-scrub is verified separately with real wheel events (Lenis-native).

PORT=3000
BASE="http://localhost:$PORT"

measure_at_pin_start() { # $1=w $2=h
  agent-browser set viewport "$1" "$2" >/dev/null 2>&1
  agent-browser open "$BASE/?v=$1x$2" >/dev/null 2>&1
  agent-browser wait --load networkidle >/dev/null 2>&1
  sleep 1.5
  agent-browser eval "(() => {
    const stage = document.querySelector('.work-stage');
    const top = stage.getBoundingClientRect().top + scrollY;
    scrollTo(0, top + 40); // jump; Lenis rewinds to pin start and holds there
    return new Promise(r => setTimeout(() => {
      const d = document.scrollingElement;
      const card = document.querySelector('.work-card');
      const cr = card.getBoundingClientRect();
      const text = card.querySelector('.work-card__text').getBoundingClientRect();
      const title = card.querySelector('.work-card__title');
      const sub = card.querySelector('.work-card__sub');
      const tr = title.getBoundingClientRect();
      const h = document.getElementById('our-work-title');
      const hr = h.getBoundingClientRect();
      const section = document.querySelector('.our-work');
      const st = document.querySelector('.work-stage').getBoundingClientRect();
      r(JSON.stringify({
        vp: innerWidth + 'x' + innerHeight,
        ratio: {w: +cr.width.toFixed(1), h: +cr.height.toFixed(1), r: +(cr.width/cr.height).toFixed(4)},
        bottomGap: +(innerHeight - cr.bottom).toFixed(1),
        headTextTop: +hr.top.toFixed(1),
        headPad: getComputedStyle(h).paddingTop,
        bgAtPin: getComputedStyle(section).backgroundColor,
        hOverflow: d.scrollWidth - d.clientWidth,
        textFits: tr.top >= cr.top - 0.5 && text.bottom <= cr.bottom + 0.5 && text.left >= cr.left - 0.5 && text.right <= cr.right + 0.5,
        textBottomPad: +(cr.bottom - text.bottom).toFixed(1),
        titleFont: getComputedStyle(title).fontSize,
        stageTop: +st.top.toFixed(1),
        pinned: getComputedStyle(document.querySelector('.work-stage')).position
      }));
    }, 2500));
  })()" 2>&1
}

echo "===== 1900x700 (user viewport, short — heading crops) ====="
measure_at_pin_start 1900 700
echo "===== 1900x900 (user width, normal height) ====="
measure_at_pin_start 1900 900
echo "===== 1440x800 ====="
measure_at_pin_start 1440 800
echo "===== 1225x800 (reference metrics: 1185x330.35) ====="
measure_at_pin_start 1225 800
echo "===== 1024x768 (theme lead engages) ====="
measure_at_pin_start 1024 768
echo "===== 2560x1440 (ultrawide, lead engages) ====="
measure_at_pin_start 2560 1440
echo "===== 768x1024 (tablet 16/10) ====="
measure_at_pin_start 768 1024
echo "===== 390x844 (mobile 4/5) ====="
measure_at_pin_start 390 844
