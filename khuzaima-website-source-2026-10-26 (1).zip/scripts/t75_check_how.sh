#!/usr/bin/env bash
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
echo "=== console errors ==="
$AB errors 2>/dev/null | head -20
echo "=== geometry at how settle ==="
$AB eval "window.scrollTo(0, 11679)" >/dev/null 2>&1; sleep 2
$AB eval "
(() => {
  const how = document.getElementById('how');
  const stack = how.querySelector('.chatdemo-stack');
  const h2 = how.querySelector('#demo-title');
  const body = stack.querySelector('.container-site');
  const T = parseFloat(how.style.height.match(/calc\(([\d.]+)px/)?.[1] || '0');
  const r1 = h2.getBoundingClientRect();
  return JSON.stringify({secH: how.offsetHeight, T, stackY: getComputedStyle(stack).transform, h2Top: +r1.top.toFixed(1), h2H: +r1.height.toFixed(1), bodyTop: +body.getBoundingClientRect().top.toFixed(1)});
})()
"
$AB eval "window.scrollTo(0, 11679 + 850)" >/dev/null 2>&1; sleep 2.5
$AB eval "
(() => {
  const how = document.getElementById('how');
  const stack = how.querySelector('.chatdemo-stack');
  const h2 = how.querySelector('#demo-title');
  const r1 = h2.getBoundingClientRect();
  return JSON.stringify({y: scrollY, stackY: getComputedStyle(stack).transform, h2Top: +r1.top.toFixed(1), h2H: +r1.height.toFixed(1)});
})()
"
$AB screenshot "$OUT/x01-how-settle.png" >/dev/null 2>&1
echo "=== console errors after ==="
$AB errors 2>/dev/null | head -20
