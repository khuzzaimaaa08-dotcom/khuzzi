#!/usr/bin/env bash
# Task 46 — full journey screenshots at 1792x837
set -u
OUT=/home/z/my-project/qa/work-t46
mkdir -p "$OUT"
AB="agent-browser"

$AB open http://localhost:3000 >/dev/null 2>&1
$AB set viewport 1792 837 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3

shot() { # $1 = scrollY, $2 = name, $3 = settle seconds
  $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1
  sleep "${3:-1.5}"
  $AB screenshot "$OUT/$2.png" >/dev/null 2>&1
  echo "captured $2 @ y=$1"
}

# A — before OurWork (brands/hero zones unchanged)
shot 1500  n01-pre-work-hero
shot 5200  n02-pre-work-brands
# B — OurWork section unchanged
shot 8500  n03-work-midpin
shot 11399 n04-work-pin-end
# C — junction + entry + pin + translate
shot 11750 n05-junction-card-swipe
shot 12150 n06-statement-entering
shot 11679 n07-pin-start-statement-screen
shot 12040 n08-mid-translate
shot 12490 n09-translate-done-1142-settled
# D — reveal experience continues + end state
shot 13000 n10-mid-reveals
shot 13600 n11-late-reveals
shot 14161 n12-end-state
shot 14400 n13-after-release
# E — scroll back upward (reversal)
shot 13000 n14-back-mid
shot 12040 n15-back-mid-translate
shot 11679 n16-back-pin-start
shot 11200 n17-back-junction
echo "done"
