#!/usr/bin/env bash
# Task 46 — measure the integrated ChatDemo geometry at 1792x837
set -u
AB="agent-browser"
$AB open http://localhost:3000 >/dev/null 2>&1
$AB set viewport 1792 837 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 2.5

echo "=== page + section metrics ==="
$AB eval "
(() => {
  const how = document.getElementById('how');
  const screen = how.querySelector('.chatdemo-screen');
  const stack = how.querySelector('.chatdemo-stack');
  const nd = how.querySelector('.never-done');
  const title = how.querySelector('.never-done-title');
  const sub = how.querySelector('.never-done-sub');
  const body = how.querySelector('.container-site');
  const head = document.getElementById('demo-title');
  const grid = how.querySelector('.grid');
  const r = el => { const b = el.getBoundingClientRect(); return {t:+b.top.toFixed(1), b:+b.bottom.toFixed(1), l:+b.left.toFixed(1), r:+b.right.toFixed(1), w:+b.width.toFixed(1), h:+b.height.toFixed(1)}; };
  const cs = getComputedStyle(title);
  const csSub = getComputedStyle(sub);
  return JSON.stringify({
    docH: document.documentElement.scrollHeight,
    sectionTop: Math.round(how.getBoundingClientRect().top + scrollY),
    sectionH: how.offsetHeight,
    inlineH: how.style.height,
    screenH: screen.offsetHeight,
    stackH: stack.offsetHeight,
    stackY: getComputedStyle(stack).transform,
    nd: r(nd), title: r(title), sub: r(sub), body: r(body), head: r(head), grid: r(grid),
    type: {ff: cs.fontFamily.split(',')[0], fs: cs.fontSize, lh: cs.lineHeight, ls: cs.letterSpacing, fw: cs.fontWeight, col: cs.color},
    subType: {fs: csSub.fontSize, lh: csSub.lineHeight, ls: csSub.letterSpacing},
    bg: getComputedStyle(how).backgroundColor
  }, null, 1);
})()
"
