#!/usr/bin/env python3
"""Task 42 — polish pass: flat card blue (no highlight), hand-placed gold
confetti at the measured reference positions, pill triangle bump."""

from pathlib import Path

p = Path("/home/z/my-project/src/app/globals.css")
t = p.read_text()

# 1. card background: flat blue + right vignette only (new reference has no
#    center-left highlight — left 2/3 measured flat #2578E4 everywhere)
old_bg = """  background:
    radial-gradient(88% 125% at 88% 55%, rgb(4 40 94 / 0.92), transparent 62%),
    radial-gradient(72% 95% at 28% 38%, rgb(110 165 255 / 0.32), transparent 60%),
    linear-gradient(160deg, #2f7eec 0%, #2878e8 46%, #1f63da 100%);"""
new_bg = """  background:
    radial-gradient(88% 125% at 88% 55%, rgb(4 40 94 / 0.92), transparent 62%),
    linear-gradient(160deg, #2a7ce9 0%, #2577e4 50%, #1f63da 100%);"""
assert old_bg in t
t = t.replace(old_bg, new_bg, 1)

# 2. gold confetti: hand-placed dots at the measured reference spots
#    (x %W, y %H) — no repeating grid, so no moiré columns.
old_conf = """  background-image:
    radial-gradient(circle, rgb(255 216 112 / 0.95) 0 2.1px, transparent 3.2px),
    radial-gradient(circle, rgb(240 200 92 / 0.85) 0 1.7px, transparent 2.7px),
    radial-gradient(circle, rgb(255 236 170 / 0.95) 0 3px, transparent 5px),
    radial-gradient(circle, rgb(222 172 60 / 0.75) 0 1.4px, transparent 2.3px),
    radial-gradient(circle, rgb(255 222 130 / 0.5) 0 5px, transparent 8px);
  background-size: 3.7cqw 2.3cqh, 2.9cqw 3.1cqh, 6.3cqw 4.4cqh, 4.4cqw 6.1cqh, 10.7cqw 7.6cqh;
  background-position: 0 0, 1.7cqw 0.9cqh, 3.1cqw 1.6cqh, 0.8cqw 3.4cqh, 5.2cqw 2.6cqh;"""
new_conf = """  background-image:
    radial-gradient(circle, rgb(255 219 116 / 0.95) 0 2.3px, transparent 3.5px),
    radial-gradient(circle, rgb(240 200 92 / 0.9) 0 1.5px, transparent 2.5px),
    radial-gradient(circle, rgb(255 232 156 / 0.95) 0 1.8px, transparent 2.9px),
    radial-gradient(circle, rgb(222 172 60 / 0.8) 0 1px, transparent 1.8px),
    radial-gradient(circle, rgb(255 219 116 / 0.95) 0 2.5px, transparent 3.9px),
    radial-gradient(circle, rgb(240 200 92 / 0.9) 0 1.3px, transparent 2.2px),
    radial-gradient(circle, rgb(255 232 156 / 0.9) 0 1px, transparent 1.8px),
    radial-gradient(circle, rgb(255 219 116 / 0.95) 0 2.8px, transparent 4.3px),
    radial-gradient(circle, rgb(255 232 156 / 0.95) 0 2.2px, transparent 3.4px),
    radial-gradient(circle, rgb(240 200 92 / 0.85) 0 1px, transparent 1.8px),
    radial-gradient(circle, rgb(255 219 116 / 0.9) 0 1.8px, transparent 2.8px),
    radial-gradient(circle, rgb(222 172 60 / 0.8) 0 1.3px, transparent 2.2px),
    radial-gradient(circle, rgb(255 232 156 / 0.95) 0 1.8px, transparent 2.8px),
    radial-gradient(circle, rgb(255 219 116 / 0.95) 0 1.8px, transparent 2.8px),
    radial-gradient(circle, rgb(240 200 92 / 0.9) 0 2px, transparent 3.1px),
    radial-gradient(circle, rgb(255 232 156 / 0.95) 0 2px, transparent 3.1px),
    radial-gradient(circle, rgb(255 219 116 / 0.95) 0 2.3px, transparent 3.5px),
    radial-gradient(circle, rgb(240 200 92 / 0.9) 0 1.8px, transparent 2.8px),
    radial-gradient(circle, rgb(222 172 60 / 0.8) 0 1.3px, transparent 2.1px),
    radial-gradient(circle, rgb(255 232 156 / 0.9) 0 1.5px, transparent 2.4px),
    radial-gradient(circle, rgb(255 219 116 / 0.95) 0 1.8px, transparent 2.8px),
    radial-gradient(circle, rgb(240 200 92 / 0.85) 0 1px, transparent 1.7px),
    radial-gradient(circle, rgb(255 232 156 / 0.9) 0 1.5px, transparent 2.4px);
  background-repeat: no-repeat;
  background-size: 10px 10px;
  background-position:
    52.7cqw 8.5cqh, 52.3cqw 10cqh, 53.1cqw 9.3cqh, 54.9cqw 10.3cqh,
    53.1cqw 12.5cqh, 52.5cqw 12.4cqh, 55.8cqw 20.6cqh,
    71.5cqw 31.6cqh, 72cqw 32.8cqh, 71.6cqw 33.4cqh, 71.5cqw 39.5cqh, 71.1cqw 38.9cqh,
    57.8cqw 57.9cqh, 57cqw 58.5cqh, 58.3cqw 59.3cqh, 59.2cqw 58.7cqh,
    57.4cqw 60.6cqh, 59.5cqw 60.7cqh, 56.8cqw 60.5cqh, 58.4cqw 61.2cqh,
    55.2cqw 69.1cqh, 55.9cqw 73.4cqh, 57cqw 74.7cqh;"""
assert old_conf in t
t = t.replace(old_conf, new_conf, 1)

# 3. pill: play triangle slightly larger (reference ~60-70% of text height)
old_pi = """.showreel-pill .sr-play { width: 3.7cqw; height: 4.4cqh; flex: none; }"""
new_pi = """.showreel-pill .sr-play { width: 4cqw; height: 5.4cqh; flex: none; }"""
assert old_pi in t
t = t.replace(old_pi, new_pi, 1)

p.write_text(t)
print("polish applied")
