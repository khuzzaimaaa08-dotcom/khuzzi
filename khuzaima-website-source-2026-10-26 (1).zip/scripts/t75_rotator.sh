#!/usr/bin/env bash
set -u
OUT=/home/z/my-project/qa/t75
AB="agent-browser"
$AB set viewport 1792 837 >/dev/null 2>&1
$AB open http://localhost:3000 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 3
$AB eval "window.scrollTo(0, 3350)" >/dev/null 2>&1; sleep 2
for i in 1 2 3 4 5 6; do
  $AB screenshot "$OUT/r0$i-rotator.png" >/dev/null 2>&1
  sleep 0.45
done
