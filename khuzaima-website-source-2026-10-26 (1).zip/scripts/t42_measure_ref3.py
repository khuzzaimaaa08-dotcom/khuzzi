#!/usr/bin/env python3
"""Task 42 pass 3 — ASCII maps + precise line profiles + color modes."""
import json
from collections import Counter
from PIL import Image

img = Image.open("/home/z/my-project/upload/pasted_image_1792673315484.png").convert("RGB")
W, H = img.size
px = img.load()
CARD = (25, 64, 1805, 558)
cl, ct, cr, cb = CARD
cw, ch = cr - cl, cb - ct

# ── ASCII map of the card: classify each cell ─────────────────────────────
COLS, ROWS = 110, 26
def classify(x0, x1, y0, y1):
    counts = Counter()
    for y in range(y0, y1, 2):
        for x in range(x0, x1, 2):
            r, g, b = px[x, y]
            if r > 225 and g > 232 and b > 238: counts["W"] += 1        # white (text/UI)
            elif b > 195 and 130 < r < 230 and 150 < g < 240 and b - r > 30: counts["P"] += 1  # pale blue text
            elif r > 185 and g < 140 and 70 < b < 210 and r - g > 80: counts["K"] += 1  # pink
            elif r < 45 and g < 45 and b < 45: counts["k"] += 1          # near black
            elif r > 170 and g > 130 and b < 140 and r - b > 60: counts["G"] += 1  # gold
            elif b > 110 and b - r > 55 and g < 175: counts["."] += 1    # card blue
            elif r > 200 and g > 185 and b > 150 and r - b > 40: counts["c"] += 1  # cream/light
            else: counts["?"] += 1
    return counts.most_common(1)[0][0] if counts else " "

print("CARD ASCII MAP (rows = card height, cols = card width):")
print("legend: .=blue W=white P=paleblue K=pink k=black G=gold c=cream ?=other")
for j in range(ROWS):
    line = ""
    for i in range(COLS):
        x0 = cl + int(cw * i / COLS); x1 = cl + int(cw * (i + 1) / COLS)
        y0 = ct + int(ch * j / ROWS); y1 = ct + int(ch * (j + 1) / ROWS)
        line += classify(x0, x1, y0, y1)
    print(f"{j*ch/ROWS:5.0f} {line}")

# ── row profile: white / paleblue / gold / pink counts per row ────────────
print("\nROW PROFILE (every 4th row): y_in_card  white  paleblue  gold  pink")
for y in range(ct, cb, 4):
    w_cnt = p_cnt = g_cnt = k_cnt = 0
    for x in range(cl, cr, 2):
        r, g, b = px[x, y]
        if r > 228 and g > 234 and b > 240: w_cnt += 1
        elif b > 195 and 130 < r < 230 and 150 < g < 240 and b - r > 30: p_cnt += 1
        elif r > 170 and g > 130 and b < 140 and r - b > 60: g_cnt += 1
        elif r > 185 and g < 140 and 70 < b < 210 and r - g > 80: k_cnt += 1
    print(f"{y-ct:6d}  {w_cnt:5d}  {p_cnt:6d}  {g_cnt:5d}  {k_cnt:5d}")

# ── headline glyph color mode (tight region: left 55%, y 200-470) ─────────
colors = Counter()
for y in range(ct + 200, ct + 470):
    for x in range(cl + 40, cl + int(cw * 0.55)):
        r, g, b = px[x, y]
        if b > 195 and 130 < r < 230 and 150 < g < 240 and b - r > 30:
            colors[(r, g, b)] += 1
top = colors.most_common(8)
print("\nHEADLINE GLYPH COLOR MODES:", json.dumps([[*c[0], c[1]] for c in top]))

# NBCU white glyph check
wcolors = Counter()
for y in range(ct + 131, ct + 190):
    for x in range(cl + 40, cl + int(cw * 0.3)):
        r, g, b = px[x, y]
        if r > 228 and g > 234 and b > 240:
            wcolors[(r, g, b)] += 1
print("NBCU WHITE MODES:", json.dumps([[*c[0], c[1]] for c in wcolors.most_common(4)]))

# ── showreel tile precise: find its white border rectangle ────────────────
# pink region: [1003,111,1801,523]. The tile should have a white border ring.
# Scan row bands inside pink region for horizontal white runs
print("\nSHOWREEL WHITE-RUN SCAN (rows inside pink region):")
for y in range(105, 530, 25):
    runs = []
    inrun = None
    for x in range(995, W - 2):
        r, g, b = px[x, y]
        white = r > 228 and g > 234 and b > 240
        if white and inrun is None: inrun = x
        elif not white and inrun is not None:
            if x - inrun > 30: runs.append((inrun, x))
            inrun = None
    if inrun is not None and W - 2 - inrun > 30: runs.append((inrun, W - 2))
    if runs:
        print(f" y={y}: {runs}")
