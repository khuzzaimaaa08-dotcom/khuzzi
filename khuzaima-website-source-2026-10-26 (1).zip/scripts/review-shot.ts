import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

// Usage: bun scripts/review-shot.ts <file.png> <question>
async function main() {
  const [file, question] = process.argv.slice(2);
  if (!file) { console.error('usage: review-shot.ts <file.png> [question]'); process.exit(1); }
  const zai = await ZAI.create();
  const b64 = fs.readFileSync(file).toString('base64');
  const res = await zai.chat.completions.createVision({
    thinking: { type: 'disabled' },
    messages: [
      { role: 'system', content: 'You are a meticulous visual QA reviewer for a marketing website hero scene. Describe precisely what you see. Be concrete about shapes, colors and positions.' },
      {
        role: 'user',
        content: [
          { type: 'text', text: question || 'Describe the visual state of this hero: background, any aurora, snow, trees, sparkles, stray shapes, and any visual problems.' },
          { type: 'image_url', image_url: { url: `data:image/png;base64,${b64}` } },
        ],
      },
    ],
  });
  console.log(res.choices[0]?.message?.content || '(no response)');
}
main().catch(e => { console.error(e); process.exit(1); });
