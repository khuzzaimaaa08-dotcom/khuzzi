#!/usr/bin/env python3
"""Analyze the reference image: pink color sampling + text line layout."""
from PIL import Image
from collections import Counter

img = Image.open("/home/z/my-project/upload/pasted_image_1792417586109.png").convert("RGB")
W, H = img.size
px = img.load()
print(f"image size: {W}x{H}")

# --- 1. Pink pixel sampling (magenta-ish: high R, low G, B mid-high) ---
pinks = Counter()
pink_rows = []
pink_cols = []
for y in range(H):
    for x in range(W):
        r, g, b = px[x, y]
        if r > 180 and g < 130 and b > 90 and b < 220 and (r - g) > 80:
            pinks[(r // 8 * 8, g // 8 * 8, b // 8 * 8)] += 1
            pink_rows.append(y)
            pink_cols.append(x)

total_pink = sum(pinks.values())
print(f"pink-ish pixels: {total_pink}")
for color, n in pinks.most_common(6):
    print(f"  pink cluster ~ rgb{color}  x{n}")

# exact average of pink pixels
if total_pink:
    # re-accumulate exact sums
    sr = sg = sb = 0
    for y in range(H):
        for x in range(W):
            r, g, b = px[x, y]
            if r > 180 and g < 130 and b > 90 and b < 220 and (r - g) > 80:
                sr += r; sg += g; sb += b
    print(f"  avg pink: rgb({sr//total_pink},{sg//total_pink},{sb//total_pink})")
    print(f"  pink bbox: x [{min(pink_cols)},{max(pink_cols)}]  y [{min(pink_rows)},{max(pink_rows)}]")

# --- 2. Dark (black text) pixel projection per row -> find text lines ---
dark_rows = []
for y in range(H):
    cnt = 0
    for x in range(W):
        r, g, b = px[x, y]
        if r < 90 and g < 90 and b < 90:
            cnt += 1
    if cnt > 3:
        dark_rows.append(y)

# group contiguous rows into lines
lines = []
if dark_rows:
    start = prev = dark_rows[0]
    for y in dark_rows[1:]:
        if y - prev > 4:
            lines.append((start, prev))
            start = y
        prev = y
    lines.append((start, prev))

print(f"\ndark text lines found: {len(lines)}")
for i, (a, b) in enumerate(lines):
    # column extent of dark pixels within this line band
    xs = [x for y in range(a, b + 1) for x in range(W)
          if px[x, y][0] < 90 and px[x, y][1] < 90 and px[x, y][2] < 90]
    print(f"  line {i+1}: y {a}-{b} (h={b-a+1})  x {min(xs)}-{max(xs)}")

# top black bar check
bar_rows = [y for y in range(H) if sum(1 for x in range(0, W, 8) if px[x, y][0] < 60) > (W // 8) * 0.8]
if bar_rows:
    print(f"\nblack top bar rows: {min(bar_rows)}-{max(bar_rows)}")

# pink rows grouped -> which text line contains the pink word
if total_pink:
    plines = []
    s = p = sorted(set(pink_rows))[0]
    for y in sorted(set(pink_rows))[1:]:
        if y - p > 4:
            plines.append((s, p)); s = y
        p = y
    plines.append((s, p))
    print(f"\npink bands: {plines}")
