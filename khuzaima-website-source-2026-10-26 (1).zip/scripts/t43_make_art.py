#!/usr/bin/env python3
"""Task 43 - placeholder case-study art for the "Our work." slider.

Generates 12 SVGs (4 placeholder clients x desktop/tablet/mobile) into
public/work/. Art = brand-gradient canvases with simple geometry, kept
calm toward the bottom-left where the card text overlays. All geometry is
computed from the canvas size, so each breakpoint variant recomposes.

TODO(content): replace with real case imagery when content lands - the
data module (src/components/site/our-work-cases.ts) points at these files.
"""
from pathlib import Path

OUT = Path("/home/z/my-project/public/work")
OUT.mkdir(parents=True, exist_ok=True)

INK = "13 11 10"          # --ink, rgb triplet for SVG color syntax
WHITE = "255 255 255"

# (slug, top-right color, bottom-left color, motif key)
# Gradient runs top-right -> bottom-left so the deepest shade sits under
# the bottom-left text block (white text cards) / the lightest calm zone
# sits there (ink text cards).
CARDS = [
    ("aster",      "#FAF5EA", "#ECE2CF", "ripples"),    # light  (ink text)
    ("northfield", "#4A41E6", "#1E179F", "network"),    # ultramarine (white)
    ("halcyon",    "#E4572E", "#8E2B0B", "ribbons"),    # coral  (white)
    ("meridian",   "#BAF0D4", "#87D9AE", "rays"),       # mint   (ink text)
]

SIZES = {"desktop": (2370, 661), "tablet": (1280, 800), "mobile": (800, 1000)}

# Northfield constellation: node positions (fractions of w/h) + edges.
NODES = [
    (0.16, 0.34), (0.27, 0.68), (0.38, 0.24), (0.47, 0.56), (0.56, 0.30),
    (0.64, 0.66), (0.72, 0.38), (0.80, 0.18), (0.87, 0.58), (0.55, 0.84),
    (0.33, 0.86), (0.91, 0.34), (0.68, 0.10), (0.44, 0.90),
]
EDGES = [(0, 1), (0, 3), (2, 3), (3, 4), (3, 5), (4, 6), (6, 7), (6, 11),
         (5, 8), (5, 9), (9, 13), (1, 10), (10, 13), (7, 12), (11, 8)]
HIGHLIGHT = [(0, 3), (3, 5), (5, 9)]  # the "featured route"


def f(v: float) -> str:
    return f"{v:.1f}".rstrip("0").rstrip(".")


def gradient(gid: str, c1: str, c2: str) -> str:
    return (
        f'<defs><linearGradient id="{gid}" x1="1" y1="0" x2="0" y2="1">'
        f'<stop offset="0" stop-color="{c1}"/>'
        f'<stop offset="1" stop-color="{c2}"/>'
        f"</linearGradient></defs>"
    )


def motif_ripples(w: float, h: float) -> str:
    u = min(w, h)
    cx, cy = w * 0.78, h * 0.42
    out = []
    for r, a in ((0.10, 0.16), (0.16, 0.12), (0.225, 0.09), (0.30, 0.06)):
        out.append(
            f'<circle cx="{f(cx)}" cy="{f(cy)}" r="{f(u * r)}" fill="none" '
            f'stroke="rgb({INK} / {a})" stroke-width="{f(max(1.5, u * 0.004))}"/>'
        )
    out.append(
        f'<circle cx="{f(w * 0.885)}" cy="{f(h * 0.32)}" r="{f(u * 0.013)}" '
        f'fill="rgb({INK} / 0.38)"/>'
    )
    out.append(
        f'<line x1="0" y1="{f(h * 0.12)}" x2="{f(w)}" y2="{f(h * 0.12)}" '
        f'stroke="rgb({INK} / 0.06)" stroke-width="{f(max(1.5, u * 0.0035))}"/>'
    )
    return "".join(out)


def motif_network(w: float, h: float) -> str:
    u = min(w, h)
    pts = [(x * w, y * h) for x, y in NODES]
    out = []
    for a, b in EDGES:
        alpha = 0.42 if (a, b) in HIGHLIGHT else 0.15
        width = max(2.5, u * 0.007) if (a, b) in HIGHLIGHT else max(1.4, u * 0.004)
        out.append(
            f'<line x1="{f(pts[a][0])}" y1="{f(pts[a][1])}" '
            f'x2="{f(pts[b][0])}" y2="{f(pts[b][1])}" '
            f'stroke="rgb({WHITE} / {alpha})" stroke-width="{f(width)}"/>'
        )
    for i, (x, y) in enumerate(pts):
        big = i in (0, 3, 5, 9)
        r = u * (0.008 if big else 0.005)
        out.append(
            f'<circle cx="{f(x)}" cy="{f(y)}" r="{f(r)}" '
            f'fill="rgb({WHITE} / {0.85 if big else 0.4})"/>'
        )
    return "".join(out)


def motif_ribbons(w: float, h: float) -> str:
    u = min(w, h)
    out = []
    for dy, a, sw in ((0.30, 0.13, 0.045), (0.52, 0.09, 0.065), (0.70, 0.16, 0.03)):
        y0, y1, y2 = h * dy, h * (dy + 0.16), h * (dy - 0.10)
        out.append(
            f'<path d="M {f(-w * 0.05)} {f(y0)} C {f(w * 0.30)} {f(y1)}, '
            f'{f(w * 0.55)} {f(y2)}, {f(w * 1.05)} {f(h * (dy + 0.06))}" '
            f'fill="none" stroke="rgb({WHITE} / {a})" '
            f'stroke-width="{f(u * sw)}" stroke-linecap="round"/>'
        )
    out.append(
        f'<circle cx="{f(w * 0.84)}" cy="{f(h * 0.22)}" r="{f(u * 0.16)}" '
        f'fill="rgb(255 194 158 / 0.28)"/>'
    )
    return "".join(out)


def motif_rays(w: float, h: float) -> str:
    u = min(w, h)
    cx, cy = w * 1.02, h * 1.04  # fan origin just past the bottom-right corner
    out = []
    import math
    for i in range(9):
        ang = math.pi + math.pi * (0.52 + i * 0.055)  # rays sweeping up-left
        x2 = cx + math.cos(ang) * w * 1.3
        y2 = cy + math.sin(ang) * h * 1.3
        out.append(
            f'<line x1="{f(cx)}" y1="{f(cy)}" x2="{f(x2)}" y2="{f(y2)}" '
            f'stroke="rgb({INK} / {0.10 if i % 2 else 0.06})" '
            f'stroke-width="{f(max(1.5, u * 0.004))}"/>'
        )
    for r, a in ((0.14, 0.14), (0.21, 0.09)):
        out.append(
            f'<circle cx="{f(cx)}" cy="{f(cy)}" r="{f(u * r)}" fill="none" '
            f'stroke="rgb({INK} / {a})" stroke-width="{f(max(1.5, u * 0.004))}"/>'
        )
    return "".join(out)


MOTIFS = {
    "ripples": motif_ripples,
    "network": motif_network,
    "ribbons": motif_ribbons,
    "rays": motif_rays,
}


def build(slug: str, c1: str, c2: str, motif: str, kind: str, w: int, h: int) -> None:
    body = (
        gradient("g", c1, c2)
        + f'<rect width="{w}" height="{h}" fill="url(#g)"/>'
        + MOTIFS[motif](w, h)
    )
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
        f'viewBox="0 0 {w} {h}" role="img" aria-hidden="true" focusable="false">\n'
        f"{body}\n</svg>\n"
    )
    path = OUT / f"{slug}-{kind}.svg"
    path.write_text(svg, encoding="utf-8")
    print(f"wrote {path} ({path.stat().st_size} bytes)")


for slug, c1, c2, motif in CARDS:
    for kind, (w, h) in SIZES.items():
        build(slug, c1, c2, motif, kind, w, h)

print("done: 12 svg files")
