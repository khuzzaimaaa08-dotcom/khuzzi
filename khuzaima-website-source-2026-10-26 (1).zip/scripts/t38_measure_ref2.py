#!/usr/bin/env python3
"""Pass 2: precise measurement of description lines, phones, showreel overlay.
Card (from pass 1): x 56-1833, y 63-557 -> w 1778, h 495 on #0D0B0A bg."""
from PIL import Image
import numpy as np

im = Image.open("/home/z/my-project/upload/pasted_image_1792667125776.png").convert("RGB")
a = np.asarray(im).astype(int)
CX0, CY0, CW, CH = 56, 63, 1778, 495

def pct(x, y):
    return f"({(x-CX0)/CW*100:.1f}%W, {(y-CY0)/CH*100:.1f}%H)"

# --- description lines: pale text below y=270 abs, left of x=800 ---
pale = (a[:,:,0] > 150) & (a[:,:,0] < 240) & (a[:,:,2] > 215) & (a[:,:,2] >= a[:,:,0]) & (a[:,:,1] > 140)
zone = pale[260:545, 80:800]
dens = zone.mean(axis=1)
lines, inl = [], False
for i, d in enumerate(dens):
    if d > 0.008 and not inl: st = i; inl = True
    elif d <= 0.008 and inl: lines.append((st, i)); inl = False
if inl: lines.append((len(dens)-1, 0))
print("DESCRIPTION lines (abs y, glyph h, x-extent):")
for st, en in lines:
    if en - st < 8: continue
    lsub = zone[st:en]
    lxs = np.where(lsub.any(axis=0))[0]
    print(f"  y {260+st}-{260+en} h={en-st}px {pct(0, 260+st)} x {80+lxs.min()}-{80+lxs.max()} w={lxs.max()-lxs.min()}px left%={(80+lxs.min()-CX0)/CW*100:.1f}")

# --- phones: dark slabs. Scan columns in card right region for dark runs ---
dark = (a[:,:,0] < 55) & (a[:,:,1] < 55) & (a[:,:,2] < 75)
# phone screens are dark; find connected column bands with dark density>0.15 between y 100..520
region = dark[100:520, 500:1500]
cold = region.mean(axis=0)
bands, inb = [], False
for i, d in enumerate(cold):
    if d > 0.12 and not inb: s = i; inb = True
    elif d <= 0.12 and inb: bands.append((s, i)); inb = False
if inb: bands.append((len(cold)-1, len(cold)))
print("DARK column bands (x ranges, likely phone screens):")
for s, e in bands:
    if e - s < 25: continue
    sub = dark[80:540, 500+s:500+e]
    rows = np.where(sub.mean(axis=1) > 0.10)[0]
    print(f"  x {500+s}-{500+e} (w={e-s}) y {80+rows.min()}-{80+rows.max()} (h={rows.max()-rows.min()}) {pct(500+s, 80+rows.min())}")

# --- showreel: white ring around black box in bottom-right ---
# search x 1000-1500, y 300-545 for a solid white rectangle border
white = (a[:,:,0] > 235) & (a[:,:,1] > 235) & (a[:,:,2] > 235)
reg = white[300:545, 1000:1600]
# find the largest contiguous white row run
rd = reg.mean(axis=1)
rr = np.where(rd > 0.03)[0]
print(f"white rows in BR zone: {300+rr.min() if len(rr) else '-'}..{300+rr.max() if len(rr) else '-'}")
# column profile within those rows
if len(rr):
    sub = reg[rr.min():rr.max()]
    cd = sub.mean(axis=0)
    cc = np.where(cd > 0.03)[0]
    print(f"white cols: {1000+cc.min()}..{1000+cc.max()}")
    # check row density profile to distinguish border ring vs solid
    print("row white-fraction (every 8px):", [f"{d:.2f}" for d in rd[::8]][:32])

# pink pixels (H pattern) inside showreel zone
pink = (a[:,:,0] > 170) & (a[:,:,1] < 160) & (a[:,:,2] > 120) & (a[:,:,2] < 230)
pz = pink[300:545, 1000:1600]
ys, xs = np.where(pz)
if len(ys):
    print(f"PINK pixels in BR zone: y {300+ys.min()}-{300+ys.max()} x {1000+xs.min()}-{1000+xs.max()} count {len(ys)}")
    print(f"  pink sample rgb{tuple(a[300+ys[len(ys)//2], 1000+xs[len(xs)//2]])}")

# pill inside showreel: glassy mauve — mid tones with R>B
mauve = (a[:,:,0] > 90) & (a[:,:,0] < 200) & (a[:,:,2] > 80) & (a[:,:,2] < 200) & (a[:,:,1] < a[:,:,0]) & (np.abs(a[:,:,0]-a[:,:,2]) < 70)
mz = mauve[300:545, 1000:1600]
ys2, xs2 = np.where(mz)
if len(ys2):
    print(f"MAUVE-ish pixels in BR zone: y {300+ys2.min()}-{300+ys2.max()} x {1000+xs2.min()}-{1000+xs2.max()} count {len(ys2)}")

# sample a horizontal strip through the showreel center to see structure
ycen = 440
strip = a[ycen, 1000:1300]
print(f"strip y={ycen}:", [f"{i+1000}:{tuple(c)}" for i, c in enumerate(strip[::20])])

# corner radius refined: top-left corner of card, blue mask
blue = (a[:,:,2] > 110) & (a[:,:,2] > a[:,:,0] + 25)
prof = []
for yy in range(CY0, CY0 + 26):
    row = np.where(blue[yy, CX0:CX0 + 40])[0]
    prof.append(row.min() if len(row) else 40)
print("top-left corner dx profile:", prof)

# particle survey: bright specks on the blue bg (not text zones)
speck = (a[:,:,0] > 200) & (a[:,:,1] > 210) & (a[:,:,2] > 230)
speck[260:545, 80:800] = False  # exclude desc
speck[180:260, 100:340] = False  # exclude title
zone2 = speck[80:520, 700:1700]
ys3, xs3 = np.where(zone2)
if len(ys3):
    print(f"SPECKS right zone: count {len(ys3)} y {80+ys3.min()}-{80+ys3.max()} x {700+xs3.min()}-{700+xs3.max()}")
    # density by 100px cell
    print("  sample speck rgb:", tuple(a[80+ys3[5], 700+xs3[5]]))
