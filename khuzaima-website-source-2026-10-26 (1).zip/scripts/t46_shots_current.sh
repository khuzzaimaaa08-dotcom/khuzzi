#!/usr/bin/env bash
# Task 46 — capture current OurWork end → ChatDemo journey at 1792x837
set -u
OUT=/home/z/my-project/qa/work-t46
mkdir -p "$OUT"
AB="agent-browser"

$AB open http://localhost:3000 >/dev/null 2>&1
$AB set viewport 1792 837 >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
sleep 2

shot() { # $1 = scrollY, $2 = name
  $AB eval "window.scrollTo(0, $1)" >/dev/null 2>&1
  sleep 1.4   # let Lenis + scrub settle
  $AB screenshot "$OUT/$2.png" >/dev/null 2>&1
  echo "captured $2 @ y=$1"
}

# OurWork: pin starts at 6023; 4 slides, travel = 3*1792 = 5376 → pin ends ≈ 6023+5376 = 11399
shot 8500  c01-work-midpin
shot 11399 c02-work-pin-end
shot 12100 c03-just-after-work
shot 12692 c04-how-top-enters
shot 13529 c05-how-pinned-start
shot 14400 c06-how-mid
shot 15200 c07-how-late
echo "done"
